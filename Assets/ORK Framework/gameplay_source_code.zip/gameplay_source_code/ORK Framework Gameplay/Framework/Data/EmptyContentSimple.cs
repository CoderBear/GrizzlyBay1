
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class EmptyContentSimple : IContentSimple
	{
		public EmptyContentSimple()
		{
			
		}

		public string GetName()
		{
			return "";
		}

		public string GetDescription()
		{
			return "";
		}

		public string GetIconTextCode()
		{
			return "";
		}

		public Texture2D GetIcon()
		{
			return null;
		}

		public GUIContent GetContent()
		{
			return new GUIContent("");
		}

		public int ID
		{
			get{ return -1;}
		}
	}
}
