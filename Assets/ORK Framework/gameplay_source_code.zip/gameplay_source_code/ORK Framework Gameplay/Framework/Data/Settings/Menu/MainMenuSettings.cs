
using UnityEngine;

namespace ORKFramework
{
	public class MainMenuSettings : BaseSettings
	{
		// main menu scene/call
		[ORKEditorHelp("Main Menu Scene", "The name of the scene the main menu is located.\n" + 
			"This scene is loaded when the game is exited to the main menu.", "")]
		[ORKEditorInfo("Base Settings", "Set the main menu scene and base main menu settings.", "", 
			expandWidth=true)]
		public string mainMenuScene = "";
		
		[ORKEditorHelp("Auto Call", "The main menu will automatically be called when the " +
			"menu scene is loaded (at game start and exit to menu).", "")]
		public bool autoCall = false;
		
		[ORKEditorHelp("Wait Time (s)", "The time in seconds before the main menu is displayed.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("autoCall", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float waitTime = 0;
		
		
		
		// new game
		[ORKEditorHelp("New Game Scene", "The name of the scene that will be loaded when a new game is started.", "")]
		[ORKEditorInfo("New Game Settings", "Set the new game scene and screen fade settings.", "", 
			expandWidth=true)]
		public string newGameScene = "";
		
		[ORKEditorHelp("Stop Music", "The music is stopped when starting a new game.\n" +
			"If disabled, you can manage the music in your start event or the new game scene.", "")]
		public bool newGameStopMusic = true;
		
		[ORKEditorHelp("Start Event", "Select the game event that will be used as start event.\n" +
			"The start event is automatically executed when starting a new game (after loading the new game scene).\n" +
			"If a game starter is set up to start immediately in the scene, the start event will also be started immediately.\n" +
			"Use the start event to add your player combatant to the player group and spawn it in the scene.", "")]
		[ORKEditorInfo(separator=true)]
		public ORKGameEvent startEvent;
		
		[ORKEditorHelp("Set Start Group", "Use a combatant group as the player group at the start of a new game.\n" +
			"The group will be created before executing the start event.", "")]
		public bool setStartGroup = false;
		
		[ORKEditorHelp("Combatant Group", "Select the combatant group that will be used as the player group.", "")]
		[ORKEditorInfo(ORKDataType.CombatantGroup)]
		[ORKEditorLayout("setStartGroup", true, endCheckGroup=true)]
		public int startGroupID = 0;
		
		// screen fade in
		[ORKEditorHelp("Fade Out", "The screen will fade out.", "")]
		[ORKEditorInfo("Screen Fade Out", "The screen can fade out before loading the new game scene.", "", separatorForce=true)]
		public bool useFadeOut = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useFadeOut", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1);
		
		
		// screen fade out
		[ORKEditorHelp("Fade In", "The screen will fade in.", "")]
		[ORKEditorInfo("Screen Fade In", "The screen can fade in after loading the new game scene.", "")]
		public bool useFadeIn = true;
		
		[ORKEditorInfo(endFoldout=true, endFoldoutForce=true)]
		[ORKEditorLayout("useFadeIn", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0);
		
		
		// menu choices
		[ORKEditorInfo("Menu Options", "The options of the main menu are defined here.", "", endFoldout=true)]
		public MainMenuChoice menu = new MainMenuChoice();
		
		
		// exit to main menu
		[ORKEditorInfo("Exit Question", "This dialogue is displayed when you exit a " +
			"running game and return to the main menu.", "", endFoldout=true)]
		public ExitChoice exitChoice = new ExitChoice();
		
		public MainMenuSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "mainMenu"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
	}
}

