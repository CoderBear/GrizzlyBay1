
using UnityEngine;

namespace ORKFramework
{
	public class BattleSettings : BaseSettings
	{
		// base settings
		[ORKEditorHelp("Enemy Counter", "Enemies of the same type can have a counter " +
			"added to their name to differentiate them from another:\n" +
			"- None: No counter is added.\n" +
			"- Letters: Letters are used (A, B, C, ...)\n" +
			"- Numbers: Numbers are used (1, 2, 3, ...)\n" +
			"The enemy counter is only used in arena battles.", "")]
		[ORKEditorInfo("Base Settings", "Base battle system settings.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public EnemyCounting enemyCounter = EnemyCounting.None;
		
		[ORKEditorHelp("Play Damage Animation", "Combatants currently performing a battle action " +
			"(and by this a battle animation) will play their damage animation when receiving damage.\n" +
			"If disabled, damage animations will be ignored for combatants that are in action while receiving damage.", "")]
		public bool playDamageAnim = false;
		
		
		// base defend rate
		[ORKEditorInfo("Base Defend Rate", "Define the base defence rate when using the defend command.\n" +
			"It's used as percent value - i.e. if the value is 100, " +
			"the damage will do 100 % of it's original damage, if the result is 50, the damage " +
			"will only do 50 % of it's original damage.", "", endFoldout=true, separatorForce=true)]
		public FloatValue defendRate = new FloatValue(50);
		
		// escape chance
		[ORKEditorInfo("Base Escape Chance", "Define the base escape chance when using the escape command.\n" +
			"The escape is performed if a random float number between two values " +
			"(default 0 and 100, you can change this in the game settings) " +
			"is less or equal to this value.", "", endFoldout=true)]
		public FloatValue escapeChance = new FloatValue(50);
		
		// escape chance
		[ORKEditorInfo("Random Battle Factor", "Define the random battle factor.\n" +
			"The random battle factor is used to influence the chance of random battles occurring. " +
			"The factor is influenced by the player battle group's random battle factor bonuses.\n" +
			"When using a formula, the player combatant (i.e. leader of the player group) will be used as user and target.\n\n" +
			"E.g.:\n" +
			"The random battle chance is 10 %, the factor is 100 % - the final chance is 10 %." +
			"The chance is 10 %, the factor is 50 % - the final chance is 5 %.", "", endFoldout=true)]
		public FloatValue randomBattleFactor = new FloatValue(100);
		
		
		// ranges
		[ORKEditorInfo("Battle Range", "The distance (in world units) a combatant can " +
			"have to the player to participate in a battle.", "", endFoldout=true)]
		public Range battleRange = new Range(20.0f);
		
		// AI settings
		[ORKEditorHelp("AI Recheck Time (s)", "The time in seconds between AI range checks.", "")]
		[ORKEditorInfo("AI Range", "The distance (in world units) a combatant can " +
			"have to the player to perform AI actions.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float aiRecheckTime = 4.0f;
		
		[ORKEditorInfo(separator=true, labelText="AI Range", endFoldout=true)]
		public Range aiRange = new Range(100.0f);
		
		[ORKEditorInfo("Move Range", "The distance (in world units) a combatant can " +
			"have to the player to use the move AI.\n" +
			"This will be used while not in battle - " +
			"each battle system type can define it's own move AI settings.", "", endFoldout=true)]
		public Range moveAIRange = new Range(100.0f);
		
		[ORKEditorInfo("Auto Join Settings", "Combatants within range of a starting battle can " +
			"automatically join the battle.\n" +
			"This setting can be overridden by individual 'Battle' components in the scene.\n" +
			"Note that this is only used in arena battles (i.e. using the 'Battle' component), " +
			"and not in real time area battles.", "", 
			endFoldout=true, endFolds=2)]
		public AutoJoinBattle autoJoin = new AutoJoinBattle();
		
		
		// default use range
		[ORKEditorInfo("Default Use Range", "The default use range settings for using abilities and items.\n" +
			"The use range determines the maximum distance between user and target to allow using an ability or item. " +
			"The range can be defined for each battle system type." +
			"Can be overridden by each ability and item individually.", "", endFoldout=true)]
		public UseRange useRange = new UseRange();
		
		
		// level up
		[ORKEditorInfo("Level Up Settings", "A combatant can receive bonuses when reaching a new base or class level.", "", 
			labelText="Base Level Up")]
		public LevelUpBonus lvlUp = new LevelUpBonus();
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Class Level Up")]
		public LevelUpBonus cLvlUp = new LevelUpBonus();
		
		
		// battle advantages
		[ORKEditorInfo("Player Advantage", "Battle advantage settings for the player group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "", endFoldout=true)]
		public BattleAdvantage playerAdvantage = new BattleAdvantage();
		
		[ORKEditorInfo("Enemy Advantage", "Battle advantage settings for the enemy group.\n" +
			"Battle advantages can change 'Consumable' type status values, " +
			"status effects and the turn order ('Turn Based' type battles) or timebar ('Active Time' type battles) at the start of a battle.\n" +
			"Advantages are available in arena battles and are decided on a chance basis at the start of a battle.\n" +
			"Arenas can override the chances and block advantages completely.", "", endFoldout=true)]
		public BattleAdvantage enemyAdvantage = new BattleAdvantage();
		
		
		// battle camera
		[ORKEditorInfo("Battle Camera", "The battle camera settings can override and " +
			"block camera changes made by battle animations.\n" +
			"The camera can be set to rotate around the arena and automatically look at users and targets " +
			"or use camera positions to show who's in action.\n" +
			"The battle camera is not available in 'Real Time' type battles.", "", endFoldout=true)]
		public BattleCamera camera = new BattleCamera();
		
		
		// menu settings
		[ORKEditorInfo("Battle Menu Settings", "Define the default battle menu settings.", "", 
			isPopup=true, popupType=ORKDataType.BattleMenu)]
		[ORKEditorHelp("Default Battle Menu", "The default battle menu.\n" +
			"Classes and combatants can define their own battle menu to replace this menu.", "")]
		public int menuID = 0;
		
		// turn based menu
		[ORKEditorHelp("Own Turn Based Menu", "Use a different battle menu in turn based battles.", "")]
		public bool useTurnBasedMenu = false;
		
		[ORKEditorHelp("Turn Based Menu", "Select the battle menu that will be used in turn based battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useTurnBasedMenu", true, endCheckGroup=true)]
		public int turnBasedMenuID = 0;
		
		// active time menu
		[ORKEditorHelp("Own Active Time Menu", "Use a different battle menu in active time battles.", "")]
		public bool useActiveTimeMenu = false;
		
		[ORKEditorHelp("Active Time Menu", "Select the battle menu that will be used in active time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useActiveTimeMenu", true, endCheckGroup=true)]
		public int activeTimeMenuID = 0;
		
		// real time menu
		[ORKEditorHelp("Own Real Time Menu", "Use a different battle menu in real time battles.", "")]
		public bool useRealTimeMenu = false;
		
		[ORKEditorHelp("Real Time Menu", "Select the battle menu that will be used in real time battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("useRealTimeMenu", true, endCheckGroup=true)]
		public int realTimeMenuID = 0;
		
		// phase battle menu
		[ORKEditorHelp("Own Phase Menu", "Use a different battle menu in phase battles.", "")]
		public bool usePhaseMenu = false;
		
		[ORKEditorHelp("Phase Menu", "Select the battle menu that will be used in phase battles.", "")]
		[ORKEditorInfo(ORKDataType.BattleMenu)]
		[ORKEditorLayout("usePhaseMenu", true, endCheckGroup=true)]
		public int phaseMenuID = 0;
		
		// drag/drop
		[ORKEditorHelp("Enable Drag", "The attack command, abilities and items can be " +
			"dragged from the menu on a target to use them.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Settings")]
		public bool bmDrag = false;
		
		[ORKEditorHelp("Enable Double Click", "Double clicking on the attack command, " +
			"an ability or an item and clicking on a target uses the command on the target.", "")]
		public bool bmClick = false;
		
		[ORKEditorHelp("Click Count", "Define the number of clicks needed.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("bmClick", true, endCheckGroup=true)]
		public int bmClickCount = 2;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a battle menu item.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool bmTooltip = false;
		
		
		// target selection
		// target menu
		[ORKEditorHelp("Use Menu", "A menu based target selection is used.", "")]
		[ORKEditorInfo("Target Selection", "The settings for the target selection.\n" +
			"The target selection is used when selecting the target for a base attack, ability or item.\n" +
			"You can combine the different target selections.", "", 
			labelText="Target Menu")]
		public bool useTargetMenu = true;
		
		// target cursor
		[ORKEditorHelp("Use Cursor", "A cursor game object is displayed at the selected target.", "")]
		[ORKEditorInfo("Target Cursor", "A cursor game object can be displayed on a selected target's game object.", "")]
		public bool useTargetCursor = false;
		
		[ORKEditorHelp("Prefab", "Select the prefab used as cursor object.", "")]
		[ORKEditorLayout("useTargetCursor", true)]
		public GameObject cursorPrefab;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings cursorMount = new MountSettings();
		
		// blink
		[ORKEditorHelp("Use Blink", "The selected target's game object will blink.", "")]
		[ORKEditorInfo("Blink Target Object", "The game object of the target can blink.", "")]
		public bool useBlink = false;
		
		[ORKEditorHelp("Blink Children", "All child game objects of the target object will blink.\n" +
			"If disabled, only the root object of the target will blink.", "")]
		[ORKEditorLayout("useBlink", true)]
		public bool blinkChildren = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings blink;
		
		// click combatant
		[ORKEditorInfo(endFoldout=true, separator=true)]
		public MouseTouchControl targetMouseTouch = new MouseTouchControl();
		
		
		// group targets
		[ORKEditorInfo("Group Target Settings", "", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Target Settings", "Adds target settings.", "", 
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] groupTargetSelection = new TargetSelection[0];
		
		
		// individual targets
		[ORKEditorInfo("Individual Target Settings", "", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Target Settings", "Adds target settings.", "", 
			"Remove", "Removes this target settings.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {
				"Target Settings", "Define the input keys and targets that can be selected.", ""
		})]
		public TargetSelection[] individualTargetSelection = new TargetSelection[0];
		
		public BattleSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<DataObject>("groupTarget"))
			{
				DataObject tmpData = data.GetFile("groupTarget");
				if(tmpData != null)
				{
					bool tmp = false;
					tmpData.Get("useGroupTarget", ref tmp);
					if(tmp)
					{
						this.groupTargetSelection = new TargetSelection[1];
						this.groupTargetSelection[0] = new TargetSelection();
						tmpData.Get("onlyInBattleRange", ref this.groupTargetSelection[0].onlyInBattleRange);
						tmpData.Get("noActionOnly", ref this.groupTargetSelection[0].noActionOnly);
						tmpData.Get("autoSelectTarget", ref this.groupTargetSelection[0].autoSelect);
						tmpData.Get("autoAttackTarget", ref this.groupTargetSelection[0].autoAttackTarget);
						tmpData.Get("aaPlayerOnly", ref this.groupTargetSelection[0].aaPlayerOnly);
						tmpData.Get("nextTargetKey", ref this.groupTargetSelection[0].nextKey);
						tmpData.Get("previousTargetKey", ref this.groupTargetSelection[0].previousKey);
						tmpData.Get("nearestTargetKey", ref this.groupTargetSelection[0].nearestKey);
						tmpData.Get("autoAttackTarget", ref this.groupTargetSelection[0].autoAttackTarget);
						tmpData.Get("clearTargetKey", ref this.groupTargetSelection[0].removeKey);
						tmpData.Get("allowTargetRemove", ref this.groupTargetSelection[0].allowClickRemove);
						tmpData.Get("useTargetCursor", ref this.groupTargetSelection[0].useTargetCursor);
						tmpData.Get("cursorPrefab", ref this.groupTargetSelection[0].cursorPrefab);
						
						this.groupTargetSelection[0].clickControl.SetData(tmpData.GetFile("groupMouseTouch"));
						this.groupTargetSelection[0].cursorMount.SetData(tmpData.GetFile("cursorMount"));
					}
				}
			}
			if(data.Contains<bool>("bmDoubleClick"))
			{
				data.Get("bmDoubleClick", ref this.bmClick);
			}
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "battleSettings"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
	}
}
