
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Shortcut", "A combatant's shortcuts will be changed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Shortcut Steps")]
	public class ChangeShortcutStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change shortcuts.\n" +
			"If the actor doesn't have a combatant, no shortcuts will be changed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorArray(false, "Add Shortcut", "Adds a shortcut.", "", 
			"Remove", "Removes this shortcut.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Shortcut", 
			"The selected shortcut slot will be assigned with the defined shortcut.", ""})]
		public ShortcutSlot[] shortcut = new ShortcutSlot[0];
		
		public ChangeShortcutStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					for(int j=0; j<this.shortcut.Length; j++)
					{
						this.shortcut[j].Assign(list[i]);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Actor " + this.id;
		}
	}
	
	[ORKEditorHelp("Check Shortcut", "Checks a combatant's shortcut.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Shortcut Steps")]
	public class CheckShortcutStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change shortcuts.\n" +
			"If the actor doesn't have a combatant, no shortcuts will be changed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorInfo(separator=true, labelText="Check Shortcut")]
		public ShortcutSlot shortcut = new ShortcutSlot();
		
		public CheckShortcutStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.Check(baseEvent.GetActorCombatant(this.id)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool Check(List<Combatant> list)
		{
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && 
					this.shortcut.Check(list[i]))
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Actor " + this.id + ": " + this.shortcut.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Change Shortcut List", "Changes a combatant's currently active shortcut list.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Shortcut Steps")]
	public class ChangeShortcutListStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change shortcuts.\n" +
			"If the actor doesn't have a combatant, no shortcuts will be changed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Change", "Select how the list will be changed:\n" +
			"- Next: Changes to the next shortcut list (i.e. current index + 1).\n" +
			"- Previous: Changes to the previous shortcut list (i.e. current index - 1).\n" +
			"- Defined Index: Changes to a defined shortcut list.", "")]
		public ShortcutListChange change = ShortcutListChange.Next;
		
		
		// defined
		[ORKEditorInfo(separator=true, labelText="List Index")]
		[ORKEditorLayout("change", ShortcutListChange.DefinedIndex, autoInit=true)]
		public EventFloat index;
		
		
		// next/previous
		[ORKEditorHelp("Loop", "Changing the list index will loop, i.e. " +
			"going to the previous list from index 0 will go to the highest index, " +
			"going to the next list from the highest index will go to index 0.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public bool loop = false;
		
		public ChangeShortcutListStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(ShortcutListChange.Next.Equals(this.change))
					{
						list[i].ChangeShortcutList(1, this.loop);
					}
					else if(ShortcutListChange.Previous.Equals(this.change))
					{
						list[i].ChangeShortcutList(-1, this.loop);
					}
					else if(ShortcutListChange.DefinedIndex.Equals(this.change))
					{
						list[i].SetShortcutList((int)this.index.GetValue(baseEvent));
					}
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Actor " + this.id + ": " + 
				(ShortcutListChange.DefinedIndex.Equals(this.change) ? 
					this.index.GetInfoText() : this.change.ToString());
		}
	}
}
