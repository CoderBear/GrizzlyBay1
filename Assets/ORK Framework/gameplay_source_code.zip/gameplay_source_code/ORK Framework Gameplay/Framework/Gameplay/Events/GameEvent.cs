
using ORKFramework;
using ORKFramework.Behaviours;
using ORKFramework.Shop;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class GameEvent : BaseEvent
	{
		[ORKEditorHelp("Blocking Event", "This event is a blocking event.\n" +
			"Only 1 blocking event can be performed at a time - i.e. this event can't be started while another blocking event is running " +
			"(or other blocking events can't be started while this event is running).", "")]
		[ORKEditorInfo("Event Settings", "Base settings of this game event.", "")]
		public bool blockingEvent = false;
		
		[ORKEditorHelp("Block Move AI", "The move AI is blocked while this event is performed.\n" +
			"The move AI will be blocked at the start of the event and unblocked at the end.", "")]
		public bool blockMoveAI = false;
		
		[ORKEditorHelp("Block Actor Move AI", "The move AI of all event actors is blocked while this event is performed.\n" +
			"The move AI of all actors will be blocked at the start of the event and unblocked at the end.", "")]
		[ORKEditorLayout("blockMoveAI", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool blockActorMoveAI = false;
		
		
		// control blocks
		[ORKEditorHelp("Block Player Control", "The control of the player will be blocked during this event.\n" +
			"If disabled, the player can still be controlled - " +
			"this can interfere with some of the event steps, e.g. movement.", "")]
		[ORKEditorInfo(separator=true, labelText="Control Blocks")]
		public bool blockPlayer = false;
		
		[ORKEditorHelp("Block Camera Control", "The control of the camera will be blocked during this event.\n" +
			"If disabled, the camera can still be controlled - " +
			"this can interfere with some of the event steps, e.g. camera changes, etc..", "")]
		public bool blockCamera = false;
		
		[ORKEditorHelp("Clear Block Steps", "All 'block player/camera control' steps will be cleared at the end of the event, " +
			"i.e. each 'block' without an 'unblock' will be unblocked at the end of the event.\n" +
			"E.g.: the player control is blocked 2 times, but only unblocked 1 time - so 1 block is still remaining and will be removed.", "")]
		public bool clearBlocks = false;
		
		// camera settings
		[ORKEditorHelp("Use Main Camera", "The event uses the main camera.\n" +
			"If disabled, you can specify another camera to be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Camera Settings")]
		public bool mainCamera = true;
		
		[ORKEditorHelp("Find With Tag", "The camera is searched using it's tag instead of name.", "")]
		[ORKEditorLayout("mainCamera", false)]
		public bool cameraTag = false;
		
		[ORKEditorHelp("Camera Name", "The name (or tag) of the camera that will be used by this event.", "")]
		[ORKEditorInfo(expandWidth=true, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string cameraName = "";
		
		
		
		// actors
		[ORKEditorInfo("Event Actors", "Event actors are used by certain event steps to " +
			"show their name in a dialogue or move them around in a scene.\n" +
			"Some actors have to be assigned to the event interaction's inspector when the event is used in a scene.\n" +
			"they need to already be placed in a scene to be used.", "", 
			endFoldout=true)]
		[ORKEditorArray(false, "Add Actor", "Adds an event actor to this event.", "", 
			"Remove", "Removes this actor from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Actor", "Event actors are used by certain event steps to " +
			"show their name in a dialogue or move them around in a scene.", ""})]
		public EventActor[] actor = new EventActor[0];
		
		
		// waypoints
		[ORKEditorInfo("Waypoints", "Waypoints can be used to move and place objects in the scene.\n" +
			"A waypoint can either be found in the scene automatically (find object), or has to be " +
			"added to the event interaction in the scene by dragging a scene object on the waypoint.", "", 
			endFoldout=true)]
		[ORKEditorArray(false, "Add Waypoint", "Adds a waypoint to this event.", "", 
			"Remove", "Removes this waypoint from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Waypoint", "Waypoints can be used to move and place objects in the scene.", ""})]
		public Waypoint[] waypoint = new Waypoint[0];
		
		
		// prefabs
		[ORKEditorHelp("Destroy Prefabs", "All spawned prefabs will be destroyed at the end of the event.", "")]
		[ORKEditorInfo("Prefabs", "Events can spawn prefabs in the scene.\n" +
			"A prefab can either be selected in the event settings, or you can set the prefab in the event " +
			"interaction in the scene by dragging a prefab on an empty prefab slot in the inspector.", "")]
		public bool destroyPrefabs = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Prefab", "Adds a prefab to this event.", "", 
			"Remove", "Removes this prefab from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Prefab", "Prefabs can be spawned in the scene by the event.", ""})]
		public EventPrefab[] prefab = new EventPrefab[0];
		
		
		// audio
		[ORKEditorInfo("Audio Clips", "Events can play audio clips in the scene.\n" +
			"An audio clip can either be selected in the event settings, or you can set the audio clip in the event " +
			"interaction in the scene by dragging an audio clip on an empty clip slot in the inspector.", "", 
			endFoldout=true)]
		[ORKEditorArray(false, "Add Audio Clip", "Adds an audio clip to this event.", "", 
			"Remove", "Removes this audio clip from the event.", "", isCopy=true, 
			foldout=true, foldoutText=new string[] {"Audio Clip", "Audio clips can be played by the event.", ""})]
		public EventAudio[] audioClip = new EventAudio[0];
		
		
		/*
		============================================================================
		Ingame variables
		============================================================================
		*/
		private int teleportID = -1;
		
		private ShopScreen shopScreen;
		
		public GameEvent()
		{
			
		}
		
		
		/*
		============================================================================
		Start/End functions
		============================================================================
		*/
		public override void StartEvent(IEventStarter s, GameObject startingObject)
		{
			if(this.step.Length > 0 && !this.executing)
			{
				this.starter = s;
				
				// clear previous runs
				for(int i=0; i<this.actor.Length; i++)
				{
					this.actor[i].Clear();
				}
				for(int i=0; i<this.waypoint.Length; i++)
				{
					this.waypoint[i].Clear();
				}
				for(int i=0; i<this.prefab.Length; i++)
				{
					this.prefab[i].Clear();
				}
				
				if(this.starter is EventInteraction)
				{
					EventInteraction ei = this.starter as EventInteraction;
					
					// find actors in scene or get them from event interaction
					for(int i=0; i<this.actor.Length; i++)
					{
						if(ActorType.Object.Equals(this.actor[i].type))
						{
							if(this.actor[i].isEventObject)
							{
								if(ei != null)
								{
									this.actor[i].SetObject(ei.gameObject);
								}
							}
							else if(this.actor[i].isFindObject)
							{
								this.actor[i].FindObject(this.GameObject);
							}
							else if(ei != null && 
								i < ei.actor.Length && 
								ei.actor[i] != null)
							{
								this.actor[i].SetObject(ei.actor[i].gameObject);
							}
						}
						else if(ActorType.StartingObject.Equals(this.actor[i].type))
						{
							if(startingObject != null)
							{
								this.actor[i].SetObject(startingObject);
							}
						}
					}
					// find waypoints in scene or get them from event interaction
					for(int i=0; i<this.waypoint.Length; i++)
					{
						if(this.waypoint[i].findObject)
						{
							this.waypoint[i].FindObject(this.GameObject);
						}
						else if(ei != null && 
							i < ei.waypoint.Length && 
							ei.waypoint[i] != null)
						{
							this.waypoint[i].SetObject(ei.waypoint[i].gameObject);
						}
					}
					if(ei != null)
					{
						// get prefabs from event interaction
						for(int i=0; i<this.prefab.Length; i++)
						{
							if(this.prefab[i].prefab == null && 
								i < ei.prefab.Length && 
								ei.prefab[i] != null)
							{
								this.prefab[i].SetPrefab(ei.prefab[i]);
							}
						}
						// get audio clips from event interaction
						for(int i=0; i<this.audioClip.Length; i++)
						{
							if(this.audioClip[i].clip == null && 
								i < ei.audioClip.Length && 
								ei.audioClip[i] != null)
							{
								this.audioClip[i].SetClip(ei.audioClip[i]);
							}
						}
					}
				}
				
				// reset teleports
				this.teleportID = -1;
				
				// blocking event
				if(this.blockingEvent)
				{
					ORK.Control.SetEventBlock(1);
				}
				
				// block move AI
				if(this.blockMoveAI)
				{
					ORK.Control.SetBlockMoveAI(1);
				}
				else if(this.blockActorMoveAI)
				{
					for(int i=0; i<this.actor.Length; i++)
					{
						List<GameObject> list = this.actor[i].GetObject(this);
						for(int j=0; j<list.Count; j++)
						{
							if(list[j] != null)
							{
								MoveAIComponent comp = list[j].GetComponentInChildren<MoveAIComponent>();
								if(comp != null)
								{
									comp.blocked = true;
								}
							}
						}
					}
				}
				
				// block controls
				if(this.blockPlayer)
				{
					ORK.Control.SetBlockPlayer(1);
				}
				if(this.blockCamera)
				{
					ORK.Control.SetBlockCamera(1);
				}
				
				this.StartEvent();
			}
			else if(ComponentHelper.IsAlive(s))
			{
				s.EventEnded();
			}
		}
		
		protected override void EndEvent()
		{
			if(this.continueSteps.Count == 0)
			{
				this.executing = false;
				this.timeRunning = false;
				
				if(this.destroyPrefabs)
				{
					for(int i=0; i<this.prefab.Length; i++)
					{
						this.prefab[i].DestroyPrefab(-1, -1);
					}
				}
				
				// blocking event
				if(this.blockingEvent)
				{
					ORK.Control.SetEventBlock(-1);
				}
				
				// block move AI
				if(this.blockMoveAI)
				{
					ORK.Control.SetBlockMoveAI(-1);
				}
				else if(this.blockActorMoveAI)
				{
					for(int i=0; i<this.actor.Length; i++)
					{
						List<GameObject> list = this.actor[i].GetObject(this);
						for(int j=0; j<list.Count; j++)
						{
							if(list[j] != null)
							{
								MoveAIComponent comp = list[j].GetComponentInChildren<MoveAIComponent>();
								if(comp != null)
								{
									comp.blocked = false;
								}
							}
						}
					}
				}
				
				// block controls
				if(this.blockPlayer)
				{
					ORK.Control.SetBlockPlayer(-1);
				}
				if(this.blockCamera)
				{
					ORK.Control.SetBlockCamera(-1);
				}
				// clear block steps
				if(this.clearBlocks)
				{
					if(this.playerBlocks > 0)
					{
						ORK.Control.SetBlockPlayer(-this.playerBlocks);
					}
					if(this.cameraBlocks > 0)
					{
						ORK.Control.SetBlockCamera(-this.cameraBlocks);
					}
				}
				
				// notify interaction
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.EventEnded();
				}
				
				// teleport somewhere
				if(this.gameOver)
				{
					ORK.Game.GameOver();
				}
				else if(this.teleportID >= 0)
				{
					ORK.Teleports.Get(this.teleportID).Use();
				}
				this.calledEvent = null;
				this.starter = null;
			}
			else
			{
				this.endAfterContinue = true;
			}
		}
		
		
		/*
		============================================================================
		Step functions
		============================================================================
		*/
		public override void ExecuteNextStep()
		{
			if(this.executing)
			{
				this.stepFinished = false;
				if(this.currentStep >= 0 && this.currentStep < this.step.Length)
				{
					if(this.step[this.currentStep].active && 
						(!this.stopFlag || this.step[this.currentStep].ExecuteOnStop))
					{
						this.step[this.currentStep].Execute(this);
					}
					else
					{
						this.StepFinished(this.step[this.currentStep].GetNext(0));
					}
				}
				else
				{
					this.EndEvent();
				}
			}
		}
		
		
		/*
		============================================================================
		Actor functions
		============================================================================
		*/
		public override string GetActorName(int index)
		{
			if(index >= 0 && index < this.actor.Length)
			{
				return this.actor[index].GetName();
			}
			return "";
		}
		
		public override Portrait GetActorPortrait(int index, int typeID)
		{
			if(index >= 0 && index < this.actor.Length)
			{
				return this.actor[index].GetPortrait(typeID);
			}
			return null;
		}
		
		public override List<GameObject> GetActorObject(int index)
		{
			if(index >= 0 && index < this.actor.Length)
			{
				return this.actor[index].GetObject(this);
			}
			return new List<GameObject>();
		}
		
		public override List<Combatant> GetActorCombatant(int index)
		{
			if(index >= 0 && index < this.actor.Length)
			{
				return this.actor[index].GetCombatant(this);
			}
			return new List<Combatant>();
		}
		
		public void ReFindActors()
		{
			for(int i=0; i<this.actor.Length; i++)
			{
				this.actor[i].FindObject(this.GameObject);
			}
		}
		
		
		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public override List<GameObject> GetWaypoint(int index)
		{
			if(index >= 0 && index < this.waypoint.Length)
			{
				return this.waypoint[index].GetObject(this);
			}
			return new List<GameObject>();
		}
		
		public void ReFindWaypoints()
		{
			for(int i=0; i<this.waypoint.Length; i++)
			{
				this.waypoint[i].FindObject(this.GameObject);
			}
		}
		
		
		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public override GameObject SpawnPrefab(int index, Vector3 position, Vector3 rotation)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].SpawnPrefab(position, rotation);
			}
			return null;
		}
		
		public override void DestroyPrefab(int index, int spawnID, float time)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				this.prefab[index].DestroyPrefab(spawnID, time);
			}
		}
		
		public override List<GameObject> GetSpawnedPrefab(int index, int spawnID)
		{
			if(index >= 0 && index < this.prefab.Length)
			{
				return this.prefab[index].GetSpawnedPrefab(spawnID);
			}
			return new List<GameObject>();
		}
		
		
		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public override AudioClip GetAudioClip(int index)
		{
			if(index >= 0 && index < this.audioClip.Length)
			{
				return this.audioClip[index].GetClip();
			}
			return null;
		}
		
		
		/*
		============================================================================
		Teleport functions
		============================================================================
		*/
		public void SetTeleportID(int id)
		{
			this.teleportID = id;
		}
		
		public void ChangeScene(SceneChanger sceneChanger, int next)
		{
			this.currentStep = next;
			if(sceneChanger != null)
			{
				this.DontDestroy();
				sceneChanger.SetStarter(this);
				sceneChanger.StartEvent(this.GameObject);
			}
			else
			{
				this.StepFinished(this.currentStep);
			}
		}
		
		
		/*
		============================================================================
		Camera functions
		============================================================================
		*/
		public override Transform GetCamera()
		{
			if(this.camera == null)
			{
				if(this.mainCamera)
				{
					Camera c = Camera.main;
					if(c != null)
					{
						this.camera = c.transform;
					}
				}
				else
				{
					Camera[] cams = Camera.allCameras;
					for(int i=0; i<cams.Length; i++)
					{
						if((this.cameraTag && cams[i].tag == this.cameraName) ||
							(!this.cameraTag && cams[i].name == this.cameraName))
						{
							this.camera = cams[i].transform;
							break;
						}
					}
				}
			}
			return this.camera;
		}
		
		
		/*
		============================================================================
		Call event functions
		============================================================================
		*/
		public override void CallEvent(ORKEventAsset eventAsset, int next)
		{
			this.currentStep = next;
			if(eventAsset != null)
			{
				this.calledEvent = new GameEvent();
				this.calledEvent.SetData(eventAsset.GetData().ToDataObject());
				this.calledEvent.StartEvent(this, this.GameObject);
			}
			else
			{
				this.StepFinished(this.currentStep);
			}
		}
		
		
		/*
		============================================================================
		Shop functions
		============================================================================
		*/
		public void OpenShop(int shopID, string shopSceneID, int factionID, int next, int nextFail)
		{
			this.currentStep = next;
			this.currentStepFail = nextFail;
			this.shopScreen = new ShopScreen(this, shopID, shopSceneID, factionID);
		}
		
		public void CloseShop(bool bought)
		{
			this.shopScreen = null;
			this.StepFinished(bought ? this.currentStep : this.currentStepFail);
		}
	}
}
