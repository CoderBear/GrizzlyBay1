
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Spawn Player", "Spawns the player or a member of the player group at the defined spawn point, position or object.\n" +
		"The player/member wont be spawned if the spawn point or object doesn't exist.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Spawn Steps")]
	public class SpawnPlayerStep : BaseEventStep
	{
		// member
		[ORKEditorHelp("Spawn Member", "Spawn a member of the player group instead of the player.\n" +
			"If disabled, the player (i.e. leader of the player group) will be spawned.", "")]
		public bool useMember = false;
		
		[ORKEditorHelp("Member Index", "The index of the member in the player group.\n" +
			"If the index is higher than the number of group members, the first member (player) is used.", "")]
		[ORKEditorLayout("useMember", true)]
		[ORKEditorLimit(0, false)]
		public int memberIndex = 0;
		
		[ORKEditorHelp("Only Battle Group", "Only members of the battle group are used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool onlyBattle = false;
		
		
		// type
		[ORKEditorHelp("Spawn At", "Select where the player will spawn at:\n" +
			"- Spawn Point: At a spawn point.\n" +
			"- Position: At a defined position.\n" +
			"- Object: At the position of a game object.", "")]
		[ORKEditorInfo(separator=true)]
		public PlayerSpawnTarget target = PlayerSpawnTarget.SpawnPoint;
		
		
		// spawn point
		[ORKEditorHelp("Spawn Point ID", "The ID of the spawn point the player will be spawned at.\n" +
			"There must be a game object with a SpawnPoint component with the " +
			"defined ID in the scene when the event is executed.", "")]
		[ORKEditorLayout("target", PlayerSpawnTarget.SpawnPoint, endCheckGroup=true)]
		public int id = 0;
		
		
		// position
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout("target", PlayerSpawnTarget.Position, autoInit=true)]
		public EventVector3 position;
		
		[ORKEditorHelp("Set Y Rotation", "Set the Y-axis rotation when spawning the player.", "")]
		public bool setYRotation = false;
		
		[ORKEditorHelp("Y Rotation", "The Y-axis rotation used when spawning the player.", "")]
		[ORKEditorLayout("setYRotation", true, endCheckGroup=true)]
		public float yRotation = 0;
		
		[ORKEditorHelp("Set Scale", "Set the scale when spawning the player.", "")]
		public bool setScale = false;
		
		[ORKEditorHelp("Scale", "The scale used when spawning the player.", "")]
		[ORKEditorLayout("setScale", true, endCheckGroup=true, endGroups=2)]
		public Vector3 scale = Vector3.one;
		
		
		// object
		[ORKEditorInfo(callbackBefore="info:spawnplayer", separator=true, labelText="Object")]
		[ORKEditorLayout("target", PlayerSpawnTarget.Object, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting useObject;
		
		public SpawnPlayerStep()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<bool>("atObject"))
			{
				bool tmp = false;
				data.Get("atObject", ref tmp);
				if(tmp)
				{
					this.target = PlayerSpawnTarget.Object;
				}
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useMember)
			{
				Combatant combatant = this.onlyBattle ? 
					ORK.Game.ActiveGroup.BattleMemberAt(this.memberIndex) : 
					ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
				
				if(combatant != null)
				{
					if(PlayerSpawnTarget.Position.Equals(this.target))
					{
						combatant.Spawn(this.position.GetValue(baseEvent), 
							this.setYRotation, this.yRotation, 
							this.setScale, this.scale);
					}
					else if(PlayerSpawnTarget.Object.Equals(this.target))
					{
						List<GameObject> list = this.useObject.GetObject(baseEvent);
						if(list.Count > 0)
						{
							combatant.Spawn(
								TransformHelper.GetCenterPosition(list), 
								true, TransformHelper.GetAverageEulerAngles(list).y, 
								false, Vector3.one);
						}
					}
					else
					{
						SpawnPoint sp = SpawnPoint.GetSpawnPoint(this.id);
						if(sp != null)
						{
							combatant.Spawn(sp.transform.position, 
								sp.useYRotation, sp.transform.eulerAngles.y, 
								sp.useScale, sp.transform.localScale);
						}
					}
				}
			}
			else
			{
				if(PlayerSpawnTarget.Position.Equals(this.target))
				{
					ORK.Game.PlayerHandler.SpawnPlayer(this.position.GetValue(baseEvent), 
						this.setYRotation, this.yRotation, 
						this.setScale, this.scale);
				}
				else if(PlayerSpawnTarget.Object.Equals(this.target))
				{
					List<GameObject> list = this.useObject.GetObject(baseEvent);
					if(list.Count > 0)
					{
						ORK.Game.PlayerHandler.SpawnPlayer(
							TransformHelper.GetCenterPosition(list), 
							true, TransformHelper.GetAverageEulerAngles(list).y, 
							false, Vector3.one);
					}
				}
				else
				{
					ORK.Game.PlayerHandler.SpawnPlayer(this.id);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			if(PlayerSpawnTarget.SpawnPoint.Equals(this.target))
			{
				return (this.useMember ? "Member " + this.memberIndex : "Player") + 
					": Spawn Point " + this.id;
			}
			else if(PlayerSpawnTarget.Position.Equals(this.target))
			{
				return (this.useMember ? "Member " + this.memberIndex : "Player") + 
					": Position " + this.position.GetInfoText();
			}
			else if(PlayerSpawnTarget.Object.Equals(this.target))
			{
				return (this.useMember ? "Member " + this.memberIndex : "Player") + 
					": Object";
			}
			return (this.useMember ? "Member " + this.memberIndex + ": " : "Player: ") + 
					this.target.ToString();
		}
	}
	
	[ORKEditorHelp("Destroy Player", "Destroys (removes) the game object of the player or " +
		"a member of the player group, or the whole party.\n" +
		"This will remove them from your scene.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Spawn Steps")]
	public class DestroyPlayerStep : BaseEventStep
	{
		// member
		[ORKEditorHelp("Destroy Member", "Destroay a member of the player group instead of the player.\n" +
			"If disabled, the player (i.e. leader of the player group) will be destroyed.", "")]
		public bool useMember = false;
		
		[ORKEditorHelp("Member Index", "The index of the member in the player group.\n" +
			"If the index is higher than the number of group members, the first member (player) is used.", "")]
		[ORKEditorLayout("useMember", true)]
		[ORKEditorLimit(0, false)]
		public int memberIndex = 0;
		
		[ORKEditorHelp("Only Battle Group", "Only members of the battle group are used.", "")]
		public bool onlyBattle = false;
		
		
		// group
		[ORKEditorHelp("Whole Group", "All game objects of the player group will be destroyed (removed).\n" +
			"If disabled, only the player game object will be destroyed.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public bool all = false;
		
		public DestroyPlayerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useMember)
			{
				Combatant combatant = this.onlyBattle ? 
					ORK.Game.ActiveGroup.BattleMemberAt(this.memberIndex) : 
					ORK.Game.ActiveGroup.MemberAt(this.memberIndex);
				
				if(combatant != null)
				{
					combatant.DestroyPrefab();
				}
			}
			else if(this.all)
			{
				ORK.Game.ActiveGroup.DestroyInstances();
			}
			else
			{
				ORK.Game.PlayerHandler.DestroyPlayer();
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useMember ? 
				"Member " + this.memberIndex : 
				(this.all ? "Whole Group" : "Player");
		}
	}
	
	[ORKEditorHelp("Teleport To", "Teleports the player group to a teleport target.\n" +
		"The event will end after the teleport.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Spawn Steps")]
	public class TeleportToStep : BaseEventStep
	{
		[ORKEditorHelp("Teleport To", "Select the teleport target the player group will be teleported to.\n" +
			"The teleports conditions are ignored (i.e. the player group will be teleported even if the " +
			"variable conditions of the teleport are not valid).", "")]
		[ORKEditorInfo(ORKDataType.Teleport)]
		public int id = 0;
		
		public TeleportToStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is GameEvent)
			{
				((GameEvent)baseEvent).SetTeleportID(this.id);
			}
			baseEvent.StepFinished(baseEvent.step.Length);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Teleports.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Spawn Prefab", "Spawns a prefab.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Spawn Steps")]
	public class SpawnPrefabStep : BaseEventStep
	{
		[ORKEditorHelp("Prefab", "Select the prefab that will be spawned.\n" +
			"Each prefab keeps track of it's spawned instances - " +
			"the first spawned instance will have ID 0, the second ID 1, etc.\n" +
			"You can use spawned prefabs individually or all at once in other steps.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=2)]
		public int id = 0;
		
		
		// vector3
		[ORKEditorHelp("Use Position", "Spawn the prefab at a defind position.\n" +
			"If disabled, a game object (e.g. an actor) will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool usePosition = false;
		
		[ORKEditorInfo(separator=true, labelText="Position")]
		[ORKEditorLayout("usePosition", true, autoInit=true)]
		public EventVector3 position;
		
		
		// object
		[ORKEditorInfo(separator=true, callbackBefore="info:spawnprefab", labelText="Target Object")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public EventObjectSetting useObject = new EventObjectSetting();
		
		[ORKEditorHelp("Use Center", "The prefab will spawn at the center of all target objects.\n" +
			"If disabled, a prefab will be spawned at every target object.", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between spawning two prefabs.\n" +
			"Only used if greater than 0 and more than one prefab will be spawned.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useCenter", false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all prefabs to spawn before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		[ORKEditorLayout(autoInit=true)]
		public MountSettings place = new MountSettings();
		
		[ORKEditorHelp("Mount", "The prefab will be mounted on the object it spawns at.\n" +
			"If disabled, the prefab will only be set to the object's position.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public bool mount = false;
		
		
		// audio options
		[ORKEditorHelp("Play Audio", "Play an audio clip when spawning the prefab.\n" +
			"The clip will be played on the prefab.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Options")]
		public bool useAudio = false;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=3)]
		[ORKEditorLayout("useAudio", true)]
		public int id2 = 0;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayAudioSettings audio;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public SpawnPrefabStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.usePosition)
			{
				GameObject prefab = baseEvent.SpawnPrefab(this.id, 
					this.position.GetValue(baseEvent), Vector3.zero);
				
				if(this.useAudio && prefab != null)
				{
					AudioClip clip = baseEvent.GetAudioClip(this.id2);
					if(clip != null)
					{
						this.audio.PlayAudio(prefab, clip);
					}
				}
				baseEvent.StepFinished(this.next);
			}
			else if(this.useCenter)
			{
				Vector3 pos = Vector3.zero;
				Vector3 rot = Vector3.zero;
				TransformHelper.GetCenterPosRot(
					this.useObject.GetObject(baseEvent), 
					ref pos, ref rot);
				GameObject prefab = baseEvent.SpawnPrefab(this.id, pos, rot);
				
				if(this.useAudio && prefab != null)
				{
					AudioClip clip = baseEvent.GetAudioClip(this.id2);
					if(clip != null)
					{
						this.audio.PlayAudio(prefab, clip);
					}
				}
				baseEvent.StepFinished(this.next);
			}
			else
			{
				this.list = this.useObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.list.Count > 0)
				{
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				Vector3 pos = Vector3.zero;
				Vector3 rot = Vector3.zero;
				
				if(this.mount)
				{
					this.place.GetMountTo(this.list[this.index].transform, 
						ref pos, ref rot);
				}
				else
				{
					this.place.GetPlace(this.list[this.index].transform, 
						ref pos, ref rot);
				}
				
				GameObject prefab = baseEvent.SpawnPrefab(this.id, pos, rot);
				
				if(prefab != null)
				{
					if(this.place.setScale)
					{
						prefab.transform.localScale = this.place.scale;
					}
					if(this.mount)
					{
						prefab.transform.parent = TransformHelper.GetChild(
							this.place.childName, this.list[this.index].transform);
					}
					if(this.useAudio)
					{
						AudioClip clip = baseEvent.GetAudioClip(this.id2);
						if(clip != null)
						{
							this.audio.PlayAudio(prefab, clip);
						}
					}
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.id.ToString() + ": " + 
				(this.usePosition ? "Position " + this.position.GetInfoText() : "Object");
		}
	}
	
	[ORKEditorHelp("Destroy Prefab", "Destroy prefabs.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Spawn Steps")]
	public class DestroyPrefabStep : BaseEventStep
	{
		[ORKEditorHelp("Prefab", "Select the prefab that will be destroyed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=2)]
		public int id = 0;
		
		[ORKEditorHelp("Spawned Prefab ID", "The ID of the spawned prefab.\n" +
			"Each prefab keeps track of it's spawned instances - " +
			"the first spawned instance will have ID 0, the second ID 1, etc.\n" +
			"Use -1 for all spawned instances of the selected prefab.", "")]
		[ORKEditorLimit(-1, false)]
		public int id2 = -1;
		
		
		// destroy after time
		[ORKEditorHelp("Destroy After Time", "The prefab will be destroyed after a defined amount of time.\n" +
			"If disabled, the prefab is destroyed immediately.\n" +
			"You can use this setting to destroy prefabs after the event has ended.", "")]
		public bool destroyAfter = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds before the prefab is destroyed.", "")]
		[ORKEditorLayout("destroyAfter", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until the prefab is destroyed before the next step is executed.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool wait = false;
		
		public DestroyPrefabStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.DestroyPrefab(this.id, this.id2, this.destroyAfter ? this.time : -1);
			
			if(this.destroyAfter && this.wait)
			{
				baseEvent.StartTime(this.time, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.id2 == -1 ? this.id + "-All" : this.id + "-" + this.id2;
		}
	}
	
	[ORKEditorHelp("Destroy Object", "Destroys a game object.\n" +
		"When destroying the event object, the event wont be able to be updated any longer.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Spawn Steps")]
	public class DestroyObjectStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Destroy Object")]
		public EventObjectSetting useObject = new EventObjectSetting();
		
		
		// destroy after time
		[ORKEditorHelp("Destroy After Time", "The prefab will be destroyed after a defined amount of time.\n" +
			"If disabled, the prefab is destroyed immediately.\n" +
			"You can use this setting to destroy prefabs after the event has ended.", "")]
		[ORKEditorInfo(separator=true)]
		public bool destroyAfter = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds before the prefab is destroyed.", "")]
		[ORKEditorLayout("destroyAfter", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Wait", "Wait until the prefab is destroyed before the next step is executed.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool wait = false;
		
		public DestroyObjectStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.useObject.GetObject(baseEvent);
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.destroyAfter)
					{
						GameObject.Destroy(list[i], this.time);
					}
					else
					{
						GameObject.Destroy(list[i]);
					}
				}
			}
			
			if(this.destroyAfter && this.wait)
			{
				baseEvent.StartTime(this.time, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.destroyAfter ? 
				"Destroy after " + this.time + (this.wait ? "s (Wait)" : "s") : 
				"";
		}
	}
}
