
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class ChoiceLanguageContent : BaseData
	{
		[ORKEditorHelp("Text", "The text of this button.", "")]
		[ORKEditorInfo(isTextArea=true, textAreaType=1)]
		public string name = "";

		[ORKEditorHelp("Icon", "The icon of this button.", "")]
		public Texture2D icon;
		
		
		// info
		[ORKEditorHelp("Add Info", "Add an info text to the button.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Info")]
		public bool addInfo = false;
		
		[ORKEditorHelp("Info Text", "The info text of this button.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, textAreaType=1)]
		[ORKEditorLayout("addInfo", true, endCheckGroup=true, setDefault=true, defaultValue="")]
		public string infoText = "";
		
		
		// title
		[ORKEditorHelp("Add Title", "Add a title to the button.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Title")]
		public bool addTitle = false;
		
		[ORKEditorHelp("Title Text", "The text of this button's title.", "")]
		[ORKEditorInfo(isTextArea=true, textAreaType=1)]
		[ORKEditorLayout("addTitle", true, setDefault=true, defaultValue="")]
		public string titleText = "";
		
		[ORKEditorHelp("Title Icon", "The icon of this button's title.", "")]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=null)]
		public Texture2D titleIcon;
		
		public ChoiceLanguageContent()
		{
			
		}
		
		public ChoiceLanguageContent(string name)
		{
			this.name = name;
		}
		
		public ChoiceContent GetChoiceContent(BaseEvent baseEvent)
		{
			return new ChoiceContent(
				new GUIContent(
					TextHelper.ReplaceActorSpecials(this.name, baseEvent), 
					this.icon), 
				true, 
				this.addInfo ? TextHelper.ReplaceActorSpecials(this.infoText, baseEvent) : "", 
				this.addTitle ? 
					new GUIContent(
						TextHelper.ReplaceActorSpecials(this.titleText, baseEvent), this.titleIcon) : 
					null);
		}
	}
}

