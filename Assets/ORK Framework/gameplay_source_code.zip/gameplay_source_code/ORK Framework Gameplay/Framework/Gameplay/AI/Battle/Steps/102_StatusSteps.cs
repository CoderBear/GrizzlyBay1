
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Turn", "Checks a combatant's turn number (i.e. the number of actions/turns performed by the combatant).\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Status Steps", "Check Steps")]
	public class CheckTurnStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		
		// turn
		[ORKEditorHelp("Every n Turns", "The check is true every set number of turns " +
			"(e.g. every 2nd turn when 'turn' is set to 2).\n" +
			"If disabled, the check is true at the specific turn number " +
			"(e.g. the 5th turn of a combatant).", "")]
		[ORKEditorInfo(separator=true, labelText="Turn")]
		public bool everyTurn = false;
		
		[ORKEditorHelp("Turn", "Set the turn that will be checked for.", "")]
		[ORKEditorLimit(1, false)]
		public int turn = 1;
		
		[ORKEditorHelp("Check Type", "Checks if the turn is equal, not equal, less or greater defined turn.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("everyTurn", false, endCheckGroup=true)]
		public ValueCheck check = ValueCheck.IsEqual;
		
		public CheckTurnStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(ref any, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check turns of all possible targets, add to found targets
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && 
					((this.everyTurn && (list[i].Turn % this.turn) == 0) ||
					(!this.everyTurn && ValueHelper.CheckValue(list[i].Turn, this.turn, this.check))))
				{
					any = true;
					if(!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " + (this.everyTurn ? 
				(this.turn == 1 ? "Every turn" : "Every " + this.turn + " turns") : 
				this.check + " " + this.turn);
		}
	}
	
	[ORKEditorHelp("Check Status", "Checks a combatant on certain status requirements, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Status Steps", "Check Steps")]
	public class CheckStatusStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		[ORKEditorHelp("Force Knowledge", "Force status checks to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;
		
		
		// status
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;
		
		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "", 
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[] {new StatusRequirement()};
		
		public CheckStatusStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(ref any, user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}
		
		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && 
					this.CheckRequirements(user, list[i]))
				{
					any = true;
					if(!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}
		
		private bool CheckRequirements(Combatant user, Combatant target)
		{
			if(!this.forceKnowledge && 
				ORK.GameSettings.bestiary.useBestiary && 
				ORK.GameSettings.bestiary.useInBattleAI && 
				user.IsPlayerControlled() && user.IsEnemy(target))
			{
				return StatusRequirement.CheckBestiary(target, this.req, this.needed);
			}
			return StatusRequirement.Check(target, this.req, this.needed);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}
	}
	
	[ORKEditorHelp("Get Status Value", "The combatant with the highest or lowest value of a " +
		"selected status value will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Status Steps")]
	public class GetStatusValueStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;
		
		
		// status
		[ORKEditorHelp("Status Value", "Select the status value that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int statusID = 0;
		
		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected status value will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the selected status value will be added to the target list.", "")]
		public bool getHighest = false;
		
		public GetStatusValueStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			currentStep = this.next;
			return null;
		}
		
		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			int tmpVal = this.getHighest ? int.MinValue : int.MaxValue;
			
			// check for highest/lowest status value
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge && 
						ORK.GameSettings.bestiary.useBestiary && 
						ORK.GameSettings.bestiary.useInBattleAI && 
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null && 
							(list[i].Bestiary.IsComplete || 
							list[i].Bestiary.status.statusValues))
						{
							int statVal = list[i].Status[this.statusID].GetValue();
							if((this.getHighest && tmpVal < statVal) || 
								(!this.getHighest && tmpVal > statVal))
							{
								tmpVal = statVal;
								found = i;
							}
						}
					}
					else
					{
						int statVal = list[i].Status[this.statusID].GetValue();
						if((this.getHighest && tmpVal < statVal) || 
							(!this.getHighest && tmpVal > statVal))
						{
							tmpVal = statVal;
							found = i;
						}
					}
				}
			}
			
			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + 
				ORK.StatusValues.GetName(this.statusID);
		}
	}
	
	[ORKEditorHelp("Get Attack Attribute", "The combatant with the highest or lowest value of a " +
		"selected attack attribute will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Status Steps")]
	public class GetAttackAttributeStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;
		
		
		// status
		[ORKEditorHelp("Attack Attribute", "Select the attack attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, separator=true)]
		public int attributeID = 0;
		
		[ORKEditorHelp("Attribute", "Select the attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, idFieldName="attributeID")]
		public int subID = 0;
		
		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected attack attribute will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"selected attack attribute will be added to the target list.", "")]
		public bool getHighest = false;
		
		public GetAttackAttributeStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			currentStep = this.next;
			return null;
		}
		
		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? Mathf.NegativeInfinity : Mathf.Infinity;
			
			// check for highest/lowest attribute
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge && 
						ORK.GameSettings.bestiary.useBestiary && 
						ORK.GameSettings.bestiary.useInBattleAI && 
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null && 
							(list[i].Bestiary.IsComplete || 
							list[i].Bestiary.status.attackAttribute[this.attributeID].attribute[this.subID]))
						{
							float attrVal = list[i].Status.GetAttackAttribute(this.attributeID).GetValue(this.subID);
							if((this.getHighest && tmpVal < attrVal) || 
								(!this.getHighest && tmpVal > attrVal))
							{
								tmpVal = attrVal;
								found = i;
							}
						}
					}
					else
					{
						float attrVal = list[i].Status.GetAttackAttribute(this.attributeID).GetValue(this.subID);
						if((this.getHighest && tmpVal < attrVal) || 
							(!this.getHighest && tmpVal > attrVal))
						{
							tmpVal = attrVal;
							found = i;
						}
					}
				}
			}
			
			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + 
				ORK.AttackAttributes.GetName(this.attributeID, this.subID) + 
				" (" + ORK.AttackAttributes.GetName(this.attributeID) + ")";
		}
	}
	
	[ORKEditorHelp("Get Defence Attribute", "The combatant with the highest or lowest value of a " +
		"selected defence attribute will be added to the target list.\n" +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Status Steps")]
	public class GetDefenceAttributeStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;
		
		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TargetType targetType = TargetType.Ally;
		
		[ORKEditorHelp("Force Knowledge", "Force the check to have all status information " +
			"instead of checking bestiary entries.\n" +
			"Only used when a player combatant checks an enemy.", "")]
		public bool forceKnowledge = false;
		
		
		// status
		[ORKEditorHelp("Defence Attribute", "Select the defence attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, separator=true)]
		public int attributeID = 0;
		
		[ORKEditorHelp("Attribute", "Select the attribute that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="attributeID")]
		public int subID = 0;
		
		[ORKEditorHelp("Highest/Lowest", "If enabled, the combatant with the highest value of the " +
			"selected defence attribute will be added to the target list.\n" +
			"If disabled, the combatant with the lowest value of the " +
			"selected defence attribute will be added to the target list.", "")]
		public bool getHighest = false;
		
		public GetDefenceAttributeStep()
		{
			
		}

		public override BaseAction Execute(ref int currentStep, Combatant user, 
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear.Equals(this.foundType))
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check.Equals(this.foundType))
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}
			
			// check all possible targets
			this.Check(user, this.GetTargetList(this.targetType, user, allies, enemies), foundTargets);
			
			currentStep = this.next;
			return null;
		}
		
		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			int found = -1;
			float tmpVal = this.getHighest ? Mathf.NegativeInfinity : Mathf.Infinity;
			
			// check for highest/lowest attribute
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(!this.forceKnowledge && 
						ORK.GameSettings.bestiary.useBestiary && 
						ORK.GameSettings.bestiary.useInBattleAI && 
						user.IsPlayerControlled() && user.IsEnemy(list[i]))
					{
						list[i].FindBestiaryEntry();
						if(list[i].Bestiary != null && 
							(list[i].Bestiary.IsComplete || 
							list[i].Bestiary.status.defenceAttribute[this.attributeID].attribute[this.subID]))
						{
							float attrVal = list[i].Status.GetDefenceAttribute(this.attributeID).GetValue(this.subID);
							if((this.getHighest && tmpVal < attrVal) || 
								(!this.getHighest && tmpVal > attrVal))
							{
								tmpVal = attrVal;
								found = i;
							}
						}
					}
					else
					{
						float attrVal = list[i].Status.GetDefenceAttribute(this.attributeID).GetValue(this.subID);
						if((this.getHighest && tmpVal < attrVal) || 
							(!this.getHighest && tmpVal > attrVal))
						{
							tmpVal = attrVal;
							found = i;
						}
					}
				}
			}
			
			if(found >= 0 && !foundTargets.Contains(list[found]))
			{
				foundTargets.Add(list[found]);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.getHighest ? "Highest " : "Lowest ") + 
				ORK.DefenceAttributes.GetName(this.attributeID, this.subID) + 
				" (" + ORK.DefenceAttributes.GetName(this.attributeID) + ")";
		}
	}
}

