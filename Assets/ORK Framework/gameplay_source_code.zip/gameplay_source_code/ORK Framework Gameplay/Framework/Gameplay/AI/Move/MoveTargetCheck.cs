
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveTargetCheck : BaseData
	{
		[ORKEditorHelp("Interval (s)", "The time between two target checks.\n" +
			"Set to 0 if the target's position should be checked every frame.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float interval = 0.5f;
		
		[ORKEditorHelp("Minimum Distance", "The minimum distance to the target in world space " +
			"to use this target check's interval.\n", "")]
		[ORKEditorLimit(0.0f, false)]
		public float distance = 10;
		
		public MoveTargetCheck()
		{
			
		}
		
		public MoveTargetCheck(float interval, float distance)
		{
			this.interval = interval;
			this.distance = distance;
		}
	}
}
