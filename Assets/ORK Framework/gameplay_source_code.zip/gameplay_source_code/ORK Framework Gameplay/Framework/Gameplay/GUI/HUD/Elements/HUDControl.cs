
using UnityEngine;
using ORKFramework.Behaviours;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDControl : BaseData
	{
		// control settings
		[ORKEditorHelp("Control Type", "Select the control type of this HUD control:\n" +
			"- Positive Button: Sets an input key's positive button state (axis 1).\n" +
			"- Negative Button: Sets an input key's negative button state (axis -1).\n" +
			"- Axis: Sets an input key's axis between -1 to 1.\n" +
			"- Joystick: Sets two input key's axis between -1 to 1.", "")]
		public HUDControlType type = HUDControlType.PositiveButton;
		
		[ORKEditorHelp("Input Key", "Select the input key that will receive the status from this HUD control.\n" +
			"If 'Is Joystick' is used, this key will be the horizontal axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int keyID = 0;
		
		[ORKEditorHelp("Invert Axis", "Invert the axis values of input key, -1 and 1 will be transposed.", "")]
		public bool invertAxis = false;
		
		[ORKEditorHelp("Input Key 2", "Select the input key that will receive the status from this HUD control.\n" +
			"This key will be the vertical axis.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("type", HUDControlType.Joystick)]
		public int keyID2 = 0;
		
		[ORKEditorHelp("Invert Axis 2", "Invert the axis values of input key 2, -1 and 1 will be transposed.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool invertAxis2 = false;
		
		
		// axis/joystick
		[ORKEditorHelp("Axis Center", "The position of the axis center within the bounds of this element.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		[ORKEditorInfo(separator=true, labelText="Axis Settings")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {HUDControlType.Axis, HUDControlType.Joystick}, needed=Needed.One)]
		public Vector2 axisCenter = Vector2.zero;
		
		[ORKEditorHelp("Maximum Distance", "The maximum distance to the center of the axis.\n" +
			"The maximum distance will be axis -1 or 1.", "")]
		public float maxDist = 50;
		
		[ORKEditorHelp("Auto Release", "Automatically release the control if the distance between the touch and the " +
			"center of the axis exceeds a defined distance.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool autoRelease = false;
		
		[ORKEditorHelp("Release Distance", "The maximum distance to the center of the axis that will release the control.", "")]
		[ORKEditorLayout("autoRelease", true, endCheckGroup=true)]
		public float releaseDist = 200;
		
		[ORKEditorHelp("Axis Type", "Select if the input key uses the 'Horizontal' or 'Vertical' axis of the control.\n" +
			"If control type 'Joystick' is used, input key 2 uses the other axis (i.e. if 'Vertical' is used if 'Horizontal' is selected).", "")]
		[ORKEditorInfo(isEnumToolbar=true)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public ColumnFill axisType = ColumnFill.Horizontal;
		
		[ORKEditorHelp("Auto Release", "Automatically release the control if the touch leaves the bounds of the element.", "")]
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool autoRelB = false;
		
		
		// images
		[ORKEditorInfo(separator=true, labelText="Default Image")]
		public BaseImage image = new BaseImage();
		
		[ORKEditorHelp("Image Bounds", "The position and size of the image.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		public Rect imgBounds = new Rect(0, 0, 100, 100);
		
		[ORKEditorHelp("Use Pressed", "Use a different image when this control is pressed/used (i.e. clicked or touched).", "")]
		[ORKEditorInfo(separator=true, labelText="Pressed Image")]
		public bool usePressed = false;
		
		[ORKEditorLayout("usePressed", true, autoInit=true)]
		public BaseImage pressedImage;
		
		[ORKEditorHelp("Pressed Bounds", "The position and size of the pressed image.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		public Rect pImgBounds = new Rect(0, 0, 100, 100);
		
		[ORKEditorHelp("Display For (s)", "The time in seconds the pressed state will be visible, after the control is no longer used.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float pTime = 0;
		
		
		// position
		[ORKEditorHelp("Show Box", "Shows a box around this element using the style of " +
			"the box defined by the GUISkin of the GUI box.\n" +
			"The position and size of the box is defined by the bounds.", "")]
		[ORKEditorInfo(separator=true, labelText="Element Position")]
		public bool box = false;
		
		[ORKEditorHelp("No Flash", "This element won't flash when the HUD flashes.", "")]
		public bool noFlash = false;
		
		[ORKEditorHelp("Bounds", "The position and size of this element.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of the GUI box this HUD uses.", "")]
		public Rect bounds = new Rect(0, 0, 300, 100);
		
		
		// background image
		[ORKEditorHelp("Show Background", "Display a background image in this HUD element.", "")]
		[ORKEditorInfo(separator=true, labelText="Background Image")]
		public bool showBackground = false;
		
		[ORKEditorLayout("showBackground", true, endCheckGroup=true, autoInit=true)]
		public DisplayImage bg;
		
		
		
		
		
		// ingame
		private float timeout = 0;
		
		private int fingerID = -1;
		
		private bool pressed = false;
		
		private Vector2 pOff = Vector2.zero;
		
		
		// new ui
		private GameObject gameObject;
		
		public HUDControl()
		{
			
		}
		
		public void Close()
		{
			this.fingerID = -1;
			this.timeout = 0;
			this.pressed = false;
		}
		
		public void Tick(ControlHUDContent hudContent, int index)
		{
			this.pressed = false;
			this.pOff = Vector2.zero;
			
			if(this.timeout > 0)
			{
				this.timeout -= ORK.Core.GUITimeDelta;
			}
			
			bool start = false;
			if(this.fingerID == -1)
			{
				this.fingerID = ORK.Control.Touch.GetStartWithin(hudContent.box.windowRect);
				if(this.fingerID != -1)
				{
					start = true;
				}
			}
			
			if(this.fingerID != -1)
			{
				Vector2 p = VectorHelper.GetScreenPosition(ORK.Control.Touch.GetPosition(this.fingerID));
				p.x -= hudContent.box.windowRect.x + hudContent.box.Settings.boxPadding.x;
				p.y -= hudContent.box.windowRect.y + hudContent.box.Settings.boxPadding.y;
				
				if(!start || GUIHelper.InGUIRect(p, this.bounds))
				{
					if(HUDControlType.Axis.Equals(this.type) || HUDControlType.Joystick.Equals(this.type))
					{
						p.x -= this.bounds.x;
						p.y -= this.bounds.y;
						if(this.autoRelease && Vector2.Distance(p, this.axisCenter) > this.releaseDist)
						{
							this.fingerID = -1;
						}
					}
					else
					{
						if(this.autoRelB && !GUIHelper.InGUIRect(p, this.bounds))
						{
							this.fingerID = -1;
						}
					}
					
					if(this.fingerID != -1)
					{
						// set down time
						if(ORK.Control.Touch.IsPhase(this.fingerID, InputHandling.Down))
						{
							hudContent.keys[index].SetDownTime();
							if(hudContent.keys2[index] != null)
							{
								hudContent.keys2[index].SetDownTime();
							}
						}
						// release down time
						else if(ORK.Control.Touch.IsPhase(this.fingerID, InputHandling.Up))
						{
							hudContent.keys[index].ReleaseDownTime();
							if(hudContent.keys2[index] != null)
							{
								hudContent.keys2[index].ReleaseDownTime();
							}
						}
						
						// update key input
						if(ORK.Control.Touch.IsPhase(this.fingerID, hudContent.keys[index].handling))
						{
							this.pressed = true;
							this.timeout = this.pTime;
							
							if(HUDControlType.PositiveButton.Equals(this.type))
							{
								hudContent.keys[index].SetAxisHUD(this.invertAxis ? -1 : 1);
							}
							else if(HUDControlType.NegativeButton.Equals(this.type))
							{
								hudContent.keys[index].SetAxisHUD(this.invertAxis ? 1 : -1);
							}
							else if(HUDControlType.Axis.Equals(this.type))
							{
								if(ColumnFill.Horizontal.Equals(this.axisType))
								{
									p.y = this.axisCenter.y;
									this.pOff = Vector2.ClampMagnitude((p - this.axisCenter), this.maxDist);
									this.SetAxis(hudContent.keys[index], 
										Mathf.Min(Vector2.Distance(this.axisCenter, p), this.maxDist) / this.maxDist, 
										this.invertAxis ? this.axisCenter.x - p.x : p.x - this.axisCenter.x);
								}
								else
								{
									p.x = this.axisCenter.x;
									this.pOff = Vector2.ClampMagnitude((p - this.axisCenter), this.maxDist);
									this.SetAxis(hudContent.keys[index], 
										Mathf.Min(Vector2.Distance(this.axisCenter, p), this.maxDist) / this.maxDist, 
										this.invertAxis ? p.y - this.axisCenter.y : this.axisCenter.y - p.y);
								}
							}
							else if(HUDControlType.Joystick.Equals(this.type))
							{
								if(ColumnFill.Horizontal.Equals(this.axisType))
								{
									this.pOff = Vector2.ClampMagnitude((p - this.axisCenter), this.maxDist);
									this.SetAxis(hudContent.keys[index], 
										Mathf.Min(Vector2.Distance(this.axisCenter, new Vector2(p.x, this.axisCenter.y)), this.maxDist) / this.maxDist, 
										this.invertAxis ? this.axisCenter.x - p.x : p.x - this.axisCenter.x);
									this.SetAxis(hudContent.keys2[index], 
										Mathf.Min(Vector2.Distance(this.axisCenter, new Vector2(this.axisCenter.x, p.y)), this.maxDist) / this.maxDist, 
										this.invertAxis2 ? p.y - this.axisCenter.y : this.axisCenter.y - p.y);
								}
								else
								{
									this.pOff = Vector2.ClampMagnitude((p - this.axisCenter), this.maxDist);
									this.SetAxis(hudContent.keys[index], 
										Mathf.Min(Vector2.Distance(this.axisCenter, new Vector2(this.axisCenter.x, p.y)), this.maxDist) / this.maxDist, 
										this.invertAxis ? p.y - this.axisCenter.y : this.axisCenter.y - p.y);
									this.SetAxis(hudContent.keys2[index], 
										Mathf.Min(Vector2.Distance(this.axisCenter, new Vector2(p.x, this.axisCenter.y)), this.maxDist) / this.maxDist, 
										this.invertAxis2 ? this.axisCenter.x - p.x : p.x - this.axisCenter.x);
								}
							}
						}
						
						ORK.Control.Touch.Use(this.fingerID);
						if(ORK.Control.Touch.IsPhase(this.fingerID, InputHandling.Up))
						{
							this.fingerID = -1;
						}
					}
				}
				else
				{
					this.fingerID = -1;
				}
			}
		}
		
		private void SetAxis(InputKey key, float value, float c)
		{
			if(c > 0)
			{
				key.SetAxisHUD(value);
			}
			else
			{
				key.SetAxisHUD(-value);
			}
		}
		
		public bool IsPressed
		{
			get{ return this.timeout > 0 || this.pressed;}
		}
		
		public Vector2 PositionOffset
		{
			get{ return this.pOff;}
		}
		
		public void Show()
		{
			if(this.box)
			{
				GUI.Box(this.bounds, "");
			}
			if(this.showBackground && this.bg != null)
			{
				this.bg.Show(this.bounds.x, this.bounds.y);
			}
			
			GUI.BeginGroup(this.bounds);
			if(this.IsPressed && this.usePressed)
			{
				if(HUDControlType.Axis.Equals(this.type) || HUDControlType.Joystick.Equals(this.type))
				{
					this.pressedImage.Show(new Rect(this.pOff.x + this.pImgBounds.x + this.axisCenter.x, 
						this.pOff.y + this.pImgBounds.y + this.axisCenter.y, 
						this.pImgBounds.width, this.pImgBounds.height));
				}
				else
				{
					this.pressedImage.Show(this.pImgBounds);
				}
			}
			else
			{
				if(HUDControlType.Axis.Equals(this.type) || HUDControlType.Joystick.Equals(this.type))
				{
					this.image.Show(new Rect(this.pOff.x + this.imgBounds.x + this.axisCenter.x, 
						this.pOff.y + this.imgBounds.y + this.axisCenter.y, 
						this.imgBounds.width, this.imgBounds.height));
				}
				else
				{
					this.image.Show(this.imgBounds);
				}
			}
			GUI.EndGroup();
		}
		
		
		/*
		============================================================================
		New UI functions
		============================================================================
		*/
		public void CreateObjects(GUIBox guiBox, GameObject parent)
		{
			if(this.gameObject != null)
			{
				GameObject.Destroy(this.gameObject);
			}
			
			this.gameObject = UIHelper.CreateBaseObject("ControlHUD", this.bounds, parent);
			
			int tmpIndex = 0;
			
			if(this.box && 
				guiBox.Skins.contentBoxPrefab != null)
			{
				UIHelper.InstantiateObject(guiBox.Skins.contentBoxPrefab, 
					"HUD Element Box", 
					new Rect(0, 0, this.bounds.width, this.bounds.height), 
					this.gameObject);
			}
			if(this.showBackground && this.bg != null)
			{
				ImageLabel imgLabel = this.bg.Create(0, 0);
				if(imgLabel != null)
				{
					imgLabel.CreateObject(this.gameObject, null, ref tmpIndex);
				}
			}
			
			GameObject contentObject = UIHelper.CreateBaseObject(
				"HUD Element", 
				new Rect(0, 0, this.bounds.width, this.bounds.height), 
				this.gameObject);
			
			
			// button
			RectTransform buttonRect = null;
			ImageLabel label = null;
			if(HUDControlType.Axis.Equals(this.type) || HUDControlType.Joystick.Equals(this.type))
			{
				label = this.image.Create(new Rect(
					this.pOff.x + this.imgBounds.x + this.axisCenter.x, 
					this.pOff.y + this.imgBounds.y + this.axisCenter.y, 
					this.imgBounds.width, this.imgBounds.height));
			}
			else
			{
				label = this.image.Create(this.imgBounds);
			}
			
			if(label != null)
			{
				tmpIndex = 0;
				List<RectTransform> list = new List<RectTransform>();
				label.CreateObject(contentObject, list, ref tmpIndex);
				if(list.Count > 0)
				{
					buttonRect = list[0];
					if(this.noFlash)
					{
						buttonRect.gameObject.AddComponent<NoFlashComponent>();
					}
				}
			}
			
			// pressed button
			RectTransform pressedRect = null;
			if(this.usePressed)
			{
				label = null;
				if(HUDControlType.Axis.Equals(this.type) || HUDControlType.Joystick.Equals(this.type))
				{
					label = this.pressedImage.Create(new Rect(
						this.pOff.x + this.pImgBounds.x + this.axisCenter.x, 
						this.pOff.y + this.pImgBounds.y + this.axisCenter.y, 
						this.pImgBounds.width, this.pImgBounds.height));
				}
				else
				{
					label = this.pressedImage.Create(this.pImgBounds);
				}
				
				if(label != null)
				{
					tmpIndex = 0;
					List<RectTransform> list = new List<RectTransform>();
					label.CreateObject(contentObject, list, ref tmpIndex);
					if(list.Count > 0)
					{
						pressedRect = list[0];
						pressedRect.gameObject.SetActive(false);
						if(this.noFlash)
						{
							pressedRect.gameObject.AddComponent<NoFlashComponent>();
						}
					}
				}
			}
			
			this.gameObject.AddComponent<ControlHUDElementComponent>().Init(buttonRect, pressedRect, this);
		}
	}
}
