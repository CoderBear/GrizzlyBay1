
using UnityEngine;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDNavigation : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of the HUD element:\n" +
			"- Separation: Displays separations between cardinal directions.\n" +
			"- North: Displays the cardinal direction north.\n" +
			"- East: Displays the cardinal direction east.\n" +
			"- South: Displays the cardinal direction south.\n" +
			"- West: Displays the cardinal direction west.\n" +
			"- Interactions: Displays nearby interactions.\n" +
			"- Combatants: Displays nearby combatants.\n" +
			"- Navigation Marker: Displays set navigation markers (can be set using the event system).", "")]
		public HUDNavigationType type = HUDNavigationType.Separation;
		
		
		// separations
		[ORKEditorHelp("Separations", "The number of separations between two cardinal directions.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", HUDNavigationType.Separation, endCheckGroup=true)]
		[ORKEditorLimit(0, false)]
		public int separations = 1;
		
		
		// interaction settings
		[ORKEditorHelp("Range", "The distance to the player a game object can have to be displayed.", "")]
		[ORKEditorInfo(separator=true, labelText="Interaction Settings")]
		[ORKEditorLayout("type", HUDNavigationType.Interaction)]
		[ORKEditorLimit(0.0f, false)]
		public float rangeInteractions = 30;
		
		// interactions
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public InteractionCheck interaction;
		
		
		// combatants
		[ORKEditorInfo(separator=true, labelText="Combatant Settings")]
		[ORKEditorLayout("type", HUDNavigationType.Combatant, autoInit=true, 
			constTypes=new System.Type[] {typeof(float)}, constValues=new System.Object[] {30.0f})]
		public Range rangeCombatant;
		
		[ORKEditorHelp("Show Faction", "Display's combatant's of a selected faction.\n" +
			"If disabled, you have to define the type of combatant's that will be displayed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool showFaction = false;
		
		[ORKEditorHelp("Faction", "Select the faction that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout("showFaction", true)]
		public int factionID = 0;
		
		[ORKEditorHelp("Combatant Type", "Select which combatant's will be displayed.\n" +
			"- Self: Members of the player group (excluding the played combatant, i.e. the  leader).\n" +
			"- Ally: Combatant's that are allied to the player.\n" +
			"- Enemy: Combatant's that are enemies of the player.\n" +
			"- All: All combatants.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public TargetType combatantType = TargetType.Enemy;
		
		
		// navigation markers
		[ORKEditorHelp("Marker Type", "The type of markers that will be displayed.\n" +
			"This navigation element will only display navigation markers of a matching type.", "")]
		[ORKEditorLayout("type", HUDNavigationType.NavigationMarker, endCheckGroup=true)]
		public string markerType = "";
		
		
		// information
		[ORKEditorInfo(separator=true)]
		[ORKEditorArray(false, "Add Content", "Adds a content label (image or text) to this navigation element.\n" +
			"Use multiple content labels to create more complex information.", "", 
			"Remove", "Removes this content label.", "", isMove=true, isCopy=true, foldout=true, 
			foldoutText=new string[] {"Content Label", "The content (e.g. an image or text).\n" +
				"Use multiple content labels to create more complex information.", ""})]
		[ORKEditorLabel(new string[] {"type", "type", "type"}, 
			new System.Object[] {HUDNavigationType.Interaction, HUDNavigationType.Combatant, HUDNavigationType.NavigationMarker}, 
			"Content Information", "n = name, %d = description, %i = icon", needed=Needed.One, bold=new bool[] {true})]
		public NavigationLabelHUD[] content = new NavigationLabelHUD[0];
		
		
		// position
		[ORKEditorHelp("Show Box", "Shows a box around this element using the style of " +
			"the box defined by the GUISkin of the GUI box.\n" +
			"The position and size of the box is defined by the bounds.", "")]
		[ORKEditorInfo(separator=true, labelText="Element Position")]
		public bool box = false;
		
		[ORKEditorHelp("No Flash", "This element won't flash when the HUD flashes.", "")]
		public bool noFlash = false;
		
		[ORKEditorHelp("Force Size", "The size (width and height of the bounds) will always be used, " +
			"even if the content of the element doesn't need the whole bounds.\n" +
			"If disabled, only the size used by the content is used.\n" +
			"This setting is used for GUI boxes with 'Auto' and 'Scroll' height adjustment.", "")]
		public bool forceSize = false;
		
		[ORKEditorHelp("Outside Bounds", "The element's content can also be displayed outside of it's bounds.\n" +
			"If disabled, the content wont be displayed outside of the element's bounds - " +
			"if content exceeds the bounds, it will be cut off.", "")]
		[ORKEditorLayout("gui:legacy", endCheckGroup=true)]
		public bool outsideBounds = false;
		
		[ORKEditorHelp("Bounds", "The position and size of this element.\n" +
			"The coordinates X=0, Y=0 are located at the position of the selected information in the navigation bar.", "")]
		public Rect bounds = new Rect(0, 0, 300, 100);
		
		
		// background image
		[ORKEditorHelp("Show Background", "Display a background image in this HUD element.", "")]
		[ORKEditorInfo(separator=true, labelText="Background Image")]
		public bool showBackground = false;
		
		[ORKEditorLayout("showBackground", true, autoInit=true)]
		public DisplayImage bg;
		
		[ORKEditorHelp("Expand Bounds", "The background image's bounds will " +
			"expand the element's bounds when exceeding them.", "")]
		[ORKEditorLayout("gui:legacy", endCheckGroup=true, endGroups=2)]
		public bool expandBoundsBG = false;
		
		
		// ingame
		private MultiNavigationHUDContent hudContent;
		
		public HUDNavigation()
		{
			
		}
		
		public void Create(GUIBox box, 
			ref List<KeyValuePair<Vector2, MultiNavigationHUDContent>> list, Transform origin, 
			float y, float halfWidth, float degreeWidth, float northOffset, float forwardOffset, 
			float forward, float left, float right, NavigationHUDContent navHUD)
		{
			// cardinal directions
			if(HUDNavigationType.Separation.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				
				float tmp = 90.0f / (this.separations + 1);
				for(int i=1; i<=this.separations; i++)
				{
					Vector2 pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
					}
					pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + 90 + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
					}
					pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + 180 + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
					}
					pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + 270 + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
					}
				}
			}
			else if(HUDNavigationType.North.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
				}
			}
			else if(HUDNavigationType.East.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset + 90, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
				}
			}
			else if(HUDNavigationType.South.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset + 180, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
				}
			}
			else if(HUDNavigationType.West.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset + 270, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
				}
			}
			// interactions
			else if(HUDNavigationType.Interaction.Equals(this.type))
			{
				if(origin != null)
				{
					List<BaseInteraction> interactions = this.interaction.GetAll();
					if(interactions != null)
					{
						for(int i=0; i<interactions.Count; i++)
						{
							if(interactions[i] != null && 
								interactions[i].CheckConditions() && 
								Vector3.Distance(
									ORK.Game.ActiveGroup.Leader.GameObject.transform.position, 
									interactions[i].transform.position) <= this.rangeInteractions)
							{
								float position = VectorHelper.HorizontalAngle(
									ORK.Game.ActiveGroup.Leader.GameObject.transform, interactions[i].transform);
								if(origin != ORK.Game.ActiveGroup.Leader.GameObject.transform)
								{
									position -= origin.transform.eulerAngles.y - 
										ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
								}
								
								Vector2 pos = new Vector2(0, y);
								if(this.CheckPosition(ref pos, forward + position, halfWidth, degreeWidth, forward, left, right))
								{
									NavHUDComponent navHUDComp = ComponentHelper.Get<NavHUDComponent>(interactions[i].gameObject);
									if(!navHUDComp.HasHUDContent(navHUD))
									{
										IContent info = ComponentHelper.GetContent(interactions[i].gameObject);
										navHUDComp.SetHUDContent(navHUD, this.CreateLabel(box, info));
									}
									list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, navHUDComp.GetHUDContent(navHUD)));
								}
							}
						}
					}
				}
			}
			// combatants
			else if(HUDNavigationType.Combatant.Equals(this.type))
			{
				if(origin != null)
				{
					List<Combatant> combatants = null;
					
					// get combatants
					if(this.showFaction)
					{
						combatants = ORK.Game.Combatants.GetFactionMembers(ORK.Game.ActiveGroup.Leader, 
							this.factionID, true, this.rangeCombatant, Consider.No, Consider.Ignore);
					}
					else if(TargetType.Self.Equals(this.combatantType))
					{
						List<Combatant> tmp = ORK.Game.ActiveGroup.GetGroup();
						for(int i=0; i<tmp.Count; i++)
						{
							if(tmp[i] != null && 
								this.rangeCombatant.InRange(ORK.Game.ActiveGroup.Leader, tmp[i]))
							{
								combatants.Add(tmp[i]);
							}
						}
					}
					else if(TargetType.Ally.Equals(this.combatantType))
					{
						combatants = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
							false, this.rangeCombatant, Consider.No, Consider.No, Consider.Ignore);
					}
					else if(TargetType.Enemy.Equals(this.combatantType))
					{
						combatants = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
							false, this.rangeCombatant, Consider.Yes, Consider.No, Consider.Ignore);
					}
					else if(TargetType.All.Equals(this.combatantType))
					{
						combatants = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
							true, this.rangeCombatant, Consider.Ignore, Consider.No, Consider.Ignore);
					}
					
					if(combatants != null)
					{
						combatants.Remove(ORK.Game.ActiveGroup.Leader);
						for(int i=0; i<combatants.Count; i++)
						{
							float position = VectorHelper.HorizontalAngle(
								ORK.Game.ActiveGroup.Leader.GameObject.transform, combatants[i].GameObject.transform);
							if(origin != ORK.Game.ActiveGroup.Leader.GameObject.transform)
							{
								position -= origin.transform.eulerAngles.y - 
									ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
							}
							
							Vector2 pos = new Vector2(0, y);
							if(this.CheckPosition(ref pos, forward + position, halfWidth, degreeWidth, forward, left, right))
							{
								NavHUDComponent navHUDComp = ComponentHelper.Get<NavHUDComponent>(combatants[i].GameObject);
								if(!navHUDComp.HasHUDContent(navHUD))
								{
									IContent info = ComponentHelper.GetContent(combatants[i].GameObject);
									navHUDComp.SetHUDContent(navHUD, this.CreateLabel(box, info));
								}
								list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, navHUDComp.GetHUDContent(navHUD)));
							}
						}
					}
				}
			}
			// navigation markers
			else if(HUDNavigationType.NavigationMarker.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				if(origin != null)
				{
					List<NavigationMarker> markers = ORK.Game.Scene.GetNavigationMarkers(this.markerType);
					if(markers != null)
					{
						for(int i=0; i<markers.Count; i++)
						{
							for(int j=0; j<markers[i].Count; j++)
							{
								float position = VectorHelper.HorizontalAngle(
									ORK.Game.ActiveGroup.Leader.GameObject.transform, markers[i][j]);
								if(origin != ORK.Game.ActiveGroup.Leader.GameObject.transform)
								{
									position -= origin.transform.eulerAngles.y - 
										ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
								}
								
								Vector2 pos = new Vector2(0, y);
								if(this.CheckPosition(ref pos, forward + position, halfWidth, degreeWidth, forward, left, right))
								{
									list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.hudContent));
								}
							}
						}
					}
				}
			}
		}
		
		public void CreateEditor(GUIBox box, 
			ref List<KeyValuePair<Vector2, MultiNavigationHUDContent>> list, 
			float y, float halfWidth, float degreeWidth, float northOffset, float forwardOffset, 
			float forward, float left, float right)
		{
			// cardinal directions
			if(HUDNavigationType.Separation.Equals(this.type))
			{
				float tmp = 90.0f / (this.separations + 1);
				for(int i=1; i<=this.separations; i++)
				{
					Vector2 pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
					}
					pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + 90 + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
					}
					pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + 180 + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
					}
					pos = new Vector2(0, y);
					if(this.CheckPosition(ref pos, northOffset + 270 + tmp * i, halfWidth, degreeWidth, forward, left, right))
					{
						list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
					}
				}
			}
			else if(HUDNavigationType.North.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
				}
			}
			else if(HUDNavigationType.East.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset + 90, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
				}
			}
			else if(HUDNavigationType.South.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset + 180, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
				}
			}
			else if(HUDNavigationType.West.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, northOffset + 270, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
				}
			}
			// interactions
			else if(HUDNavigationType.Interaction.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, forward + 20, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, ORK.SceneObjects.Get(0))));
				}
			}
			// combatants
			else if(HUDNavigationType.Combatant.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, forward - 20, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, ORK.Combatants.Create(0, null))));
				}
			}
			// navigation markers
			else if(HUDNavigationType.NavigationMarker.Equals(this.type))
			{
				Vector2 pos = new Vector2(0, y);
				if(this.CheckPosition(ref pos, forward - 60, halfWidth, degreeWidth, forward, left, right))
				{
					list.Add(new KeyValuePair<Vector2, MultiNavigationHUDContent>(pos, this.CreateLabel(box, null)));
				}
			}
		}
		
		private MultiNavigationHUDContent CreateLabel(GUIBox box, IContent info)
		{
			List<BaseLabel> label = new List<BaseLabel>();
			for(int i=0; i<this.content.Length; i++)
			{
				this.content[i].Create(ref label, 
					new Rect(0, 0, this.bounds.width, this.bounds.height), 
					info);
			}
			return new MultiNavigationHUDContent(box, this, label, this.bounds);
		}
		
		private bool CheckPosition(ref Vector2 pos, float position, float halfWidth, 
			float degreeWidth, float forward, float left, float right)
		{
			if(position >= left && position <= right)
			{
				pos.x = halfWidth + (degreeWidth * (position - forward));
				return true;
			}
			else if(position - 360 >= left && position - 360 <= right)
			{
				pos.x = halfWidth + (degreeWidth * (position - 360 - forward));
				return true;
			}
			else if(position + 360 >= left && position + 360 <= right)
			{
				pos.x = halfWidth + (degreeWidth * (position + 360 - forward));
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		New UI functions
		============================================================================
		*/
		public void CreateCardinalObjects(GUIBox box, GameObject parent, 
			float y, float northOffset, NavigationHUDContent navHUD)
		{
			if(HUDNavigationType.Separation.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				
				float tmp = 90.0f / (this.separations + 1);
				for(int i=1; i<=this.separations; i++)
				{
					// north
					Vector2 pos = new Vector2(northOffset + tmp * i, y);
					ValueHelper.SecureRotation(ref pos.x);
					this.hudContent.CreateObjects(pos, parent, navHUD);
					
					// east
					pos = new Vector2(northOffset + 90 + tmp * i, y);
					ValueHelper.SecureRotation(ref pos.x);
					this.hudContent.CreateObjects(pos, parent, navHUD);
					
					// south
					pos = new Vector2(northOffset + 180 + tmp * i, y);
					ValueHelper.SecureRotation(ref pos.x);
					this.hudContent.CreateObjects(pos, parent, navHUD);
					
					// west
					pos = new Vector2(northOffset + 270 + tmp * i, y);
					ValueHelper.SecureRotation(ref pos.x);
					this.hudContent.CreateObjects(pos, parent, navHUD);
				}
			}
			else if(HUDNavigationType.North.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				
				Vector2 pos = new Vector2(northOffset, y);
				ValueHelper.SecureRotation(ref pos.x);
				this.hudContent.CreateObjects(pos, parent, navHUD);
			}
			else if(HUDNavigationType.East.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				
				Vector2 pos = new Vector2(northOffset + 90, y);
				ValueHelper.SecureRotation(ref pos.x);
				this.hudContent.CreateObjects(pos, parent, navHUD);
			}
			else if(HUDNavigationType.South.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				
				Vector2 pos = new Vector2(northOffset + 180, y);
				ValueHelper.SecureRotation(ref pos.x);
				this.hudContent.CreateObjects(pos, parent, navHUD);
			}
			else if(HUDNavigationType.West.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				
				Vector2 pos = new Vector2(northOffset + 270, y);
				ValueHelper.SecureRotation(ref pos.x);
				this.hudContent.CreateObjects(pos, parent, navHUD);
			}
		}
		
		public void CreateObjects(GUIBox box, GameObject parent, Transform origin, 
			ref Dictionary<BaseInteraction, NavHUDElementComponent> interactionList, 
			ref Dictionary<Combatant, NavHUDElementComponent> combatantList, 
			ref List<NavigationMarker> markerList, 
			float y, float forward, NavigationHUDContent navHUD)
		{
			// interactions
			if(HUDNavigationType.Interaction.Equals(this.type))
			{
				Dictionary<BaseInteraction, NavHUDElementComponent> controlList = new 
					Dictionary<BaseInteraction, NavHUDElementComponent>(interactionList);
				if(origin != null)
				{
					List<BaseInteraction> interactions = this.interaction.GetAll();
					if(interactions != null)
					{
						for(int i=0; i<interactions.Count; i++)
						{
							if(interactions[i] != null)
							{
								if(interactions[i].CheckConditions() && 
									Vector3.Distance(
										ORK.Game.ActiveGroup.Leader.GameObject.transform.position, 
										interactions[i].transform.position) <= this.rangeInteractions)
								{
									float position = VectorHelper.HorizontalAngle(
										ORK.Game.ActiveGroup.Leader.GameObject.transform, interactions[i].transform);
									if(origin != ORK.Game.ActiveGroup.Leader.GameObject.transform)
									{
										position -= origin.transform.eulerAngles.y - 
											ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
									}
									
									Vector2 pos = new Vector2(forward + position, y);
									ValueHelper.SecureRotation(ref pos.x);
									
									if(interactionList.ContainsKey(interactions[i]))
									{
										if(interactionList[interactions[i]] != null)
										{
											interactionList[interactions[i]].degreePosition = pos.x;
											interactionList[interactions[i]].IsVisible = true;
											controlList.Remove(interactions[i]);
										}
									}
									else
									{
										NavHUDComponent navHUDComp = ComponentHelper.Get<NavHUDComponent>(interactions[i].gameObject);
										if(!navHUDComp.HasHUDContent(navHUD))
										{
											IContent info = ComponentHelper.GetContent(interactions[i].gameObject);
											navHUDComp.SetHUDContent(navHUD, this.CreateLabel(box, info));
										}
										interactionList.Add(interactions[i], 
											navHUDComp.GetHUDContent(navHUD).CreateObjects(pos, parent, navHUD));
									}
								}
								else if(interactionList.ContainsKey(interactions[i]) && 
									interactionList[interactions[i]] != null)
								{
									interactionList[interactions[i]].IsVisible = false;
									controlList.Remove(interactions[i]);
								}
							}
						}
					}
				}
				if(controlList.Count > 0)
				{
					foreach(KeyValuePair<BaseInteraction, NavHUDElementComponent> pair in controlList)
					{
						if(pair.Value != null)
						{
							GameObject.Destroy(pair.Value.gameObject);
						}
						interactionList.Remove(pair.Key);
					}
				}
			}
			// combatants
			else if(HUDNavigationType.Combatant.Equals(this.type))
			{
				Dictionary<Combatant, NavHUDElementComponent> controlList = new 
					Dictionary<Combatant, NavHUDElementComponent>(combatantList);
				if(origin != null)
				{
					List<Combatant> combatants = null;
					
					// get combatants
					if(this.showFaction)
					{
						combatants = ORK.Game.Combatants.GetFactionMembers(ORK.Game.ActiveGroup.Leader, 
							this.factionID, true, this.rangeCombatant, Consider.No, Consider.Ignore);
					}
					else if(TargetType.Self.Equals(this.combatantType))
					{
						List<Combatant> tmp = ORK.Game.ActiveGroup.GetGroup();
						for(int i=0; i<tmp.Count; i++)
						{
							if(tmp[i] != null && 
								this.rangeCombatant.InRange(ORK.Game.ActiveGroup.Leader, tmp[i]))
							{
								combatants.Add(tmp[i]);
							}
						}
					}
					else if(TargetType.Ally.Equals(this.combatantType))
					{
						combatants = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
							false, this.rangeCombatant, Consider.No, Consider.No, Consider.Ignore);
					}
					else if(TargetType.Enemy.Equals(this.combatantType))
					{
						combatants = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
							false, this.rangeCombatant, Consider.Yes, Consider.No, Consider.Ignore);
					}
					else if(TargetType.All.Equals(this.combatantType))
					{
						combatants = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
							true, this.rangeCombatant, Consider.Ignore, Consider.No, Consider.Ignore);
					}
					
					if(combatants != null)
					{
						combatants.Remove(ORK.Game.ActiveGroup.Leader);
						for(int i=0; i<combatants.Count; i++)
						{
							float position = VectorHelper.HorizontalAngle(
								ORK.Game.ActiveGroup.Leader.GameObject.transform, combatants[i].GameObject.transform);
							if(origin != ORK.Game.ActiveGroup.Leader.GameObject.transform)
							{
								position -= origin.transform.eulerAngles.y - 
									ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
							}
							
							Vector2 pos = new Vector2(forward + position, y);
							ValueHelper.SecureRotation(ref pos.x);
							
							if(combatantList.ContainsKey(combatants[i]))
							{
								if(combatantList[combatants[i]] != null)
								{
									combatantList[combatants[i]].degreePosition = pos.x;
									combatantList[combatants[i]].IsVisible = true;
									controlList.Remove(combatants[i]);
								}
							}
							else
							{
								NavHUDComponent navHUDComp = ComponentHelper.Get<NavHUDComponent>(combatants[i].GameObject);
								if(!navHUDComp.HasHUDContent(navHUD))
								{
									IContent info = ComponentHelper.GetContent(combatants[i].GameObject);
									navHUDComp.SetHUDContent(navHUD, this.CreateLabel(box, info));
								}
								combatantList.Add(combatants[i], 
									navHUDComp.GetHUDContent(navHUD).CreateObjects(pos, parent, navHUD));
							}
						}
					}
				}
				if(controlList.Count > 0)
				{
					foreach(KeyValuePair<Combatant, NavHUDElementComponent> pair in controlList)
					{
						if(pair.Value != null)
						{
							GameObject.Destroy(pair.Value.gameObject);
						}
						combatantList.Remove(pair.Key);
					}
				}
			}
			// navigation markers
			else if(HUDNavigationType.NavigationMarker.Equals(this.type))
			{
				if(this.hudContent == null)
				{
					this.hudContent = this.CreateLabel(box, null);
				}
				List<NavigationMarker> controlList = new List<NavigationMarker>(markerList);
				if(origin != null)
				{
					List<NavigationMarker> markers = ORK.Game.Scene.GetNavigationMarkers(this.markerType);
					if(markers != null)
					{
						for(int i=0; i<markers.Count; i++)
						{
							markers[i].CheckHUDList();
							if(!markerList.Contains(markers[i]))
							{
								markerList.Add(markers[i]);
							}
							else
							{
								controlList.Remove(markers[i]);
							}
							
							for(int j=0; j<markers[i].Count; j++)
							{
								float position = VectorHelper.HorizontalAngle(
									ORK.Game.ActiveGroup.Leader.GameObject.transform, markers[i][j]);
								if(origin != ORK.Game.ActiveGroup.Leader.GameObject.transform)
								{
									position -= origin.transform.eulerAngles.y - 
										ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
								}
								
								Vector2 pos = new Vector2(forward + position, y);
								ValueHelper.SecureRotation(ref pos.x);
								
								if(j < markers[i].HUDList.Count)
								{
									if(markers[i].HUDList[j] != null)
									{
										markers[i].HUDList[j].degreePosition = pos.x;
										markers[i].HUDList[j].IsVisible = true;
									}
								}
								else
								{
									markers[i].HUDList.Add(this.hudContent.CreateObjects(pos, parent, navHUD));
								}
							}
						}
					}
				}
				if(controlList.Count > 0)
				{
					for(int i=0; i<controlList.Count; i++)
					{
						controlList[i].ClearHUDList();
						markerList.Remove(controlList[i]);
					}
				}
			}
		}
	}
}
