
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class ShortcutSlotText : BaseData
	{
		[ORKEditorHelp("Position", "Set the X and Y position of the info label within a shortcut's bounds.", "")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Anchor", "Select the anchor of the info label.\n" +
			"E.g. 'Upper Left' will place the upper left corner of the info label at the defined position, " +
			"'Lower Right' will place the lower right corner of the image at the defind position.", "")]
		public TextAnchor anchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the shortcut's bounds the info label will be relative to.", "")]
		public TextAnchor relativeTo = TextAnchor.UpperLeft;
		
		
		// size
		[ORKEditorHelp("Set Size", "Set the size of this info label.\n" +
			"If disabled, the info label will use the size of the cell.", "")]
		[ORKEditorInfo(separator=true)]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "Define the width (X) and height (Y) of the info label.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(50, 50);
		
		
		// icon
		[ORKEditorHelp("Use Icon", "Use the icon of the shortcut.\n" +
			"While you can also use the '%i' text code to display the icon of the shortcut in the text, " +
			"enabling this option will give additional control over the icon display.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useIcon = false;
		
		[ORKEditorHelp("Scale Mode", "How to scale the icon to the used bounds.", "")]
		[ORKEditorLayout("useIcon", true)]
		public ScaleMode scaleMode = ScaleMode.StretchToFill;
		
		[ORKEditorHelp("Alpha Blend", "Whether to alpha blend the icon on to the display (the default).\n" +
			"If false, the picture is drawn on to the display.", "")]
		public bool alphaBlend = true;
		
		[ORKEditorHelp("Image Aspect", "Aspect ratio to use for the source image.\n" +
			"If 0 (the default), the aspect ratio from the image is used. Pass in w/h for the desired aspect ratio.\n" +
			"This allows the aspect ratio of the source image to be adjusted without changing the pixel width and height.", "")]
		public float imageAspect = 0;
		
		// text
		[ORKEditorInfo(separator=true, 
			label=new string[] {"%n = name, %d = description, %i = icon, % = info (quantity, use costs), %s = slot index"})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public StatusTextHUD text = new StatusTextHUD();
		
		public ShortcutSlotText()
		{
			
		}
		
		public void Create(ref List<BaseLabel> label, Combatant combatant, IShortcut shortcut, Rect bounds, int index)
		{
			if(this.useIcon)
			{
				if(shortcut != null)
				{
					Texture2D icon = shortcut.GetIcon();
					if(icon != null)
					{
						ImageLabel image = new ImageLabel(icon, 
							this.setSize ? new Rect(bounds.x, bounds.y, this.size.x, this.size.y) : bounds, 
							this.scaleMode, this.alphaBlend, this.imageAspect);
						
						// move to anchor positions
						Rect tmpBounds = new Rect(
							this.position.x, this.position.y, 
							image.bounds.width, image.bounds.height);
						Vector2 tmp = GUIHelper.GetRectAnchor(bounds, this.relativeTo);
						tmpBounds.x += (tmp.x - bounds.x);
						tmpBounds.y += (tmp.y - bounds.y);
						GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
						image.ChangeX(tmpBounds.x);
						image.ChangeY(tmpBounds.y);
						
						label.Add(image);
					}
				}
			}
			else
			{
				MultiContent mc = new MultiContent(
					TextHelper.ReplaceSpecials(this.GetText(combatant, shortcut, 
						this.text.text[ORK.Game.Language], index)), 
					null, null, this.setSize ? new Rect(bounds.x, bounds.y, this.size.x, this.size.y) : bounds, 
					this.text.lineSpacing, this.text.alignment, this.text.vAlignment, 
					this.setSize ? BoxHeightAdjustment.None : BoxHeightAdjustment.Auto, 
					false, this.text.textFormat);
				
				// move to anchor positions
				Rect tmpBounds = new Rect(
					this.position.x, this.position.y, 
					mc.bounds.width - bounds.x, mc.bounds.height - bounds.y);
				Vector2 tmp = GUIHelper.GetRectAnchor(bounds, this.relativeTo);
				tmpBounds.x += (tmp.x - bounds.x);
				tmpBounds.y += (tmp.y - bounds.y);
				GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
				mc.ChangePosition(tmpBounds.x, tmpBounds.y);
				
				label.AddRange(mc.label);
			}
		}
		
		private string GetText(Combatant combatant, IShortcut shortcut, string text, int index)
		{
			return shortcut != null ? 
				text.Replace("%n", shortcut.GetName()).
					Replace("%d", shortcut.GetDescription()).
					Replace("%i", shortcut.GetIconTextCode()).
					Replace("%s", index.ToString()).
					Replace("%", shortcut.GetInfo(combatant)) : 
				text.Replace("%n", "").
					Replace("%d", "").
					Replace("%i", "").
					Replace("%s", index.ToString()).
					Replace("%", "");
		}
	}
}
