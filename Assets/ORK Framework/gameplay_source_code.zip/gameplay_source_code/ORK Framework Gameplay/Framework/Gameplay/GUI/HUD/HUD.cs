
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUD
	{
		private HUDSetting settings;
		
		private List<GUIBox> box = new List<GUIBox>();
		
		
		// display toggle
		private bool displaying = false;
		
		private bool resetIndividual = false;
		
		// key toggle
		private bool toggle = true;
		
		// external visibility toggle
		public bool visible = true;
		
		// display at object position
		private GameObject displayObject;
		
		public HUD(HUDSetting hs)
		{
			this.settings = hs;
			this.toggle = this.settings.toggleStartState;
			this.AddBox();
			
			// register turn order update
			if(HUDType.TurnOrder.Equals(this.settings.type))
			{
				ORK.BattleSystem.turnBased.UpdateHUD += this.UpdateTurnOrder;
			}
		}
		
		public HUDSetting Settings
		{
			get{ return this.settings;}
		}
		
		public bool ResetIndividual
		{
			get{ return this.displaying && this.resetIndividual;}
		}
		
		public bool Displaying
		{
			get{ return this.displaying;}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private void AddBox()
		{
			GUIBox b = ORK.GUIBoxes.Create(this.settings.guiBoxID);
			b.inPause = true;
			b.controlable = HUDType.Console.Equals(this.settings.type);
			b.focusable = false;
			b.hidden = this.settings.hideEmptyHUD;
			b.Content = this.settings.Create();
			b.Content.SetName(this.GetTitle(null));
			
			this.box.Add(b);
			
			if(this.displaying)
			{
				b.Reset();
				b.InitIn();
			}
		}
		
		private string GetTitle(Combatant c)
		{
			if(this.settings.useTitle)
			{
				if(this.settings.titleName)
				{
					if(c != null)
					{
						return c.GetName();
					}
				}
				else
				{
					return this.settings.title[ORK.Game.Language];
				}
			}
			return "";
		}
		
		public void UpdateTurnOrder()
		{
			if(HUDType.TurnOrder.Equals(this.settings.type))
			{
				List<Combatant> list = ORK.BattleSystem.turnBased.GetTurnOrder(
					this.settings.limitTurnOrder ? this.settings.turnOrderLimit : -1);
				if(this.settings.invertGroup)
				{
					list.Reverse();
				}
				this.SetCombatants(list);
			}
		}
		
		public void SetCombatants(List<Combatant> list)
		{
			if((HUDType.Combatant.Equals(this.settings.type) && 
				CombatantScope.Group.Equals(this.settings.comScope)) || 
				HUDType.TurnOrder.Equals(this.settings.type))
			{
				// remove unused boxes
				if(list.Count < this.box.Count)
				{
					for(int i=this.box.Count-1; i>list.Count-1; i--)
					{
						if(this.displaying)
						{
							this.box[i].InitOut();
						}
						this.box.RemoveAt(i);
					}
				}
				// add needed boxes
				else if(list.Count > this.box.Count)
				{
					for(int i=this.box.Count; i<list.Count; i++)
					{
						this.AddBox();
					}
				}
				// update combatants
				for(int i=0; i<list.Count; i++)
				{
					((PrecalcHUDContent)this.box[i].Content).Combatant = list[i];
					((PrecalcHUDContent)this.box[i].Content).SetName(this.GetTitle(list[i]));
					
					if(i > 0)
					{
						if(this.settings.isRelativeComOff)
						{
							this.box[i].BaseOffset = this.settings.comOff;
							this.box[i].SetRelativeTo(this.box[i - 1], this.settings.comOffRelativeTo);
						}
						else
						{
							this.box[i].BaseOffset = this.settings.comOff * i;
						}
					}
				}
			}
		}
		
		public void SetCombatant(Combatant c)
		{
			if(HUDType.Combatant.Equals(this.settings.type) && 
				CombatantScope.Individual.Equals(this.settings.comScope))
			{
				((PrecalcHUDContent)this.box[0].Content).Combatant = c;
				((PrecalcHUDContent)this.box[0].Content).SetName(this.GetTitle(c));
				if(c.GameObject != null)
				{
					this.SetTargetObject(TransformHelper.GetChildObject(this.settings.childName, c.GameObject));
				}
				else
				{
					this.SetTargetObject(null);
				}
				this.resetIndividual = false;
			}
		}
		
		public void SetTargetObject(GameObject obj)
		{
			this.displayObject = obj;
		}
		
		public bool CheckCursorOver()
		{
			if(HUDType.Combatant.Equals(this.settings.type) && 
				CombatantScope.Individual.Equals(this.settings.comScope) && 
				this.settings.curOver)
			{
				return this.displayObject != null && ORK.GUI.CursorTransform != null && 
					this.displayObject.transform.root == ORK.GUI.CursorTransform.root;
			}
			else
			{
				return true;
			}
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void Tick()
		{
			if(ORK.Game.Running && this.visible && 
				this.settings.IsVisible() && this.CheckCursorOver())
			{
				// toggle key
				if(this.settings.useKey)
				{
					if(this.settings.onlyWhileKey)
					{
						if(this.settings.toggleStartState)
						{
							this.toggle = ORK.InputKeys.Get(this.settings.keyID).GetButton();
						}
						else
						{
							this.toggle = !ORK.InputKeys.Get(this.settings.keyID).GetButton();
						}
					}
					else if(ORK.InputKeys.Get(this.settings.keyID).GetButton())
					{
						this.toggle = !this.toggle;
					}
				}
				
				// show if toggled on
				if(this.toggle)
				{
					// display at object position
					if(this.displayObject != null)
					{
						for(int i=0; i<this.box.Count; i++)
						{
							this.box[i].BaseOffset = this.settings.comPosOff;
							this.box[i].AtObject = this.displayObject;
						}
					}
					
					if(HUDType.Combatant.Equals(this.settings.type))
					{
						if(CombatantScope.Group.Equals(this.settings.comScope))
						{
							List<Combatant> list = new List<Combatant>();
							Combatant player = ORK.Game.ActiveGroup.Leader;
							if(player != null)
							{
								// player group
								if(this.settings.player)
								{
									if(this.settings.onlyLeader)
									{
										if(StatusRequirement.Check(player, this.settings.statusRequirement, this.settings.needed))
										{
											list.Add(player);
										}
									}
									else
									{
										List<Combatant> tmp = player.Group.GetBattle();
										for(int i=0; i<tmp.Count; i++)
										{
											if(StatusRequirement.Check(tmp[i], this.settings.statusRequirement, this.settings.needed))
											{
												list.Add(tmp[i]);
											}
										}
									}
								}
								// ally groups
								if(this.settings.ally)
								{
									List<Combatant> tmp = ORK.Game.Combatants.Get(player, true, Range.Infinity, 
										Consider.No, Consider.Ignore, Consider.Ignore);
									if(this.settings.onlyLeader)
									{
										for(int i=0; i<tmp.Count; i++)
										{
											if(tmp[i] != null && tmp[i].Group != null && 
												!list.Contains(tmp[i].Group.Leader) && 
												StatusRequirement.Check(tmp[i].Group.Leader, 
													this.settings.statusRequirement, this.settings.needed))
											{
												list.Add(tmp[i].Group.Leader);
											}
										}
									}
									else
									{
										for(int i=0; i<tmp.Count; i++)
										{
											if(tmp[i] != null && 
												StatusRequirement.Check(tmp[i], 
													this.settings.statusRequirement, this.settings.needed))
											{
												list.Add(tmp[i]);
											}
										}
									}
								}
								// enemy groups
								if(this.settings.enemy)
								{
									List<Combatant> tmp = ORK.Game.Combatants.Get(player, true, Range.Infinity, 
										Consider.Yes, Consider.Ignore, Consider.Ignore);
									if(this.settings.onlyLeader)
									{
										for(int i=0; i<tmp.Count; i++)
										{
											if(tmp[i] != null && tmp[i].Group != null && 
												!list.Contains(tmp[i].Group.Leader) && 
												StatusRequirement.Check(tmp[i].Group.Leader, 
													this.settings.statusRequirement, this.settings.needed))
											{
												list.Add(tmp[i].Group.Leader);
											}
										}
									}
									else
									{
										for(int i=0; i<tmp.Count; i++)
										{
											if(tmp[i] != null && 
												StatusRequirement.Check(tmp[i], 
													this.settings.statusRequirement, this.settings.needed))
											{
												list.Add(tmp[i]);
											}
										}
									}
								}
							}
							
							if(this.settings.invertGroup)
							{
								list.Reverse();
							}
							
							if(this.settings.groupStartOffset > 0)
							{
								if(this.settings.groupStartOffset >= list.Count)
								{
									list.Clear();
								}
								else
								{
									list.RemoveRange(0, this.settings.groupStartOffset);
								}
							}
							if(this.settings.groupLimitDisplay && 
								list.Count > this.settings.groupMaximumLength)
							{
								list.RemoveRange(this.settings.groupMaximumLength, list.Count - this.settings.groupMaximumLength);
							}
							this.SetCombatants(list);
						}
					}
					if(!this.displaying)
					{
						this.displaying = true;
						for(int i=0; i<this.box.Count; i++)
						{
							this.box[i].Reset();
							this.box[i].InitIn();
						}
					}
				}
				// close if toggled off
				else if(this.displaying)
				{
					this.CloseHUD();
				}
			}
			else if(this.displaying)
			{
				this.CloseHUD();
			}
		}
		
		public void CloseHUD()
		{
			this.displaying = false;
			this.resetIndividual = true;
			for(int i=0; i<this.box.Count; i++)
			{
				this.box[i].InitOut();
			}
		}
	}
}
