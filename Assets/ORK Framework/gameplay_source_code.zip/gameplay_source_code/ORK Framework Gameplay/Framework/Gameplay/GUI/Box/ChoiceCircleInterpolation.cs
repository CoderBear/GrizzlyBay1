
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChoiceCircleInterpolation : BaseData
	{
		[ORKEditorHelp("Fade Time (s)", "The time in seconds used to fade to the new circle position.", "")]
		public float time = 0.3f;
		
		[ORKEditorHelp("Interpolation", "The interpolation used to fade the circle positions.", "")]
		public EaseType interpolation = EaseType.Linear;
		
		[ORKEditorHelp("Block Input", "The choice rotation fade will block input to the GUI box while rotating.", "")]
		public bool block = false;
		
		
		// in-game
		private Function fade;
		
		private float time2 = 0;
		
		private float offset = 0;
		
		private float start = 0;
		
		private float distance = 0;
		
		public ChoiceCircleInterpolation()
		{
			
		}
		
		public float Offset
		{
			get{ return this.offset;}
		}
		
		public void Start(float start, float distance)
		{
			this.time2 = 0;
			this.offset = start;
			this.start = start;
			this.distance = distance;
			
			if(this.fade == null)
			{
				this.fade = Interpolate.Ease(this.interpolation);
			}
		}
		
		public bool Tick()
		{
			if(this.fade != null)
			{
				this.time2 += ORK.Core.GUITimeDelta;
				this.offset = Interpolate.Ease(this.fade, this.start, this.distance, this.time2, this.time);
				return this.time2 >= this.time;
			}
			else
			{
				return true;
			}
		}
	}
}
