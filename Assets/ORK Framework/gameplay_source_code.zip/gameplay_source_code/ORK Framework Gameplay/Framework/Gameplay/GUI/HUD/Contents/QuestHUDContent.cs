
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class QuestHUDContent : GUIBoxContent
	{
		private HUDQuest[] element;
		
		private HUDSetting hudSetting;
		
		
		// created content
		private List<MultiQuestHUDContent> content;
		
		private bool autoUpdate = false;
		
		private float updateInterval = 0;
		
		private float updateTime = 0;
		
		private bool markUpdate = false;
		
		
		// new UI
		private GameObject bgObject;
		
		private GameObject fgObject;
		
		public QuestHUDContent(HUDSetting setting)
		{
			this.hudSetting = setting;
			
			if(HUDType.Quest.Equals(setting.type))
			{
				this.element = setting.questElement;
				if(ORK.Game != null && ORK.Game.Quests != null)
				{
					ORK.Game.Quests.Changed += this.Recalculate;
				}
			}
			
			this.newContent = true;
		}
		
		public override void Clear()
		{
			base.Clear();
			if(this.bgObject != null)
			{
				GameObject.Destroy(this.bgObject);
			}
			if(this.fgObject != null)
			{
				GameObject.Destroy(this.fgObject);
			}
		}

		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(this.autoUpdate)
				{
					this.updateTime -= ORK.Core.GUITimeDelta;
					if(this.updateTime <= 0)
					{
						this.markUpdate = true;
						this.updateTime = this.updateInterval;
					}
				}
				
				if(this.markUpdate)
				{
					this.newContent = true;
					this.markUpdate = false;
				}
				
				// interface tick
				if(this.box.Controlable && this.controlInterface != null && this.box.Focused)
				{
					this.controlInterface.Tick(this.box);
				}
			}
		}
		
		public override void Closed()
		{
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		public void SetAutoUpdate(float interval)
		{
			this.autoUpdate = interval > 0;
			this.updateInterval = interval;
			this.updateTime = interval;
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent)
			{
				this.box = box;
				this.newContent = false;
				this.markUpdate = false;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			this.content = new List<MultiQuestHUDContent>();
			
			float contentHeight = 0;
			
			bool any = false;
			if(this.element != null)
			{
				for(int i=0; i<this.element.Length; i++)
				{
					MultiQuestHUDContent mhc = new MultiQuestHUDContent(this.element[i], 
						ORK.Game.ActiveGroup.Leader);
					
					if(mhc.label != null || (this.hudSetting != null && this.hudSetting.emptyElements))
					{
						any = true;
						if(contentHeight < this.element[i].bounds.y + mhc.bounds.height)
						{
							contentHeight = this.element[i].bounds.y + mhc.bounds.height;
						}
						
						this.content.Add(mhc);
					}
				}
			}
			
			if(this.hudSetting != null && this.hudSetting.hideEmptyHUD)
			{
				this.box.hidden = !any;
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.UpdatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				// display content
				for(int i=0; i<this.content.Count; i++)
				{
					this.content[i].CreateObjects(this.box, parent, this.labelObject, ref index);
				}
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
				
				// background image
				if(this.hudSetting != null && this.bgObject == null && 
					this.hudSetting.showBackground && this.hudSetting.bgImage != null)
				{
					this.bgObject = this.CreateImage(this.hudSetting.bgImage, 
						this.hudSetting.bgRelative, this.hudSetting.bgRelativeTo, 0);
				}
				// foreground image
				if(this.hudSetting != null && this.fgObject == null && 
					this.hudSetting.showForeground && this.hudSetting.fgImage != null)
				{
					this.fgObject = this.CreateImage(this.hudSetting.fgImage, 
						this.hudSetting.fgRelative, this.hudSetting.fgRelativeTo, 1);
				}
			}
		}
		
		public void Recalculate()
		{
			this.markUpdate = true;
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			// background image
			if(this.hudSetting != null && 
				this.hudSetting.showBackground && this.hudSetting.bgImage != null)
			{
				if(this.hudSetting.bgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.bgRelativeTo);
					this.hudSetting.bgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.bgImage.Show();
				}
			}
		}
		
		public override void ShowAfter()
		{
			// foreground image
			if(this.hudSetting != null && 
				this.hudSetting.showForeground && this.hudSetting.fgImage != null)
			{
				if(this.hudSetting.fgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.fgRelativeTo);
					this.hudSetting.fgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.fgImage.Show();
				}
			}
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.skin.horizontalScrollbar = GUIStyle.none;
				this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
				GUI.BeginGroup(this.scrollRect);
			}
			else
			{
				GUI.BeginGroup(this.contentBounds);
			}
			
			// display content
			for(int i=0; i<this.content.Count; i++)
			{
				// no flash > reset color
				this.box.SetGUIColor(this.content[i].setting.noFlash);
				
				// show
				this.content[i].Show(textStyle);
				this.box.SetGUIColor(false);
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public override ChoiceContent GetDragOnPosition(Vector2 position)
		{
			if(this.content != null)
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				
				for(int i=0; i<this.content.Count; i++)
				{
					ChoiceContent cc = this.content[i].GetDragOnPosition(position);
					if(cc != null)
					{
						return cc;
					}
				}
			}
			return null;
		}
		
		public override bool CheckDrop(DragInfo drag, Vector2 position)
		{
			return false;
		}
		
		public override IContent GetTooltip(Vector2 position)
		{
			if(this.box != null && !this.box.FadingOut)
			{
				position.x -= this.box.windowRect.x + this.box.Settings.boxPadding.x;
				position.y -= this.box.windowRect.y + this.box.Settings.boxPadding.y;
				
				if(this.content != null)
				{
					for(int i=0; i<this.content.Count; i++)
					{
						IContent content = this.content[i].GetTooltip(position);
						if(content != null)
						{
							return content;
						}
					}
				}
			}
			return null;
		}
	}
}
