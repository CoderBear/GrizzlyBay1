
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class NavigationHUDContent : GUIBoxContent
	{
		private HUDSetting hudSetting;
		
		public List<KeyValuePair<Vector2, MultiNavigationHUDContent>> content;
		
		
		// navigation parameters
		public float forwardAngle = 0;
		
		public float rightEnd = 0;
		
		public float leftEnd = 0;
		
		public float oneDegreeWidth = 0;
		
		public float halfWidth = 0;
		
		
		// new UI
		private GameObject bgObject;
		
		private GameObject fgObject;
		
		private GameObject parentObject;
		
		private Dictionary<BaseInteraction, NavHUDElementComponent> interactionList;
		
		private Dictionary<Combatant, NavHUDElementComponent> combatantList;
		
		private List<NavigationMarker> markerList;
		
		public NavigationHUDContent(HUDSetting setting)
		{
			this.hudSetting = setting;
		}
		
		public override void Clear()
		{
			base.Clear();
			if(this.bgObject != null)
			{
				GameObject.Destroy(this.bgObject);
			}
			if(this.fgObject != null)
			{
				GameObject.Destroy(this.fgObject);
			}
			if(this.interactionList != null)
			{
				foreach(KeyValuePair<BaseInteraction, NavHUDElementComponent> pair in this.interactionList)
				{
					if(pair.Value != null)
					{
						GameObject.Destroy(pair.Value.gameObject);
					}
				}
				this.interactionList = null;
			}
			if(this.combatantList != null)
			{
				foreach(KeyValuePair<Combatant, NavHUDElementComponent> pair in this.combatantList)
				{
					if(pair.Value != null)
					{
						GameObject.Destroy(pair.Value.gameObject);
					}
				}
				this.combatantList = null;
			}
			if(this.markerList != null)
			{
				for(int i=0; i<this.markerList.Count; i++)
				{
					this.markerList[i].ClearHUDList();
				}
				this.markerList = null;
			}
		}

		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(ORK.GUI.IsNewUI)
				{
					if(this.hudSetting.navigationElement != null && 
						ORK.Game.ActiveGroup.Leader != null && 
						ORK.Game.ActiveGroup.Leader.GameObject != null)
					{
						Transform transform = null;
						this.forwardAngle = this.hudSetting.navForwardOffset;
						this.rightEnd = this.hudSetting.navDisplayRange / 2;
						this.leftEnd = -this.rightEnd;
						
						if(this.hudSetting.navFromPlayer)
						{
							this.forwardAngle += ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
							transform = ORK.Game.ActiveGroup.Leader.GameObject.transform;
						}
						else if(Camera.main != null)
						{
							this.forwardAngle += Camera.main.transform.eulerAngles.y;
							transform = Camera.main.transform;
						}
						
						this.rightEnd += this.forwardAngle;
						this.leftEnd += this.forwardAngle;
						
						if(this.interactionList == null)
						{
							this.interactionList = new Dictionary<BaseInteraction, NavHUDElementComponent>();
						}
						if(this.combatantList == null)
						{
							this.combatantList = new Dictionary<Combatant, NavHUDElementComponent>();
						}
						if(this.markerList == null)
						{
							this.markerList = new List<NavigationMarker>();
						}
						
						// check objects
						for(int i=0; i<this.hudSetting.navigationElement.Length; i++)
						{
							this.hudSetting.navigationElement[i].CreateObjects(
								this.box, this.parentObject, transform, 
								ref this.interactionList, ref this.combatantList, ref this.markerList, 
								this.hudSetting.navLineY, this.forwardAngle, this);
						}
					}
				}
				else
				{
					this.newContent = true;
				}
				
				// interface tick
				if(this.box.Controlable && this.controlInterface != null && this.box.Focused)
				{
					this.controlInterface.Tick(this.box);
				}
			}
		}
		
		public override void Closed()
		{
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
			if(this.markerList != null)
			{
				for(int i=0; i<this.markerList.Count; i++)
				{
					this.markerList[i].ClearHUDList();
				}
				this.markerList = null;
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.box == null)
			{
				this.box = box;
				this.newContent = false;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			this.content = new List<KeyValuePair<Vector2, MultiNavigationHUDContent>>();
			
			float contentHeight = 0;
			
			if(this.hudSetting.navigationElement != null && 
				ORK.Game.ActiveGroup.Leader != null && 
				ORK.Game.ActiveGroup.Leader.GameObject != null)
			{
				Transform transform = null;
				this.forwardAngle = this.hudSetting.navForwardOffset;
				this.rightEnd = this.hudSetting.navDisplayRange / 2;
				this.leftEnd = -this.rightEnd;
				
				if(this.hudSetting.navFromPlayer)
				{
					this.forwardAngle += ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
					transform = ORK.Game.ActiveGroup.Leader.GameObject.transform;
				}
				else if(Camera.main != null)
				{
					this.forwardAngle += Camera.main.transform.eulerAngles.y;
					transform = Camera.main.transform;
				}
				this.rightEnd += this.forwardAngle;
				this.leftEnd += this.forwardAngle;
				
				this.halfWidth = baseWidth / 2;
				this.oneDegreeWidth = baseWidth / this.hudSetting.navDisplayRange;
				
				for(int i=0; i<this.hudSetting.navigationElement.Length; i++)
				{
					this.hudSetting.navigationElement[i].Create(this.box, 
						ref this.content, transform, this.hudSetting.navLineY, this.halfWidth, this.oneDegreeWidth, 
						this.hudSetting.navNorthOffset, this.hudSetting.navForwardOffset, this.forwardAngle, 
						this.leftEnd, this.rightEnd, this);
				}
			}
			// editor
			else if(!Application.isPlaying)
			{
				this.rightEnd = this.hudSetting.navDisplayRange / 2;
				this.leftEnd = -this.rightEnd;
				this.halfWidth = baseWidth / 2;
				this.oneDegreeWidth = baseWidth / this.hudSetting.navDisplayRange;
				
				for(int i=0; i<this.hudSetting.navigationElement.Length; i++)
				{
					this.hudSetting.navigationElement[i].CreateEditor(this.box, 
						ref this.content, this.hudSetting.navLineY, this.halfWidth, this.oneDegreeWidth, 
						this.hudSetting.navNorthOffset, this.hudSetting.navForwardOffset, 0, this.leftEnd, this.rightEnd);
				}
			}
			
			for(int i=0; i<this.content.Count; i++)
			{
				if(contentHeight < this.content[i].Key.y + this.content[i].Value.bounds.y + this.content[i].Value.bounds.height)
				{
					contentHeight = this.content[i].Key.y + this.content[i].Value.bounds.y + this.content[i].Value.bounds.height;
				}
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				this.parentObject = this.CreatePanel();
				
				// cardinal directions
				for(int i=0; i<this.hudSetting.navigationElement.Length; i++)
				{
					this.hudSetting.navigationElement[i].CreateCardinalObjects(
						this.box, this.parentObject, this.hudSetting.navLineY, 
						this.hudSetting.navNorthOffset, this);
				}
				
				// background image
				if(this.hudSetting != null && this.bgObject == null && 
					this.hudSetting.showBackground && this.hudSetting.bgImage != null)
				{
					this.bgObject = this.CreateImage(this.hudSetting.bgImage, 
						this.hudSetting.bgRelative, this.hudSetting.bgRelativeTo, 0);
				}
				// foreground image
				if(this.hudSetting != null && this.fgObject == null && 
					this.hudSetting.showForeground && this.hudSetting.fgImage != null)
				{
					this.fgObject = this.CreateImage(this.hudSetting.fgImage, 
						this.hudSetting.fgRelative, this.hudSetting.fgRelativeTo, 1);
				}
			}
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			// background image
			if(this.hudSetting != null && 
				this.hudSetting.showBackground && this.hudSetting.bgImage != null)
			{
				if(this.hudSetting.bgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.bgRelativeTo);
					this.hudSetting.bgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.bgImage.Show();
				}
			}
		}
		
		public override void ShowAfter()
		{
			// foreground image
			if(this.hudSetting != null && 
				this.hudSetting.showForeground && this.hudSetting.fgImage != null)
			{
				if(this.hudSetting.fgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.fgRelativeTo);
					this.hudSetting.fgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.fgImage.Show();
				}
			}
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.skin.horizontalScrollbar = GUIStyle.none;
				this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
				GUI.BeginGroup(this.scrollRect);
			}
			else
			{
				GUI.BeginGroup(this.contentBounds);
			}
			
			// display content
			for(int i=0; i<this.content.Count; i++)
			{
				// no flash > reset color
				this.box.SetGUIColor(this.content[i].Value.setting.noFlash);
				
				// show
				this.content[i].Value.ShowAt(this.content[i].Key, textStyle);
				this.box.SetGUIColor(false);
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
			}
		}
	}
}
