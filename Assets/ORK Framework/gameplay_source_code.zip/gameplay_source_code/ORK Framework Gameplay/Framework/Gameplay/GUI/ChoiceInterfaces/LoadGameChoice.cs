
using UnityEngine;
using ORKFramework.Behaviours;
using ORKFramework.Events;
using ORKFramework.Menu;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LoadGameChoice : BaseData, IChoice
	{
		[ORKEditorHelp("GUI Box", "The GUI box used to display the load game dialogue.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("One Box", "Only one box is displayed at a time, i.e. question/info box will be displayed after the load box was closed.\n" +
			"If disabled, the question/info box will be displayed while still showing the load box (and block it).", "")]
		[ORKEditorLayout(new string[] {"useQuestion", "useInfo"}, 
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool oneBox = false;
		
		
		// load
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// cancel
		[ORKEditorHelp("Add Cancel", "A cancel choice is added to the file list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addCancel = true;
		
		[ORKEditorHelp("Cancel First Element", "The cancel choice is the first element in the list.", "")]
		[ORKEditorLayout("addCancel", true, endCheckGroup=true)]
		public bool cancelFirst = false;
		
		// message
		[ORKEditorHelp("Load Text", "The text displayed in the load dialogue.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Load Text")]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// question
		[ORKEditorHelp("Show Question", "Display a question dialogue before loading a selected save game file.", "")]
		[ORKEditorInfo(separator=true, labelText="Load Question Dialogue")]
		public bool useQuestion = true;
		
		[ORKEditorHelp("GUI Box", "The GUI box used to display the load game question.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("useQuestion", true)]
		public int qGuiBoxID = 0;
		
		// title
		[ORKEditorHelp("Show Title (Question)", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useQTitle = false;
		
		[ORKEditorHelp("Title (Question)", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, callbackBefore="label:questioninfo")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useQTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] qTitle;
		
		// message
		[ORKEditorHelp("Question Text", "The text displayed in the load question dialogue.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Question Text", callbackBefore="label:questioninfo")]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(autoInit=true, autoLangSize=true)]
		public string[] qMessage;
		
		// question buttons
		[ORKEditorHelp("Use Choice", "Use a choice to accept or cancel the question, " +
			"the 'Yes' and 'No' options of the choice will be defined here.\n" +
			"If disabled, the 'Ok' and 'Cancel' buttons of the GUI box will be used.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useChoice = false;
		
		// yes button
		[ORKEditorInfo(separator=true, labelText="Yes Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout("useChoice", true, autoInit=true, autoLangSize=true)]
		public LanguageContent[] yesButton;
		
		// no button
		[ORKEditorInfo(separator=true, labelText="No Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public LanguageContent[] noButton;
		
		
		// loaded info
		[ORKEditorHelp("Show Loaded Info", "Display a information dialogue after the save game has been loaded.", "")]
		[ORKEditorInfo(separator=true, labelText="Loaded Info Dialogue")]
		public bool useInfo = true;
		
		[ORKEditorHelp("GUI Box", "The GUI box used to display the game loaded info.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("useInfo", true)]
		public int iGuiBoxID = 0;
		
		// title
		[ORKEditorHelp("Show Title (Info)", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useITitle = false;
		
		[ORKEditorHelp("Title (Info)", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, callbackBefore="label:questioninfo")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useITitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] iTitle;
		
		// message
		[ORKEditorHelp("Info Text", "The text displayed in the game loaded dialogue.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Info Text", callbackBefore="label:questioninfo")]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] iMessage;
		
		
		// bg image
		[ORKEditorHelp("Own Background", "Override the default save menu background image settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Background Image")]
		public bool ownBG = false;
		
		[ORKEditorLayout("ownBG", true, endCheckGroup=true, autoInit=true)]
		[ORKEditorArray(false, "Add Background", "Adds a background image.", "", 
			"Remove", "Removes this background image.", "", foldout=true, 
			foldoutText=new string[] {"Background Image", "Define the background image that will be displayed.", ""})]
		public BackgroundImage[] background;
		
		
		// ingame
		private GUIBox[] bgBox;
		
		private GUIBox box;
		
		private GUIBox qBox;
		
		private GUIBox iBox;
		
		private bool backFlag = false;
		
		private ChoiceContent[] fileChoice;
		
		private int[] action;
		
		private ChoiceContent[] qChoice;
		
		private int file = -2;
		
		
		// back
		private IChoiceSimple backOption;
		
		private IEventStarter starter;
		
		private SceneChanger changer;
		
		public LoadGameChoice()
		{
			
		}
		
		private string GetFileNumber()
		{
			if(this.file <= SaveGameHandler.AUTOSAVE_INDEX)
			{
				return ORK.SaveGameMenu.GetAutoName(Mathf.Abs(this.file + 2));
			}
			return (this.file + 1).ToString();
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return this.qBox == origin || this.iBox == origin;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return this.qBox == origin;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void LoadSaveGame(SceneChanger changer)
		{
			if(this.useInfo)
			{
				this.changer = changer;
				this.iBox = ORK.GUIBoxes.Create(this.iGuiBoxID);
				this.iBox.Content = new DialogueContent(
					this.iMessage[ORK.Game.Language].Replace("%", this.GetFileNumber()), 
					this.useITitle ? this.iTitle[ORK.Game.Language].Replace("%", this.GetFileNumber()) : "", 
					null, this);
				if(this.backOption != null && this.backOption is MenuScreen)
				{
					this.iBox.inPause = ((MenuScreen)this.backOption).pauseGame;
				}
				this.iBox.InitIn();
				ORK.GUI.FocusBlocked = true;
			}
			else if(this.box != null)
			{
				this.changer = changer;
				this.box.InitOut();
				if(this.bgBox != null)
				{
					for(int i=0; i<this.bgBox.Length; i++)
					{
						if(this.bgBox[i] != null)
						{
							this.bgBox[i].InitOut();
							this.bgBox[i] = null;
						}
					}
					this.bgBox = null;
				}
			}
			else
			{
				if(this.bgBox != null)
				{
					for(int i=0; i<this.bgBox.Length; i++)
					{
						if(this.bgBox[i] != null)
						{
							this.bgBox[i].InitOut();
							this.bgBox[i] = null;
						}
					}
					this.bgBox = null;
				}
				changer.StartEvent(null);
			}
		}
		
		private void ShowQuestion()
		{
			if(this.useQuestion)
			{
				if(this.useChoice)
				{
					this.qChoice = new ChoiceContent[2];
					this.qChoice[0] = this.yesButton[ORK.Game.Language].GetChoiceContent();
					this.qChoice[1] = this.noButton[ORK.Game.Language].GetChoiceContent();
				}
				else
				{
					this.qChoice = null;
				}
				
				this.qBox = ORK.GUIBoxes.Create(this.qGuiBoxID);
				this.qBox.Content = new DialogueContent(
					this.qMessage[ORK.Game.Language].Replace("%", this.GetFileNumber()), 
					this.useQTitle ? this.qTitle[ORK.Game.Language].Replace("%", this.GetFileNumber()) : "", 
					this.qChoice, this);
				if(this.backOption != null && this.backOption is MenuScreen)
				{
					this.qBox.inPause = ((MenuScreen)this.backOption).pauseGame;
				}
				this.qBox.InitIn();
				ORK.GUI.FocusBlocked = true;
			}
			else
			{
				ORK.SaveGame.Load(this.file);
			}
		}
		
		public void Show(IChoiceSimple back, IEventStarter starter)
		{
			this.backOption = back;
			this.starter = starter;
			ORK.Control.SetMenuBlock(1);
			this.Show();
		}
		
		public void Show()
		{
			ORK.Menu.ShowGeneralSaveBG();
			
			if(this.ownBG && this.background != null && this.background.Length > 0)
			{
				this.bgBox = new GUIBox[this.background.Length];
				for(int i=0; i<this.bgBox.Length; i++)
				{
					this.bgBox[i] = this.background[i].Init();
				}
			}
			else if(!this.ownBG && ORK.MenuSettings.defaultSaveBG.Length > 0)
			{
				this.bgBox = new GUIBox[ORK.MenuSettings.defaultSaveBG.Length];
				for(int i=0; i<this.bgBox.Length; i++)
				{
					this.bgBox[i] = ORK.MenuSettings.defaultSaveBG[i].Init();
				}
			}
			
			this.ShowList();
		}
		
		private void ShowList()
		{
			// create choices
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			
			ORK.SaveGame.GetFileList(true, ref cc, ref ca, this.addCancel, this.cancelFirst);
			
			this.fileChoice = cc.ToArray();
			this.action = ca.ToArray();
			
			// find selection
			int sel = 0;
			
			for(int i=0; i<this.action.Length; i++)
			{
				if(this.action[i] == this.file)
				{
					sel = i;
					break;
				}
			}
			
			// show box
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.Content = new DialogueContent(this.message[ORK.Game.Language], 
				this.useTitle ? this.title[ORK.Game.Language] : "", 
				this.fileChoice, this, sel);
			if(this.backOption != null && this.backOption is MenuScreen)
			{
				this.box.inPause = ((MenuScreen)this.backOption).pauseGame;
			}
			this.box.InitIn();
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.backFlag)
			{
				this.backFlag = false;
				if(this.box == origin)
				{
					this.box = null;
					if(this.backOption != null)
					{
						this.backOption.Show();
					}
					else if(ComponentHelper.IsAlive(this.starter))
					{
						this.starter.EventEnded();
					}
					ORK.Menu.CloseGeneralSaveBG();
					ORK.Control.SetMenuBlock(-1);
					
					if(this.bgBox != null)
					{
						for(int i=0; i<this.bgBox.Length; i++)
						{
							if(this.bgBox[i] != null)
							{
								this.bgBox[i].InitOut();
								this.bgBox[i] = null;
							}
						}
						this.bgBox = null;
					}
				}
				else if(this.qBox == origin)
				{
					this.qBox = null;
					ORK.GUI.FocusBlocked = false;
					
					if(this.oneBox)
					{
						this.ShowList();
					}
					else
					{
						this.box.SetFocus();
					}
				}
			}
			else
			{
				if(this.box == origin)
				{
					this.box = null;
					if(this.changer == null)
					{
						this.ShowQuestion();
					}
				}
				else if(this.qBox == origin)
				{
					this.qBox = null;
					ORK.GUI.FocusBlocked = false;
					ORK.SaveGame.Load(this.file);
				}
				else if(this.iBox == origin)
				{
					this.iBox = null;
				}
				
				// load saved game
				if(this.changer != null && this.iBox == null && this.box == null)
				{
					ORK.GUI.FocusBlocked = false;
					ORK.Menu.CloseGeneralSaveBG();
					ORK.Control.SetMenuBlock(-1);
					
					if(this.bgBox != null)
					{
						for(int i=0; i<this.bgBox.Length; i++)
						{
							if(this.bgBox[i] != null)
							{
								this.bgBox[i].InitOut();
								this.bgBox[i] = null;
							}
						}
						this.bgBox = null;
					}
					
					this.changer.StartEvent(null);
					this.changer = null;
					this.backOption = null;
					this.starter = null;
				}
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.box == origin)
			{
				if(index >= 0 && index < this.action.Length)
				{
					this.file = this.action[index];
					
					if(this.file == -1)
					{
						this.backFlag = true;
						this.box.InitOut();
						if(this.bgBox != null)
						{
							for(int i=0; i<this.bgBox.Length; i++)
							{
								if(this.bgBox[i] != null)
								{
									this.bgBox[i].InitOut();
									this.bgBox[i] = null;
								}
							}
							this.bgBox = null;
						}
					}
					else if(this.oneBox)
					{
						this.box.InitOut();
					}
					else
					{
						this.ShowQuestion();
					}
				}
			}
			else if(this.qBox == origin)
			{
				if(index != 0)
				{
					this.backFlag = true;
				}
				this.qBox.InitOut();
			}
			else if(this.iBox == origin)
			{
				if(this.box != null)
				{
					this.box.InitOut();
				}
				this.iBox.InitOut();
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			if(this.box == origin)
			{
				origin.Audio.PlayCancel();
				this.backFlag = true;
				this.box.InitOut();
				if(this.bgBox != null)
				{
					for(int i=0; i<this.bgBox.Length; i++)
					{
						if(this.bgBox[i] != null)
						{
							this.bgBox[i].InitOut();
							this.bgBox[i] = null;
						}
					}
					this.bgBox = null;
				}
			}
			else if(this.qBox == origin)
			{
				origin.Audio.PlayCancel();
				this.backFlag = true;
				this.qBox.InitOut();
			}
		}
	}
}
