
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDLevelPoints : HUDElement
	{
		[ORKEditorHelp("Element Type", "Select the type of the HUD element:\n" +
			"- Level Points: Displays an equipment's or ability's level points.\n" +
			"- Durability: Displays an equipment's durability.", "")]
		public HUDShortcutValueType type = HUDShortcutValueType.LevelPoints;
		
		
		// value bar
		[ORKEditorHelp("Use Bar", "The value will be displayed as a bar instead of text.", "")]
		public bool useBar = false;
		
		[ORKEditorHelp("Bar Bounds", "The position and size of the bar.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		[ORKEditorLayout("useBar", true)]
		public Rect barBounds = new Rect(0, 0, 100, 10);
		
		[ORKEditorLayout(autoInit=true)]
		public ValueBar bar;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"% = current value, %m = maximum value (experience: next level up)"})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public StatusTextHUD text;
		
		public HUDLevelPoints()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabel(out List<BaseLabel> label, Rect bounds, IShortcut shortcut, Combatant combatant)
		{
			label = new List<BaseLabel>();
			
			if(HUDShortcutValueType.LevelPoints.Equals(this.type))
			{
				if(shortcut is AbilityShortcut)
				{
					AbilityShortcut ability = shortcut as AbilityShortcut;
					if(ability.CanLevelUp())
					{
						this.Create(ref label, bounds, ability.LevelPoints, ability.MinLevelPoints, ability.MaxLevelPoints);
					}
				}
				else if(shortcut is EquipShortcut)
				{
					EquipShortcut equip = shortcut as EquipShortcut;
					if(equip.CanLevelUp())
					{
						this.Create(ref label, bounds, equip.LevelPoints, equip.MinLevelPoints, equip.MaxLevelPoints);
					}
				}
			}
			else if(HUDShortcutValueType.Durability.Equals(this.type))
			{
				if(shortcut is EquipShortcut && combatant != null)
				{
					EquipShortcut equip = shortcut as EquipShortcut;
					if(equip.Durability != -1)
					{
						this.Create(ref label, bounds, equip.Durability, 0, equip.GetMaxDurability(combatant));
					}
				}
			}
		}
		
		private void Create(ref List<BaseLabel> label, Rect bounds, float value, float minValue, float maxValue)
		{
			if(this.useBar)
			{
				this.bar.Create(ref label, 
					new Rect(this.barBounds.x + bounds.x, this.barBounds.y + bounds.y, this.barBounds.width, this.barBounds.height), 
					value, minValue, maxValue);
			}
			else
			{
				label.AddRange(new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%m", maxValue.ToString()).
						Replace("%", value.ToString())), 
					null, null, bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, this.text.textFormat).label);
			}
		}
	}
}
