
using UnityEngine;
using System.Collections.Generic;
using ORKFramework;
using ORKFramework.Menu.Parts;

namespace ORKFramework.Menu
{
	public class MenuScreenItem : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of this menu item:\n" +
			"- Menu Screen: Calls a menu screen.\n" +
			"- Save: Calls the save menu defined in the save game settings.\n" +
			"- Load: Calls the load menu defined in the save game settings.\n" +
			"- Exit Game: Exits to the main menu, displays the 'Exit Question' defined in the main menu settings.\n" +
			"- Global Event: Calls a global event.\n" +
			"- Close: Closes this menu screen.", "")]
		public MenuItemType type = MenuItemType.MenuScreen;
		
		
		// screen
		[ORKEditorHelp("Menu Screen", "Select the menu screen that will be called.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen)]
		[ORKEditorLayout("type", MenuItemType.MenuScreen)]
		public int screenID = 0;
		
		[ORKEditorHelp("Select Combatant", "Calls the combatant selection menu before calling the menu screen.\n" +
			"If disabled, the player combatant (i.e. the leader of the player group) is selected automatically.", "")]
		public bool selectCom = false;
		
		[ORKEditorHelp("Own Com. Selection", "Define a combatant selection that will be used.\n" +
			"If disabled, the default combatant selection (menu user) will be used.", "")]
		[ORKEditorLayout("selectCom", true, setDefault=true, defaultValue=false)]
		public bool ownSelection = false;
		
		[ORKEditorHelp("Combatant Selection", "Select the combatant selection that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		[ORKEditorLayout("ownSelection", true, endCheckGroup=true, endGroups=3)]
		public int selectionID = 0;
		
		
		// event
		[ORKEditorHelp("Global Event", "Select the global event that will be called.", "")]
		[ORKEditorInfo(ORKDataType.GlobalEvent)]
		[ORKEditorLayout("type", MenuItemType.GlobalEvent, endCheckGroup=true)]
		public int eventID = 0;
		
		
		// requirement
		[ORKEditorHelp("Use Requirement", "A defined requirement must be valid to display this menu item.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useReq = false;
		
		[ORKEditorHelp("Requirement", "Select the requirement that must be valid.", "")]
		[ORKEditorInfo(ORKDataType.Requirement)]
		[ORKEditorLayout("useReq", true)]
		public int reqID = 0;
		
		[ORKEditorHelp("Hide", "The button wont be displayed if the requirement is invalid.\n" +
			"If disabled, the button will only be deactivated.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool reqHide = false;
		
		
		// button
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);
		
		public MenuScreenItem()
		{
			
		}
		
		public bool IsCallSingleScreen()
		{
			return MenuItemType.MenuScreen.Equals(this.type) && 
				this.screenID >= 0 && this.screenID < ORK.MenuScreens.Count && 
					ORK.MenuScreens.Get(this.screenID).singleScreen;
		}
		
		public void Selected(MenuScreen origin)
		{
			if(MenuItemType.MenuScreen.Equals(this.type))
			{
				if(this.screenID >= 0 && this.screenID < ORK.MenuScreens.Count)
				{
					ORK.MenuScreens.Get(this.screenID).Show(origin);
				}
			}
			else if(MenuItemType.Save.Equals(this.type))
			{
				ORK.SaveGameMenu.saveMenu.Show(origin, null);
			}
			else if(MenuItemType.Load.Equals(this.type))
			{
				ORK.SaveGameMenu.loadMenu.Show(origin, null);
			}
			else if(MenuItemType.ExitGame.Equals(this.type))
			{
				ORK.MainMenu.exitChoice.Show(origin);
			}
			else if(MenuItemType.GlobalEvent.Equals(this.type))
			{
				ORK.GlobalEvents.CallGlobalEvent(this.eventID);
			}
			else if(MenuItemType.Close.Equals(this.type))
			{
				origin.Close();
			}
		}
		
		public void CallCombatantSelection(BaseMenuPart parent)
		{
			if(this.ownSelection)
			{
				ORK.CombatantSelections.Get(this.selectionID).Show(this, parent);
			}
			else
			{
				ORK.CombatantSelections.Get(ORK.MenuSettings.comUserID).Show(this, parent);
			}
		}
		
		public bool ResumeMusic
		{
			get
			{
				return !MenuItemType.MenuScreen.Equals(this.type) || 
					!ORK.MenuScreens.Get(this.screenID).ownMusic;
			}
		}
	}
}
