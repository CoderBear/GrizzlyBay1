
using UnityEngine;
using System.Collections.Generic;
using ORKFramework.Behaviours;
using ORKFramework.Menu;
using ORKFramework.Menu.Parts;

namespace ORKFramework
{
	public class ItemBoxChoice : BaseData, IChoice, IDragOrigin, IChoiceDrop
	{
		// animation
		[ORKEditorHelp("Use Animation", "The player will play an animation when interacting with an item box.", "")]
		public bool useAnimation = false;
		
		[ORKEditorHelp("Animation Type", "Select the animation type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		[ORKEditorLayout("useAnimation", true, endCheckGroup=true)]
		public int animationTypeID = 0;
		
		// audio
		[ORKEditorHelp("Play Sound", "A sound will be played when the player interacts with an item box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool playSound = false;
		
		[ORKEditorHelp("Use Sound Type", "The player combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("playSound", true)]
		public bool useSoundType = false;
		
		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;
		
		[ORKEditorHelp("Audio Clip", "The selected audio clip will be played.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=null)]
		public AudioClip audioClip;
		
		[ORKEditorHelp("Volume", "The volume used to play the sound.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float volume = 1;
		
		
		// drag+drop
		[ORKEditorHelp("Enable Dragging", "Items can be dragged.\n" +
			"Dragging an item on a combatant, HUD or inventory menu will " +
			"remove the item from the item box and add it to the combatant's inventory.", "")]
		[ORKEditorInfo(labelText="Drag Settings")]
		public bool enableDrag = false;
		
		[ORKEditorHelp("Enable Clicking", "Items can be clicked.\n" +
			"Clicking on an item the defind amount of time and clicking on a combatant, HUD or inventory menu will " +
			"remove the item from the item box and add it to the combatant's inventory.", "")]
		public bool enableClick = false;
		
		[ORKEditorHelp("Click Count", "Define the number of clicks needed.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("enableClick", true, endCheckGroup=true)]
		public int clickCount = 2;
		
		[ORKEditorHelp("Enable Tooltip", "A tooltip HUD can be displayed when the mouse position is over a menu item.", "")]
		public bool enableTooltip = false;
		
		[ORKEditorHelp("Receive Drops", "The item box can receive drops.\n" +
			"Items dropped on the item list will be removed from the combatant who owns them and added to the item box.", "")]
		[ORKEditorInfo(separator=true, labelText="Drop Settings")]
		public bool receiveDrops = false;
		
		[ORKEditorInfo("Drop Quantity Selection", "Define how the quantity of items dropped into the item box is decided.\n" +
			"If 'Default', the default give quantity selection is used.", "", 
			endFoldout=true)]
		[ORKEditorLayout("receiveDrops", true, endCheckGroup=true, autoInit=true)]
		public QuantityCall dropQuantity;
		
		
		// quantity selections
		[ORKEditorInfo("Take Quantity Selection", "Define how the quantity of items taken from the the item box is decided.\n" +
			"If 'Default', the default give quantity selection is used.", "", 
			endFoldout=true, separatorForce=true)]
		public QuantityCall takeQuantity = new QuantityCall();
		
		
		
		// item box GUI
		[ORKEditorHelp("GUI Box", "The GUI box used to display the item box dialogue.", "")]
		[ORKEditorInfo("Item List Settings", "Define the appearance of the item list the item box contains.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox, separatorForce=true)]
		public int guiBoxID = 0;
		
		
		// options
		[ORKEditorHelp("Auto Stack", "Items are automatically stacked, i.e. items that are equal will be grouped together.\n" +
			"If disabled, items will be left individually, even if other items of the same kind are already in the item box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool autoStack = false;
		
		[ORKEditorHelp("Allow Cancel", "The cancel button will close the item box.", "")]
		public bool allowCancel = true;
		
		[ORKEditorHelp("Auto Close", "The box will close when taking the last item.\n" +
			"Empty boxes can't be opened any more.", "")]
		public bool autoClose = false;
		
		
		// title settings
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the item box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
				"You can use scene object or combatant component information:", 
				"%n = name, %d = description, %i = icon", 
				"%td = type name, %td = type description, %ti = type icon"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// layout
		[ORKEditorInfo("Content Layout", "Define the layout of the buttons.", "", 
			endFoldout=true, separatorForce=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);
		
		
		// message
		[ORKEditorHelp("Message Text", "The message text displayed when items are in the box.", "")]
		[ORKEditorInfo("Message Text", "The message text displayed when items are in the box.", "", endFoldout=true, 
			isTextArea=true, label=new string[] {
				"You can use scene object or combatant component information:", 
				"%n = name, %d = description, %i = icon", 
				"%td = type name, %td = type description, %ti = type icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		[ORKEditorHelp("Empty Text", "The message text displayed when the box is empty.", "")]
		[ORKEditorInfo("Empty Text", "The message text displayed when the box is empty.", "", endFoldout=true, 
			isTextArea=true, label=new string[] {
				"You can use scene object or combatant component information:", 
				"%n = name, %d = description, %i = icon", 
				"%td = type name, %td = type description, %ti = type icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] messageEmpty = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// exit
		[ORKEditorHelp("Show Exit", "The exit button is displayed.", "")]
		[ORKEditorInfo("Exit Button", "An exit button can be added to the item list.", "")]
		public bool showExit = false;
		
		[ORKEditorHelp("Exit First", "The exit button will be the first button of the list.\n" +
			"If disabled, it will be the last button.", "")]
		[ORKEditorLayout("showExit", true)]
		public bool exitFirst = false;
				
		// exit button
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, autoLangSize=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"Exit"})]
		public LanguageInfo[] exitButton;
		
		
		// description box
		[ORKEditorHelp("Show Description", "Show a description box displaying the selected item's description.", "")]
		[ORKEditorInfo("Description Box", "The item box can display the description of the selected item.", "")]
		public bool showDescription = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showDescription", true, endCheckGroup=true, autoInit=true)]
		public DescriptionMenuPart description;
		
		
		// ingame
		private GUIBox box;
		
		private ItemCollector itemBox;
		
		private IContent titleContent;
		
		private ChoiceContent[] choices;

		private int[] choiceActions;
		
		private int current = 0;
		
		public ItemBoxChoice()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<bool>("enableDoubleClick"))
			{
				data.Get("enableDoubleClick", ref this.enableClick);
			}
		}
		
		public string Message
		{
			get
			{
				if(this.choices == null || this.choices.Length == 0 ||
					(this.showExit && this.choices.Length == 1))
				{
					if(this.titleContent != null)
					{
						IContentSimple typeContent = this.titleContent.GetTypeContent();
						return this.messageEmpty[ORK.Game.Language].
							Replace("%n", this.titleContent.GetName()).
							Replace("%d", this.titleContent.GetDescription()).
							Replace("%i", this.titleContent.GetIconTextCode()).
							Replace("%tn", typeContent.GetName()).
							Replace("%td", typeContent.GetDescription()).
							Replace("%ti", typeContent.GetIconTextCode());
					}
					else
					{
						return this.messageEmpty[ORK.Game.Language].
							Replace("%n", "").Replace("%d", "").Replace("%i", "").
							Replace("%tn", "").Replace("%td", "").Replace("%ti", "");
					}
				}
				else
				{
					if(this.titleContent != null)
					{
						IContentSimple typeContent = this.titleContent.GetTypeContent();
						return this.message[ORK.Game.Language].
							Replace("%n", this.titleContent.GetName()).
							Replace("%d", this.titleContent.GetDescription()).
							Replace("%i", this.titleContent.GetIconTextCode()).
							Replace("%tn", typeContent.GetName()).
							Replace("%td", typeContent.GetDescription()).
							Replace("%ti", typeContent.GetIconTextCode());
					}
					else
					{
						return this.message[ORK.Game.Language].
							Replace("%n", "").Replace("%d", "").Replace("%i", "").
							Replace("%tn", "").Replace("%td", "").Replace("%ti", "");
					}
				}
			}
		}
		
		public string Title
		{
			get
			{
				if(this.useTitle)
				{
					if(this.titleContent != null)
					{
						IContentSimple typeContent = this.titleContent.GetTypeContent();
						return this.title[ORK.Game.Language].
							Replace("%n", this.titleContent.GetName()).
							Replace("%d", this.titleContent.GetDescription()).
							Replace("%i", this.titleContent.GetIconTextCode()).
							Replace("%tn", typeContent.GetName()).
							Replace("%td", typeContent.GetDescription()).
							Replace("%ti", typeContent.GetIconTextCode());
					}
					else
					{
						return this.title[ORK.Game.Language].
							Replace("%n", "").Replace("%d", "").Replace("%i", "").
							Replace("%tn", "").Replace("%td", "").Replace("%ti", "");
					}
				}
				return "";
			}
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(ItemCollector ic)
		{
			if(ic != null)
			{
				this.current = 0;
				this.itemBox = ic;
				this.titleContent = ComponentHelper.GetContent(this.itemBox.gameObject);
				this.Show();
			}
		}
		
		public void Show()
		{
			this.CreateChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.Content = new DialogueContent(this.Message, this.Title, this.choices, this);
				this.box.InitIn();
			}
			else if(this.box.Content != null && 
				this.box.Content is DialogueContent)
			{
				((DialogueContent)this.box.Content).Update(this.Message, this.Title, this.choices, this.current, null, null);
			}
			if(this.current < 0)
			{
				this.current = 0;
			}
			else if(this.current >= this.choices.Length)
			{
				this.current = this.choices.Length - 1;
			}
			this.SelectionChanged(this.current, this.box);
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && this.current >= 0 && 
				this.current < this.itemBox.ItemList.Count)
			{
				ORK.GUI.SelectedShortcut = this.itemBox.ItemList[this.current];
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			if(this.box == origin)
			{
				ORK.GUI.SelectedShortcut = null;
			}
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.box == origin)
			{
				this.itemBox.CollectionFinished(true);
				this.itemBox = null;
				this.box = null;
				ORK.GUI.SelectedShortcut = null;
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			
			for(int i=0; i<this.itemBox.ItemList.Count; i++)
			{
				ChoiceContent tmp = null;
				if(this.itemBox.ItemList[i] is ItemShortcut ||
					this.itemBox.ItemList[i] is EquipShortcut ||
					this.itemBox.ItemList[i] is MoneyShortcut)
				{
					tmp = this.contentLayout.GetChoiceContent(this.itemBox.ItemList[i], ORK.Game.ActiveGroup.Leader);
				}
				
				if(tmp != null)
				{
					// drag and drop
					tmp.isDragable = this.enableDrag;
					tmp.clickCount = this.enableClick ? this.clickCount : 0;
					tmp.isTooltip = this.enableTooltip;
					if(tmp.isDragable || tmp.clickCount > 0 || tmp.isTooltip)
					{
						tmp.drag = this.itemBox.ItemList[i].GetDrag(this, null);
					}
					
					tmp.Active = ORK.Game.ActiveGroup.Leader.Inventory.GetAllowedCount(this.itemBox.ItemList[i]) != 0;
					
					cc.Add(tmp);
					ca.Add(i);
				}
			}
			
			if(this.showExit)
			{
				if(this.exitFirst)
				{
					cc.Insert(0, this.contentLayout.GetChoiceContent(this.exitButton));
					ca.Insert(0, -1);
				}
				else
				{
					cc.Add(this.contentLayout.GetChoiceContent(this.exitButton));
					ca.Add(-1);
				}
			}
			
			this.choices = cc.ToArray();
			this.choiceActions = ca.ToArray();
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.box == origin)
			{
				if(this.choices.Length == 0 || 
					(this.showExit && 
						((this.exitFirst && index == 0) || 
						(!this.exitFirst && index == this.choices.Length - 1))))
				{
					this.box.InitOut();
					
					if(this.showDescription && this.description != null)
					{
						this.description.Close();
					}
				}
				else
				{
					if(this.showExit && this.exitFirst)
					{
						index--;
					}
					if(index >= 0 && index < this.itemBox.ItemList.Count)
					{
						this.takeQuantity.Call(new QuantityData(false, null, this.itemBox.ItemList[index], 
							ORK.Game.ActiveGroup.Leader.Inventory.GetAllowedQuantity(this.itemBox.ItemList[index], -1), 
							ORK.Game.ActiveGroup.Leader.Inventory.GetCount(this.itemBox.ItemList[index]), 
							0, ORK.Game.ActiveGroup.Leader.Inventory.GetMoney(0), this.itemBox.ItemList[index].BuyPrice, 
							QuantitySelectionMode.Give, ORK.Game.ActiveGroup.Leader.Inventory.Add, this.RemoveQuantity));
					}
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			if(this.box == origin && index >= 0 && index < this.choices.Length)
			{
				this.current = index;
				
				if(this.choiceActions[index] == -1)
				{
					ORK.GUI.SelectedShortcut = null;
					if(this.showDescription && this.description != null)
					{
						this.description.Show(
							this.choices[index].description, 
							this.choices[index].Content.text, 
							null);
					}
				}
				else
				{
					if(this.showExit && this.exitFirst)
					{
						index--;
					}
					ORK.GUI.SelectedShortcut = this.itemBox.ItemList[index];
					
					if(this.showDescription && this.description != null)
					{
						this.description.Show(
							this.choices[index].description, 
							this.choices[index].Content.text, 
							this.itemBox.ItemList[index]);
					}
				}
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			if(this.box == origin && this.allowCancel)
			{
				origin.Audio.PlayCancel();
				this.box.InitOut();
				
				if(this.showDescription && this.description != null)
				{
					this.description.Close();
				}
			}
		}
		
		
		/*
		============================================================================
		Add/remove item functions
		============================================================================
		*/
		public bool AddQuantity(IShortcut shortcut, bool showNotification, bool showConsole)
		{
			if(this.itemBox != null)
			{
				this.itemBox.AddItem(shortcut);
				this.Show();
				return true;
			}
			return false;
		}
		
		public void RemoveQuantity(IShortcut shortcut, int quantity, bool showNotification, bool showConsole)
		{
			for(int i=0; i<this.itemBox.ItemList.Count; i++)
			{
				if(this.itemBox.ItemList[i] == shortcut)
				{
					if(this.itemBox.ItemList[i].Quantity <= quantity)
					{
						this.itemBox.ItemList.RemoveAt(i);
					}
					else
					{
						this.itemBox.ItemList[i].Quantity -= quantity;
					}
					break;
				}
			}
			
			if(this.autoClose && this.itemBox.ItemList.Count == 0)
			{
				this.box.InitOut();
				
				if(this.showDescription && this.description != null)
				{
					this.description.Close();
				}
			}
			else
			{
				this.Show();
			}
		}
		
		
		/*
		============================================================================
		Drag/drop functions
		============================================================================
		*/
		public void Dropped(DragInfo drag)
		{
			
		}

		public bool DroppedOnCombatant(Combatant c, DragInfo drag)
		{
			if(drag.Shortcut != null && (drag.Shortcut is ItemShortcut || 
				drag.Shortcut is MoneyShortcut || drag.Shortcut is EquipShortcut))
			{
				this.takeQuantity.Call(new QuantityData(false, null, drag.Shortcut, 
					c.Inventory.GetAllowedQuantity(drag.Shortcut, -1), 
					c.Inventory.GetCount(drag.Shortcut), 
					0, c.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, 
					QuantitySelectionMode.Give, c.Inventory.Add, this.RemoveQuantity));
			}
			return false;
		}

		public bool DroppedToWorld(Vector3 position, DragInfo drag)
		{
			return false;
		}
		
		public void ChoiceDropped(int index, GUIBox origin, DragInfo drag)
		{
			if(this.receiveDrops && drag.User != null && drag.Shortcut != null && 
				(drag.Shortcut is ItemShortcut || drag.Shortcut is MoneyShortcut || drag.Shortcut is EquipShortcut))
			{
				int inBox = ShortcutHelper.GetCount(this.itemBox.ItemList, drag.Shortcut);
				int allowed = -1;
				
				if(drag.Shortcut is ItemShortcut)
				{
					allowed = ((ItemShortcut)drag.Shortcut).Setting.GetQuantityLimit();
				}
				else if(drag.Shortcut is EquipShortcut)
				{
					allowed = ((EquipShortcut)drag.Shortcut).Setting.GetQuantityLimit();
				}
				
				if(allowed == -1 || allowed - inBox > 0)
				{
					this.dropQuantity.Call(new QuantityData(false, null, drag.Shortcut, 
						Mathf.Min(allowed - inBox, drag.Shortcut.Quantity), 
						ORK.Game.ActiveGroup.Leader.Inventory.GetCount(drag.Shortcut), 
						0, ORK.Game.ActiveGroup.Leader.Inventory.GetMoney(0), drag.Shortcut.BuyPrice, 
						QuantitySelectionMode.Give, this.AddQuantity, drag.User.Inventory.Remove));
				}
			}
		}
	}
}
