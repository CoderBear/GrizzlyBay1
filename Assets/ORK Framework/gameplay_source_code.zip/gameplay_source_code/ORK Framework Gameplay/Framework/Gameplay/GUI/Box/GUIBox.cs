
using UnityEngine;
using ORKFramework.Behaviours;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBox
	{
		private GUIBoxSetting settings;
		
		
		// tick in pause?
		public bool inPause = false;
		
		public bool forceSize = false;
		
		public bool useFullScreen = false;
		
		
		// positions
		public Rect bounds = new Rect(0, 0, 1280, 800);
		
		public Rect nameBounds = new Rect(0, 0, 150, 50);
		
		public Rect windowRect = new Rect(0, 0, 100, 100);

		private Vector2 moveInStart = Vector2.zero;

		private Vector2 moveOutEnd = Vector2.zero;

		private Vector2 currentPos = Vector2.zero;

		public Vector2 nameOffset = Vector2.zero;
		
		private Vector2 baseOffset = Vector2.zero;
		
		private GameObject atObject = null;
		
		private Renderer renderer = null;
		
		private GUIBox relativeToBox = null;
		
		private TextAnchor relativeToBoxAnchor = TextAnchor.UpperLeft;
		
		
		// scaling
		public Vector2 currentScale = Vector2.one;
		
		private Vector2 distanceScale = Vector2.one;
		
		public TextAnchor scaleAnchor = TextAnchor.UpperLeft;
		
		
		// fading
		public Color color = new Color(1, 1, 1, 1);
		
		public Color lastColor = new Color(1, 1, 1, 1);
		
		private Color colStart = new Color(1, 1, 1, 1);
		
		public bool doFlash = false;
		
		public Color flashColor;

		private float time = 0;

		private bool inDone = false;

		public bool outDone = false;
		
		private bool isFading = false;
		
		private bool delayFade = false;
		
		
		// moving
		private Function interpolateMIn;

		private Function interpolateMOut;

		private float mTime = 0;

		private bool mInDone = false;

		private bool mOutDone = false;

		private float mDistanceX = 0;

		private float mDistanceY = 0;

		private bool isMoving = false;
		
		private bool delayMove = false;
		
		
		// content
		private GUIBoxContent content;
		
		public bool controlable = true;
		
		public bool focusable = true;
		
		public bool disableChoice = false;
		
		public bool blocked = false;
		
		public bool hidden = false;
		
		private bool registered = false;
		
		
		// unfocused selection
		private int choiceDown = -1;
		
		
		// auto close
		private bool autoClose = false;
		
		private float closeAfter = 0;
		
		
		// new UI
		public GUIBoxComponent uiComponent;
		
		public GameObject gameObject;
		
		public GUIBox(GUIBoxSetting s)
		{
			this.settings = s;
			
			this.bounds = this.settings.boxBounds;
			this.nameBounds = this.settings.nameBounds;
			this.windowRect = this.bounds;
			this.moveInStart = this.settings.moveInStart;
			this.moveOutEnd = this.settings.moveOutEnd;
			this.currentPos = new Vector2(this.bounds.x, this.bounds.y);
			this.useFullScreen = ORK.GUILayers.Get(this.settings.layerID).useFullScreen;
			
			if(this.settings.nameRelative)
			{
				this.nameOffset = new Vector2(this.settings.nameBounds.x, this.settings.nameBounds.y);
			}
			else
			{
				this.nameOffset = new Vector2(this.settings.nameBounds.x - this.bounds.x, this.settings.nameBounds.y - this.bounds.y);
			}
		}
		
		public GUIBoxSetting Settings
		{
			get{ return this.settings;}
		}
		
		public MenuAudioClips Audio
		{
			get
			{
				if(this.settings.ownAudio && this.settings.audio != null)
				{
					return this.settings.audio;
				}
				else
				{
					return ORK.MenuSettings.audio;
				}
			}
		}
		
		public GUIBoxSkins Skins
		{
			get
			{
				if(this.settings.ownSkins && this.settings.skins != null)
				{
					return this.settings.skins;
				}
				else
				{
					return ORK.MenuSettings.skins;
				}
			}
		}
		
		public ChoiceIconSettings ChoiceIcon
		{
			get
			{
				if(this.settings.ownChoiceIcon && this.settings.choiceIcon != null)
				{
					return this.settings.choiceIcon;
				}
				else
				{
					return ORK.MenuSettings.choiceIcon;
				}
			}
		}
		
		public HeaderSettings Headers
		{
			get
			{
				if(this.settings.ownHeaders && this.settings.headerSettings != null)
				{
					return this.settings.headerSettings;
				}
				else
				{
					return ORK.MenuSettings.headerSettings;
				}
			}
		}
		
		
		/*
		============================================================================
		Window and focus functions
		============================================================================
		*/
		public void SetFocus()
		{
			if(this.controlable && this.focusable)
			{
				ORK.GUI.Focus = this;
			}
		}
		
		public bool Focused
		{
			get
			{
				return this.controlable && 
					this.focusable && ORK.GUI.Focus == this;
			}
		}
		
		
		/*
		============================================================================
		Base position functions
		============================================================================
		*/
		public GameObject AtObject
		{
			get{ return this.atObject;}
			set
			{
				this.atObject = value;
				if(this.atObject != null)
				{
					this.renderer = this.atObject.transform.root.GetComponentInChildren<Renderer>();
				}
			}
		}
		
		public void SetRelativeTo(GUIBox box, TextAnchor anchor)
		{
			this.relativeToBox = box;
			this.relativeToBoxAnchor = anchor;
		}
		
		public void SetBaseToCursor()
		{
			Vector2 pos = ORK.GUILayers.Get(this.settings.layerID).GetPoint(ORK.Control.MousePosition);
			this.SetBasePosition(pos.x, pos.y);
		}
		
		public void SetBasePosition(float newX, float newY)
		{
			if(this.bounds.x != newX || this.bounds.y != newY)
			{
				if(this.settings.moveIn)
				{
					this.moveInStart.x = newX - (this.bounds.x - this.moveInStart.x);
					this.moveInStart.y = newY - (this.bounds.y - this.moveInStart.y);
					if(!this.mInDone)
					{
						this.mDistanceX = newX - this.moveInStart.x;
						this.mDistanceY = newY - this.moveInStart.y;
					}
				}
				if(this.settings.moveOut)
				{
					this.moveOutEnd.x = newX - (this.bounds.x - this.moveOutEnd.x);
					this.moveOutEnd.y = newY - (this.bounds.y - this.moveOutEnd.y);
				}
				this.currentPos.x += newX - this.bounds.x;
				this.currentPos.y += newY - this.bounds.y;
				this.bounds.x = newX;
				this.bounds.y = newY;
			}
		}
		
		public void MoveBasePosition(Vector2 change)
		{
			if(change.x != 0 || change.y != 0)
			{
				if(ORK.GameSettings.secureWindowDrag)
				{
					Rect tmp = new Rect(this.currentPos.x + change.x + this.baseOffset.x, 
						this.currentPos.y + change.y + this.baseOffset.y, 
						this.bounds.width, this.bounds.height);
					ORK.GameSettings.CheckDragWindowPosition(ref tmp);
					this.SetBasePosition(tmp.x - this.baseOffset.x, tmp.y - this.baseOffset.y);
				}
				else
				{
					this.SetBasePosition(this.currentPos.x + change.x, this.currentPos.y + change.y);
				}
			}
		}
		
		public Vector2 BaseOffset
		{
			get{ return this.baseOffset;}
			set{ this.baseOffset = value;}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public void InitIn()
		{
			this.outDone = false;
			this.mOutDone = false;
			
			// display at cursor position
			if(this.settings.atCursor)
			{
				this.SetBaseToCursor();
			}
			
			if(this.settings.useFadeIn && this.settings.fadeIn != null && !this.hidden)
			{
				this.time = 0;
				this.colStart = this.color;
				this.settings.fadeIn.GetStart(ref this.colStart);
				this.color = this.colStart;
				this.isFading = true;
				this.inDone = false;
				this.delayFade = this.settings.fadeInDelay > 0;
			}
			else
			{
				this.isFading = false;
				this.inDone = true;
				this.delayFade = false;
			}
			
			if(this.settings.moveIn && !this.hidden)
			{
				this.interpolateMIn = Interpolate.Ease(this.settings.moveInInterpolation);
				this.mTime = 0;
				this.mDistanceX = this.bounds.x - this.moveInStart.x;
				this.mDistanceY = this.bounds.y - this.moveInStart.y;
				this.currentPos = new Vector2(this.moveInStart.x, this.moveInStart.y);
				this.currentScale = this.settings.moveInUseScale ? this.settings.moveInScale : Vector2.one;
				this.distanceScale = Vector2.one - this.currentScale;
				this.scaleAnchor = this.settings.moveInScaleAnchor;
				this.isMoving = true;
				this.mInDone = false;
				this.delayMove = this.settings.moveInDelay > 0;
			}
			else
			{
				this.currentPos = new Vector2(this.bounds.x, this.bounds.y);
				this.isMoving = false;
				this.mInDone = true;
				this.delayMove = false;
			}
			
			this.windowRect.x = this.currentPos.x + this.baseOffset.x;
			this.windowRect.y = this.currentPos.y + this.baseOffset.y;
			this.windowRect.width = this.bounds.width;
			this.windowRect.height = this.bounds.height;
			
			this.Register();
		}
		
		public void InitOut()
		{
			this.autoClose = false;
			this.inDone = true;
			this.mInDone = true;
			if(this.settings.useFadeOut && this.settings.fadeOut != null && !this.hidden)
			{
				this.time = 0;
				this.colStart = this.color;
				this.settings.fadeOut.GetStart(ref this.colStart);
				this.color = colStart;
				this.isFading = true;
				this.outDone = false;
				this.delayFade = this.settings.fadeOutDelay > 0;
			}
			else
			{
				this.isFading = false;
				this.outDone = true;
				this.delayFade = false;
			}
			if(this.settings.moveOut && !this.hidden)
			{
				this.interpolateMOut = Interpolate.Ease(this.settings.moveOutInterpolation);
				this.mTime = 0;
				this.mDistanceX = this.moveOutEnd.x - this.currentPos.x;
				this.mDistanceY = this.moveOutEnd.y - this.currentPos.y;
				this.currentScale = Vector2.one;
				this.distanceScale = (this.settings.moveOutUseScale ? this.settings.moveOutScale : Vector2.one) - this.currentScale;
				this.scaleAnchor = this.settings.moveOutScaleAnchor;
				this.isMoving = true;
				this.mOutDone = false;
				this.delayMove = this.settings.moveOutDelay > 0;
			}
			else
			{
				this.isMoving = false;
				this.mOutDone = true;
				this.delayMove = false;
			}
		}
		
		public void Reset()
		{
			this.time = 0;
			this.mTime = 0;
			this.inDone = false;
			this.outDone = false;
			this.mInDone = false;
			this.mOutDone = false;
			this.isFading = false;
			this.isMoving = false;
			this.interpolateMIn = null;
			this.interpolateMOut = null;
			this.mDistanceX = 0;
			this.mDistanceY = 0;
			this.currentPos = Vector2.zero;
			
			this.color = new Color(1, 1, 1, 1);
			this.autoClose = false;
			
			if(this.content != null)
			{
				this.content.newContent = true;
			}
		}
		
		public void CloseAfter(float t, bool controlable)
		{
			float f1 = 0;
			float f2 = 0;
			if(this.settings.useFadeOut)
			{
				f1 = this.settings.fadeOut.time;
			}
			if(this.settings.moveOut)
			{
				f2 = this.settings.moveOutTime;
			}
			this.closeAfter = t - Mathf.Max(f1, f2);
			this.autoClose = true;
			this.controlable = controlable;
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool FadingOut
		{
			get
			{
				return this.inDone && this.mInDone && 
				((!this.outDone && this.isFading) || 
					(!this.mOutDone && this.isMoving));
			}
		}
		
		public bool Controlable
		{
			get
			{
				return !this.blocked && this.inDone && this.mInDone && 
					!this.isFading && !this.isMoving && 
					!this.outDone && !this.mOutDone && 
					this.controlable && 
					(this.inPause || !ORK.Game.Paused);
			}
		}
		
		public bool FadedIn
		{
			get
			{
				return !this.blocked && this.inDone && this.mInDone && 
					!this.isFading && !this.isMoving && 
					!this.outDone && !this.mOutDone;
			}
		}
		
		public bool FadedOut
		{
			get
			{
				return this.outDone && this.mOutDone;
			}
		}

		public void SetOutDone()
		{
			this.outDone = true;
			this.mOutDone = true;
		}
		
		public bool IsTooltip
		{
			get
			{
				return this.content != null && 
					((this.content is PrecalcHUDContent && 
						HUDType.Tooltip.Equals(((PrecalcHUDContent)this.content).type)) || 
					this.content is DragContent);
			}
		}
		
		
		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public void Register()
		{
			if(!this.registered)
			{
				if(this.IsTooltip)
				{
					ORK.GUI.AddTooltip(this);
				}
				else
				{
					ORK.GUI.AddBox(this);
				}
				this.registered = true;
			}
		}
		
		public void Unregister()
		{
			this.registered = false;
			if(this.IsTooltip)
			{
				ORK.GUI.RemoveTooltip(this);
			}
			else
			{
				ORK.GUI.RemoveBox(this);
			}
			if(this.content != null)
			{
				this.content.Clear();
			}
			if(this.uiComponent != null)
			{
				GameObject.Destroy(this.uiComponent.gameObject);
			}
		}
		
		
		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public void Tick(float t)
		{
			if(ORK.GUI.IsNewUI && this.uiComponent != null)
			{
				if(this.blocked || this.hidden || this.content == null)
				{
					this.uiComponent.gameObject.SetActive(false);
				}
				else if(!this.uiComponent.gameObject.activeInHierarchy)
				{
					this.uiComponent.gameObject.SetActive(true);
				}
				if(this.content != null)
				{
					if(this.forceSize)
					{
						this.bounds.width = this.settings.boxBounds.width;
						this.bounds.height = this.settings.boxBounds.height;
					}
					
					this.windowRect.x = this.currentPos.x + this.baseOffset.x;
					this.windowRect.y = this.currentPos.y + this.baseOffset.y;
					
					if(this.content.newContent)
					{
						this.content.Init(this);
						this.content.CreateNewUI();
					}
					if(this.content.newName)
					{
						this.content.CalculateName();
					}
					
					this.windowRect.width = this.bounds.width;
					this.windowRect.height = this.bounds.height;
					
					GUIHelper.GetRectAnchor(ref this.windowRect, 
						-this.windowRect.width, -this.windowRect.height, 
						this.settings.boxAnchor);
					
					// name box
					this.nameBounds.x = this.windowRect.x + this.nameOffset.x;
					this.nameBounds.y = this.windowRect.y + this.nameOffset.y;
					if(!this.settings.nameRelative)
					{
						GUIHelper.GetRectAnchorReverse(ref this.nameBounds, 
							-this.windowRect.width, -this.windowRect.height, 
							this.settings.boxAnchor);
					}
				}
			}
			
			if(this.inPause || !ORK.Game.Paused)
			{
				// at object
				if(this.atObject != null)
				{
					this.blocked = this.renderer == null || !this.renderer.isVisible;
					Vector3 pos = VectorHelper.GetScreenPosition(atObject.transform.position);
					this.SetBasePosition(pos.x, pos.y);
				}
				// relative to box
				else if(this.relativeToBox != null)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.relativeToBox.windowRect, this.relativeToBoxAnchor);
					this.SetBasePosition(tmp.x, tmp.y);
				}
				// at cursor
				else if(this.settings.atCursor && this.settings.followCursor && 
					(this.settings.followAtClose || !this.FadingOut))
				{
					this.SetBaseToCursor();
				}
				
				
				// auto close
				if(this.autoClose)
				{
					this.closeAfter -= t;
					if(this.closeAfter <= 0)
					{
						this.InitOut();
					}
				}
				
				// fade
				this.DoFade(t);
				
				// content
				if(this.content != null)
				{
					this.content.Tick();
				}
				
				// close
				if(this.outDone && this.mOutDone && this.registered)
				{
					this.Unregister();
					if(this.content != null)
					{
						this.content.Closed();
					}
				}
			}
		}
		
		public void DoFade(float t)
		{
			if(this.isFading)
			{
				if(!this.inDone)
				{
					this.DoFadeIn(t);
				}
				else if(!this.outDone)
				{
					this.DoFadeOut(t);
				}
				else
				{
					this.isFading = false;
				}
			}
			if(this.isMoving)
			{
				if(!this.mInDone)
				{
					this.DoMoveIn(t);
				}
				else if(!this.mOutDone)
				{
					this.DoMoveOut(t);
				}
				else
				{
					this.isMoving = false;
				}
			}
		}
		
		public void DoFadeIn(float t)
		{
			this.time += t;
			
			if(this.delayFade)
			{
				if(this.time >= this.settings.fadeInDelay)
				{
					this.time = 0;
					this.delayFade = false;
				}
			}
			else if(this.settings.fadeIn.Fade(ref this.color, this.colStart, this.time))
			{
				this.lastColor = this.color;
				this.isFading = false;
				this.inDone = true;
			}
		}
		
		public void DoFadeOut(float t)
		{
			this.time += t;
			
			if(this.delayFade)
			{
				if(this.time >= this.settings.fadeOutDelay)
				{
					this.time = 0;
					this.delayFade = false;
				}
			}
			else if(this.settings.fadeOut.Fade(ref this.color, this.colStart, this.time))
			{
				this.lastColor = this.color;
				this.isFading = false;
				this.outDone = true;
			}
		}
		
		
		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public void DoMoveIn(float t)
		{
			if(this.interpolateMIn != null)
			{
				this.mTime += t;
				
				if(this.delayMove)
				{
					if(this.mTime >= this.settings.moveInDelay)
					{
						this.mTime = 0;
						this.delayMove = false;
					}
				}
				else
				{
					if(this.mDistanceX != 0)
					{
						this.currentPos.x = Interpolate.Ease(this.interpolateMIn, this.moveInStart.x, 
							this.mDistanceX, this.mTime, this.settings.moveInTime);
					}
					if(this.mDistanceY != 0)
					{
						this.currentPos.y = Interpolate.Ease(this.interpolateMIn, this.moveInStart.y, 
							this.mDistanceY, this.mTime, this.settings.moveInTime);
					}
					if(this.settings.moveInUseScale)
					{
						this.currentScale = Interpolate.Ease(this.interpolateMIn, this.settings.moveInScale, 
							this.distanceScale, this.mTime, this.settings.moveInTime);
					}
					if(this.mTime >= this.settings.moveInTime)
					{
						this.isMoving = false;
						this.mInDone = true;
					}
				}
			}
		}
		
		public void DoMoveOut(float t)
		{
			if(this.interpolateMOut != null)
			{
				this.mTime += t;
				
				if(this.delayMove)
				{
					if(this.mTime >= this.settings.moveOutDelay)
					{
						this.mTime = 0;
						this.delayMove = false;
					}
				}
				else
				{
					if(this.mDistanceX != 0)
					{
						this.currentPos.x = Interpolate.Ease(this.interpolateMOut, this.bounds.x, 
							this.mDistanceX, this.mTime, this.settings.moveOutTime);
					}
					if(this.mDistanceY != 0)
					{
						this.currentPos.y = Interpolate.Ease(this.interpolateMOut, this.bounds.y, 
							this.mDistanceY, this.mTime, this.settings.moveOutTime);
					}
					if(this.settings.moveOutUseScale)
					{
						this.currentScale = Interpolate.Ease(this.interpolateMIn, Vector2.one, 
							this.distanceScale, this.mTime, this.settings.moveOutTime);
					}
					if(this.mTime >= this.settings.moveOutTime)
					{
						this.isMoving = false;
						this.mOutDone = true;
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Unity GUI functions
		============================================================================
		*/
		public GUIBoxContent Content
		{
			get{ return this.content;}
			set
			{
				if(this.content != null)
				{
					this.content.Clear();
				}
				this.content = value;
				this.content.box = this;
				this.content.newContent = true;
			}
		}
		
		public void SetGUIColor(bool blockFlash)
		{
			if(this.doFlash && !blockFlash)
			{
				GUI.color = this.flashColor;
				GUI.backgroundColor = this.flashColor;
				GUI.contentColor = this.flashColor;
			}
			else if(this.controlable && this.focusable && !this.Focused)
			{
				this.InactiveColor.SetColors();
			}
			else
			{
				GUI.color = this.color;
				GUI.backgroundColor = this.color;
				GUI.contentColor = this.color;
			}
		}
		
		public InactiveColor InactiveColor
		{
			get
			{
				if(this.settings.ownInactive)
				{
					return this.settings.inactive;
				}
				else
				{
					return ORK.MenuSettings.inactive;
				}
			}
		}
		
		public void ShowGUI()
		{
			if(!this.blocked)
			{
				GUISkin tmp = GUI.skin;
				if(this.content != null)
				{
					// matrix
					if(this.useFullScreen)
					{
						GUI.matrix = ORK.Core.FullScreenMatrix;
					}
					else
					{
						GUI.matrix = ORK.Core.GUIMatrix;
					}
					
					if(this.forceSize)
					{
						this.bounds.width = this.settings.boxBounds.width;
						this.bounds.height = this.settings.boxBounds.height;
					}
					
					if(this.Skins.skin)
					{
						GUI.skin = this.Skins.skin;
					}
					
					this.content.Init(this);
					
					Color c = GUI.color;
					Color bc = GUI.backgroundColor;
					Color cc = GUI.contentColor;
					
					GUI.color = this.color;
					
					this.SetGUIColor(false);
					
					this.windowRect.x = this.currentPos.x + this.baseOffset.x;
					this.windowRect.y = this.currentPos.y + this.baseOffset.y;
					this.windowRect.width = this.bounds.width;
					this.windowRect.height = this.bounds.height;
					
					GUIHelper.GetRectAnchor(ref this.windowRect, 
						-this.windowRect.width, -this.windowRect.height, 
						this.settings.boxAnchor);
					
					if(this.currentScale != Vector2.one)
					{
						Vector3 guiScale = this.useFullScreen ? 
							new Vector3(ORK.Core.RealScale.x * this.currentScale.x, 
								ORK.Core.RealScale.y * this.currentScale.y, 1) :
							new Vector3(ORK.Core.GUIScale.x * this.currentScale.x, 
								ORK.Core.GUIScale.y * this.currentScale.y, 1);
						if(guiScale.x <= 0.0001f)
						{
							guiScale.x = 0.0001f;
						}
						if(guiScale.y <= 0.0001f)
						{
							guiScale.y = 0.0001f;
						}
						
						Vector3 tmpPos = GUIHelper.GetRectAnchor(this.windowRect, this.scaleAnchor);
						tmpPos.x *= ORK.Core.GUIScale.x;
						tmpPos.y *= ORK.Core.GUIScale.y;
						
						GUI.matrix = Matrix4x4.TRS((this.useFullScreen ? Vector3.zero : ORK.Core.GUITranslate) + tmpPos - 
								new Vector3(tmpPos.x * this.currentScale.x, tmpPos.y * this.currentScale.y, 0), 
							Quaternion.identity, guiScale);
					}
					
					// name box
					this.nameBounds.x = this.windowRect.x + this.nameOffset.x;
					this.nameBounds.y = this.windowRect.y + this.nameOffset.y;
					if(!this.settings.nameRelative)
					{
						GUIHelper.GetRectAnchorReverse(ref this.nameBounds, 
							-this.windowRect.width, -this.windowRect.height, 
							this.settings.boxAnchor);
					}
					
					
					if(!this.hidden)
					{
						this.content.ShowBefore();
						
						// content box
						if(this.Settings.showBox)
						{
							GUI.Box(this.windowRect, "");
						}
						
						GUI.BeginGroup(this.windowRect);
						this.content.ShowWindow();
						GUI.EndGroup();
						
						// ok/cancel buttons
						this.content.ShowButtons();
						
						// show name
						this.content.ShowName();
						
						// selection icon
						this.content.ShowSelectionIcon();
						
						this.content.ShowAfter();
					}
					
					GUI.color = c;
					GUI.backgroundColor = bc;
					GUI.contentColor = cc;
					
					if(this.currentScale != Vector2.one)
					{
						GUI.matrix = ORK.Core.GUIMatrix;
					}
				}
				GUI.skin = tmp;
			}
		}
		
		public bool Button(Rect buttonBounds, bool showButton, int index, bool last)
		{
			if(this.Focused && this.FadedIn && !this.FadingOut)
			{
				if(GUI.Button(buttonBounds, "", showButton ? "button" : ""))
				{
					return true;
				}
				// unfocused selection
				else if(this.choiceDown >= 0 && 
					Event.current.type == EventType.mouseUp)
				{
					if(this.choiceDown == index)
					{
						this.choiceDown = -1;
						
						Vector2 pos = ORK.GUILayers.Get(this.settings.layerID).GetPoint(ORK.Control.MousePosition);
						pos.x -= this.windowRect.x + this.settings.boxPadding.x;
						pos.y -= this.windowRect.y + this.settings.boxPadding.y;
						
						if(buttonBounds.Contains(pos))
						{
							return true;
						}
					}
					else if(last)
					{
						this.choiceDown = -1;
					}
				}
			}
			else if(showButton)
			{
				GUI.Box(buttonBounds, "", "button");
				
				// unfocused selection
				if(this.settings.unfocusedChoice && 
					Event.current.type == EventType.mouseDown)
				{
					Vector2 pos = ORK.GUILayers.Get(this.settings.layerID).GetPoint(ORK.Control.MousePosition);
					pos.x -= this.windowRect.x + this.settings.boxPadding.x;
					pos.y -= this.windowRect.y + this.settings.boxPadding.y;
					
					if(buttonBounds.Contains(pos))
					{
						this.choiceDown = index;
					}
				}
			}
			return false;
		}
		
		public bool TabButton(Rect buttonBounds)
		{
			if(!Application.isPlaying || !this.FadedIn || this.FadingOut)
			{
				GUI.Box(buttonBounds, "", this.settings.tabsButtonSettings.showButton ? "button" : "");
			}
			else
			{
				if(GUI.Button(buttonBounds, "", this.settings.tabsButtonSettings.showButton ? "button" : ""))
				{
					return true;
				}
			}
			return false;
		}
	}
}
