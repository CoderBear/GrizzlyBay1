
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantShortcuts : ISaveData
	{
		private Combatant owner;
		
		
		// slots
		private Dictionary<int, IShortcut> slots;
		
		public CombatantShortcuts(Combatant owner)
		{
			this.owner = owner;
			this.slots = new Dictionary<int, IShortcut>();
		}
		
		public bool CheckShortcut(IShortcut shortcut)
		{
			return shortcut is MoneyShortcut || 
				(shortcut is AbilityShortcut && this.owner.Abilities.Has((AbilityShortcut)shortcut)) || 
				((shortcut is ItemShortcut || shortcut is EquipShortcut) && this.owner.Inventory.Has(shortcut));
		}
		
		private IShortcut GetRenewedShortcut(IShortcut shortcut)
		{
			if(shortcut is AbilityShortcut)
			{
				return this.owner.Abilities.Get(shortcut as AbilityShortcut);
			}
			else if(shortcut is ItemShortcut)
			{
				if(this.owner.Inventory.Has(shortcut))
				{
					return this.owner.Inventory.GetItem(shortcut.ID);
				}
			}
			else if(shortcut is EquipShortcut)
			{
				if(this.owner.Inventory.Has(shortcut))
				{
					return this.owner.Inventory.GetEquipment(shortcut as EquipShortcut);
				}
			}
			else if(shortcut is MoneyShortcut)
			{
				if(this.owner.Inventory.Has(shortcut))
				{
					return this.owner.Inventory.GetMoneyShortcut(shortcut.ID);
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Slot functions
		============================================================================
		*/
		public IShortcut this[int index]
		{
			get
			{
				if(this.slots.ContainsKey(index))
				{
					this.slots[index] = this.GetRenewedShortcut(this.slots[index]);
					return this.slots[index];
				}
				return null;
			}
			set
			{
				if(value == null)
				{
					this.slots.Remove(index);
				}
				else
				{
					if(this.slots.ContainsKey(index))
					{
						this.slots[index] = value;
					}
					else
					{
						this.slots.Add(index, value);
					}
				}
				this.owner.MarkHUDUpdate();
			}
		}
		
		public bool HasShortcut(int index)
		{
			return this.slots.ContainsKey(index) && 
				this.slots[index] != null && 
				this.CheckShortcut(this.slots[index]);
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			foreach(KeyValuePair<int, IShortcut> pair in this.slots)
			{
				data.Set(pair.Key.ToString(), pair.Value.SaveGame());
			}
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.slots = new Dictionary<int, IShortcut>();
			if(data != null)
			{
				Dictionary<string, DataObject> tmp = data.GetData<DataObject>(typeof(DataObject));
				
				foreach(KeyValuePair<string, DataObject> pair in tmp)
				{
					string typeInfo = "";
					pair.Value.Get(DataSerializer.TYPE, ref typeInfo);
					if(typeInfo.EndsWith("Shortcut"))
					{
						IShortcut shortcut = DataSerializer.CreateInstance(System.Type.GetType("ORKFramework." + typeInfo)) as IShortcut;
						if(shortcut != null)
						{
							shortcut.LoadGame(pair.Value);
							this.slots.Add(int.Parse(pair.Key), shortcut);
						}
					}
				}
			}
		}
	}
}
