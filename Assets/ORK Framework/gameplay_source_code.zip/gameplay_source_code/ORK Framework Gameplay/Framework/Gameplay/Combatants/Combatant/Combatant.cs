
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Combatant : ISaveData, IContent
	{
		// setting reference
		private CombatantSetting setting;
		
		private int realID = 0;
		
		private Group group;
		
		private bool isInitialized = false;
		
		private bool isTemporary = false;
		
		
		// base
		private int currentClassID = 0;
		
		private int currentLevel = 1;
		
		private Dictionary<int, int> currentClassLevel = new Dictionary<int, int>();
		
		private Dictionary<int, int> classLevelExp = new Dictionary<int, int>();
		
		private CombatantStatus status;
		
		private CombatantEquipment equipment;
		
		private CombatantActions actions;
		
		private CombatantAnimations animations;
		
		
		// shortcut lists
		private CombatantShortcuts[] shortcutList;
		
		private int shortcutIndex = 0;
		
		private Dictionary<int, CombatantShortcuts[]> classShortcutList = new Dictionary<int, CombatantShortcuts[]>();
		
		
		// name
		private string newName = "";
		
		private string nameCount = "";
		
		
		// inventory
		private Inventory inventory;
		
		private bool itemStolen = false;
		
		private bool moneyStolen = false;
		
		
		// game objects
		private int prefabIndex = -1;
		
		private GameObject prefabInstance;
		
		private CombatantComponent combatantComponent;
		
		private GameObject battleSpot;
		
		private GameObject cursorInstance;
		
		
		// HUD
		private Renderer renderer;
		
		private List<HUD> hud = new List<HUD>();
		
		private float hudLastCheckTime = 0;
		
		private int hudLastFaction = -2;
		
		private bool hudPlayerEnemy = false;
		
		private int hudEffectIndex = 0;
		
		private float hudEffectTime = 0;
		
		// HUD color fade
		private FadeColorSettings fade;
		
		private Color hudCol = new Color(1, 1, 1, 1);
		
		private Color hudColStart = new Color(1, 1, 1, 1);
		
		private float hudColTime = 0;
		
		private float hudColTime2 = 0;
		
		private int hudColState = 0;
		
		// battle info GUI box
		private List<GUIBox> battleInfo = new List<GUIBox>();
		
		// bestiary information
		private BestiaryEntry bestiaryEntry;
		
		
		//  battle
		private bool inBattle = false;
		
		private ActiveBattleMenu battleMenu;
		
		private List<Combatant> lastTargets = new List<Combatant>();
		
		private SelectedTargets selectedTargets;
		
		private int lastTurnIndex = -1;
		
		private bool turnPerformed = false;
		
		private bool phasePerformed = false;
		
		private int currentTurn = 0;
		
		private float turnValue = 0;
		
		private float turnValueDummy = 0;
		
		private bool turnEnded = false;
		
		private float timeBar = 0.0f;
		
		private float usedTimeBar = 0.0f;
		
		private float delayTime = 0.0f;
		
		private float delayTimeMax = 0.0f;
		
		private bool isDead = false;
		
		private bool isDefending = false;
		
		private bool enableAutoAttack = true;
		
		
		// aggression
		private bool isAggressive = false;
		
		// list of factions and combatants who attacked.
		private List<Combatant> atkByCombatant = new List<Combatant>();
		
		private List<int> atkByFaction = new List<int>();
		
		
		// abilities
		private CombatantAbilities abilities;
		
		private int lastAbilityID = -1;
		
		private List<AbilityBlock> abilityReuseBlock = new List<AbilityBlock>();
		
		private int attackIndex = 0;
		
		private float baTimeout = -10;
		
		
		// control
		private List<ControlMap> controlMaps;
		
		private MoveAIComponent moveAIComponent = null;
		
		private bool respawnFlag = false;
		
		private float sprintEnergy = 10;
		
		private float sprintEnergyMax = 10;
		
		private float[] moveSpeed = new float[3];
		
		
		// data
		private VariableHandler variableHandler;
		
		private bool rememberPosition = false;
		
		private Vector3 storedPosition = Vector3.zero;
		
		private Vector3 storedRotation = Vector3.zero;
		
		
		// event handlers
		private int markReset = 0;
		
		private int markBoundsCheck = 0;

		private int markHUDUpdate = 0;
		
		public event LevelChanged LevelChanged;
		public event ClassLevelChanged ClassLevelChanged;
		public event ClassChanged ClassChanged;
		public event CombatantChanged Changed;
		public event UpdateHUD UpdateHUD;
		public event CombatantGroupChanged GroupChanged;
		public event CombatantInventoryChanged InventoryChanged;
		
		public Combatant()
		{
			
		}
		
		public Combatant(DataObject data, bool loadPosition, Group g)
		{
			data.Get("realID", ref this.realID);
			this.BaseInit(ORK.Combatants.Get(this.realID), this.realID, g, true);
			this.LoadGame(data);
			if(loadPosition)
			{
				this.LoadPosition(data);
			}
		}
		
		/// <summary>
		/// Determines whether this combatant is player controlled (i.e. part of the player group).
		/// </summary>
		/// <returns>
		/// <c>true</c> if this combatant is controlled by the player; otherwise, <c>false</c>.
		/// </returns>
		public bool IsPlayerControlled()
		{
			return this.Group.IsPlayerControlled();
		}
		
		/// <summary>
		/// Determines whether this combatant is AI controlled, 
		/// i.e. either not part of the player group or an AI controlled player group member.
		/// </summary>
		/// <returns>
		/// <c>true</c> if this combatant is AI controlled; otherwise, <c>false</c>.
		/// </returns>
		public bool IsAIControlled()
		{
			return !this.Group.IsPlayerControlled() || 
				(this.setting.aiControlled && 
					(this.setting.aiControlledPlayer || this != ORK.Game.ActiveGroup.Leader));
		}
		
		/// <summary>
		/// Determines whether this combatant is an enemy the specified combatant.
		/// </summary>
		/// <returns>
		/// <c>true</c> if this combatant is an enemy the specified combatant; otherwise, <c>false</c>.
		/// </returns>
		/// <param name='c'>
		/// The combatant to check.
		/// </param>
		public bool IsEnemy(Combatant c)
		{
			if(c != null)
			{
				return this.Group.IsEnemy(c);
			}
			else
			{
				return false;
			}
		}
		
		/// <summary>
		/// Gets the inventory limit.
		/// </summary>
		/// <returns>
		/// The inventory limit.
		/// </returns>
		public float GetInventoryLimit()
		{
			if(ORK.InventorySettings.limit)
			{
				return ORK.InventorySettings.limitValue.GetValue(this, this) + 
					this.status.GetItemLimitBonus();
			}
			else
			{
				return Mathf.Infinity;
			}
		}
		
		/// <summary>
		/// Notifies all event listeners that something changed.
		/// </summary>
		public void FireChanged()
		{
			if(this.Changed != null)
			{
				this.Changed(this);
			}
			this.FireHUDUpdate();
			this.SetStartEffects();
			this.CheckSpawnedPrefab();
		}
		
		/// <summary>
		/// Notifies all HUD listeners that something changed.
		/// </summary>
		public void FireHUDUpdate()
		{
			this.markHUDUpdate = 0;
			if(this.UpdateHUD != null)
			{
				this.UpdateHUD();
			}
		}
		
		/// <summary>
		/// Notifies all group change listeners that the group changed.
		/// </summary>
		public void FireGroupChanged()
		{
			if(this.GroupChanged != null)
			{
				this.GroupChanged(this);
			}
		}
		
		/// <summary>
		/// Notifies all inventory change listeners that the inventory changed.
		/// </summary>
		public void FireInventoryChanged()
		{
			if(this.InventoryChanged != null)
			{
				this.InventoryChanged(this);
			}
		}
		
		/// <summary>
		/// Marks this combatant for a HUD update in the next Update tick.
		/// </summary>
		public void MarkHUDUpdate()
		{
			this.markHUDUpdate++;
		}
		
		/// <summary>
		/// Called by VariableHandler when a variable changed.
		/// </summary>
		public void VariablesChanged()
		{
			this.SetStartEffects();
			this.CheckSpawnedPrefab();
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public void SetName(string n)
		{
			this.newName = n;
			
			if(this.prefabInstance != null && this.setting.setObjectName)
			{
				this.prefabInstance.name = this.GetName();
			}
		}
	
		public string GetName()
		{
			string n = "";
			if(this.newName != "")
			{
				n = this.newName;
			}
			else
			{
				n = this.setting.GetName();
			}
			if(this.nameCount != "")
			{
				n += " " + this.nameCount;
			}
			return n;
		}
		
		public string GetDescription()
		{
			return this.setting.GetDescription();
		}
		
		public Texture2D GetIcon()
		{
			return this.setting.GetIcon();
		}
		
		public GUIContent GetContent()
		{
			GUIContent g = this.setting.GetContent();
			if(this.newName != "" && g != null)
			{
				g.text = this.newName;
			}
			if(this.nameCount != "" && g != null)
			{
				g.text += " " + this.nameCount;
			}
			return g;
		}
		
		public string GetIconTextCode()
		{
			return TextCode.CombatantIcon + this.realID + "#";
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}

		public int ID
		{
			get{ return this.realID;}
		}
		
		public int TypeID
		{
			get{ return this.ClassID;}
		}
		
		public IContentSimple GetTypeContent()
		{
			return ORK.Classes.Get(this.ClassID);
		}
		
		public Portrait GetPortrait(int typeID)
		{
			return this.setting.GetPortrait(typeID);
		}
		
		
		/*
		============================================================================
		Bestiary settings
		============================================================================
		*/
		public BestiaryEntry Bestiary
		{
			get{ return this.bestiaryEntry;}
			set{ this.bestiaryEntry = value;}
		}
		
		public void FindBestiaryEntry()
		{
			if(this.bestiaryEntry == null)
			{
				this.bestiaryEntry = ORK.Game.Bestiary.GetEntry(this);
			}
		}
		
		
		/*
		============================================================================
		Init
		============================================================================
		*/
		/// <summary>
		/// Handles the basic initialization of the combatant.
		/// </summary>
		/// <param name='cs'>
		/// The CombatantSettings used to initialize the combatant.
		/// </param>
		/// <param name='id'>
		/// The ID (index) of the combatant.
		/// </param>
		/// <param name='g'>
		/// The Group the combatant will be added to.
		/// If null, a new group is created.
		/// </param>
		/// <param name='loadGame'>
		/// <c>true</c> if the initalization comes from loading the game; otherwise, <c>false</c>.
		/// </param>
		public void BaseInit(CombatantSetting cs, int id, Group g, bool loadGame)
		{
			this.setting = cs;
			this.realID = id;
			
			this.status = new CombatantStatus(this);
			this.abilities = new CombatantAbilities(this);
			this.equipment = new CombatantEquipment(this);
			this.actions = new CombatantActions(this);
			this.animations = new CombatantAnimations(this);
			
			// aggressive
			if(AggressionType.Always.Equals(this.setting.aggressionType))
			{
				this.IsAggressive = true;
			}
			
			if(loadGame)
			{
				this.group = g;
				this.group.Abilities.Changed += this.Abilities.GroupAbilitiesChanged;
			}
			else
			{
				this.inventory = new Inventory(this);
				for(int i=0; i<this.setting.money.Length; i++)
				{
					if(this.setting.money[i] > 0)
					{
						this.inventory.AddMoney(i, this.setting.money[i], false, false);
					}
				}
				this.inventory.Add(this.setting.itemDrop, false, false);
				
				if(g == null)
				{
					g = new Group();
				}
				g.Join(this);
			}
		}
		
		/// <summary>
		/// Initializes the combatant with the default start level, class level and class.
		/// Requires the combatant to be base initialized using the BaseInit function.
		/// </summary>
		public void Init()
		{
			this.Init(this.setting.startLevel, this.setting.startClassLevel, this.setting.startClassID);
		}
		
		/// <summary>
		/// Initialize the combatant with a defined level, class level and class.
		/// </summary>
		/// <param name='level'>
		/// The level.
		/// </param>
		/// <param name='classLevel'>
		/// The class level.
		/// </param>
		/// <param name='classID'>
		/// The ID (index) of the class.
		/// </param>
		public void Init(int level, int classLevel, int classID)
		{
			this.currentClassID = classID;
			this.currentLevel = level;
			
			if(this.currentClassLevel.ContainsKey(this.currentClassID))
			{
				this.currentClassLevel[this.currentClassID] = classLevel;
			}
			else
			{
				this.currentClassLevel.Add(this.currentClassID, classLevel);
			}
			
			this.Abilities.UpdateClassAbility();
			this.Equipment.CheckAvailableParts(false);
			
			Class cl = ORK.Classes.Get(this.currentClassID);
			
			this.status.Init(cl.GetStatusDevelopment());
			
			// init level skills
			this.setting.abilityDevelopment.Init(this);
			
			// init class skills
			cl.abilityDevelopment.Init(this);
			
			this.status.SetConsumableStartValues();
			this.status.ResetStatus();
			
			for(int i=0; i<this.setting.startEquipment.Length; i++)
			{
				if(this.setting.startEquipment[i].EquipOn(this))
				{
					break;
				}
			}
			
			this.status.ResetStatus();
			
			this.Equipment.CheckAvailableParts(true);
			this.status.SetConsumableStartValues();
			ORK.StatusEffects.CheckAuto(this);
			ORK.StatusEffects.RegisterStatusChanges(this);
			
			// init shortcuts
			if(this.setting.useClassShortcuts)
			{
				if(this.classShortcutList.ContainsKey(this.currentClassID))
				{
					this.shortcutList = this.classShortcutList[this.currentClassID];
				}
				else
				{
					this.shortcutList = new CombatantShortcuts[cl.shortcutListCount];
					for(int i=0; i<this.shortcutList.Length; i++)
					{
						this.shortcutList[i] = new CombatantShortcuts(this);
					}
					
					// set default shortcuts
					for(int i=0; i<cl.defaultShortcut.Length; i++)
					{
						cl.defaultShortcut[i].Assign(this);
					}
				}
			}
			else
			{
				this.shortcutList = new CombatantShortcuts[this.setting.shortcutListCount];
				for(int i=0; i<this.shortcutList.Length; i++)
				{
					this.shortcutList[i] = new CombatantShortcuts(this);
				}
				
				// set default shortcuts
				for(int i=0; i<this.setting.defaultShortcut.Length; i++)
				{
					this.setting.defaultShortcut[i].Assign(this);
				}
			}
			
			this.isInitialized = true;
			this.SetStartEffects();
		}
		
		/// <summary>
		/// Changes the combatant's class.
		/// </summary>
		/// <param name='classID'>
		/// The ID (index) of the class.
		/// </param>
		/// <param name='forgetAbilities'>
		/// <c>true</c> if the abilities learned from the previous class should be forgotten; otherwise, <c>false</c>.
		/// </param>
		/// <param name='learnAbilities'>
		/// <c>true</c> if the abilities of the new class should be learned; otherwise, <c>false</c>.
		/// </param>
		/// <param name='resetClassLevel'>
		/// <c>true</c> if the class level of the new class should be reset to the start class level; otherwise, <c>false</c>.
		/// </param>
		/// <param name='removeOldBonus'>
		/// <c>true</c> if the bonuses of the previous class should be forgotten; otherwise, <c>false</c>.
		/// </param>
		/// <param name='statusBonus'>
		/// <c>true</c> if the bonuses of the new class should be learned; otherwise, <c>false</c>.
		/// </param>
		/// <param name='resetAtkAttrStart'>
		/// <c>true</c> if the attack attribute start values of the previous class should be forgotten; otherwise, <c>false</c>.
		/// </param>
		/// <param name='resetDefAttrStart'>
		/// <c>true</c> if the defence attribute start values of the previous class should be forgotten; otherwise, <c>false</c>.
		/// </param>
		public void ChangeClass(int classID, bool forgetAbilities, bool learnAbilities, 
				bool resetClassLevel, bool removeOldBonus, bool statusBonus, 
				bool resetAtkAttrStart, bool resetDefAttrStart)
		{
			this.controlMaps = null;
			this.equipment.UnequipAll(this.Inventory);
			
			// store current class level exp
			for(int i=0; i<ORK.StatusValues.Count; i++)
			{
				if(this.status[i].IsClassLevel())
				{
					if(!this.classLevelExp.ContainsKey(this.currentClassID))
					{
						this.classLevelExp.Add(this.currentClassID, this.status[i].GetBaseValue());
					}
					else
					{
						this.classLevelExp[this.currentClassID] = this.status[i].GetBaseValue();
					}
				}
			}
			
			Class oldClass = ORK.Classes.Get(this.currentClassID);
			StatusDevelopment oldClassStatDev = oldClass.GetStatusDevelopment();
			
			// remove old attribute start values
			if(resetAtkAttrStart)
			{
				for(int i=0; i<ORK.AttackAttributes.Count; i++)
				{
					AttackAttribute atkAttr = this.status.GetAttackAttribute(i);
					for(int j=0; j<atkAttr.Count; j++)
					{
						atkAttr.AddBaseValue(j, -atkAttr.GetStartValue(j));
					}
				}
			}
			if(resetDefAttrStart)
			{
				for(int i=0; i<ORK.DefenceAttributes.Count; i++)
				{
					DefenceAttribute defAttr = this.status.GetDefenceAttribute(i);
					for(int j=0; j<defAttr.Count; j++)
					{
						defAttr.AddBaseValue(j, -defAttr.GetStartValue(j));
					}
				}
			}
			
			int prevClassID = this.currentClassID;
			this.currentClassID = classID;
			if(!this.currentClassLevel.ContainsKey(this.currentClassID))
			{
				this.currentClassLevel.Add(this.currentClassID, this.setting.startClassLevel);
			}
			this.Abilities.UpdateClassAbility();
			this.Equipment.CheckAvailableParts(false);
			
			Class newClass = ORK.Classes.Get(this.currentClassID);
			StatusDevelopment classStatDev = newClass.GetStatusDevelopment();
			
			// add new attribute start value
			if(resetAtkAttrStart)
			{
				for(int i=0; i<ORK.AttackAttributes.Count; i++)
				{
					AttackAttribute atkAttr = this.status.GetAttackAttribute(i);
					for(int j=0; j<atkAttr.Count; j++)
					{
						atkAttr.AddBaseValue(j, atkAttr.GetStartValue(j));
					}
				}
			}
			if(resetDefAttrStart)
			{
				for(int i=0; i<ORK.DefenceAttributes.Count; i++)
				{
					DefenceAttribute defAttr = this.status.GetDefenceAttribute(i);
					for(int j=0; j<defAttr.Count; j++)
					{
						defAttr.AddBaseValue(j, defAttr.GetStartValue(j));
					}
				}
			}
			
			// abilities
			if(forgetAbilities)
			{
				oldClass.abilityDevelopment.Forget(this);
			}
			
			// remove old bonus
			if(removeOldBonus && oldClassStatDev != null)
			{
				for(int i=0; i<ORK.StatusValues.Count; i++)
				{
					if(this.status[i].IsNormal())
					{
						int value = -oldClassStatDev.GetValueAtLevel(i, this.ClassLevel);
						this.status[i].AddBaseValue(value);
						this.status[i].AddValue(value, false, true, true, false, false, false);
					}
				}
			}
			
			// reset class level
			if(resetClassLevel && newClass.useClassLevel)
			{
				this.currentClassLevel[this.currentClassID] = this.setting.startClassLevel;
			}
			
			// add new bonus
			if(classStatDev != null)
			{
				for(int i=0; i<ORK.StatusValues.Count; i++)
				{
					if(this.status[i].IsClassLevel())
					{
						int value = 0;
						if(this.classLevelExp.ContainsKey(this.currentClassID))
						{
							value = this.classLevelExp[this.currentClassID];
						}
						else
						{
							value = classStatDev.GetValueAtLevel(i, this.ClassLevel);
						}
						
						this.status[i].InitValue(value);
					}
					else if(this.status[i].IsNormal() && statusBonus)
					{
						int value = classStatDev.GetValueAtLevel(i, this.ClassLevel);
						
						if(value != 0)
						{
							this.status[i].AddBaseValue(value);
							this.status[i].AddValue(value, false, true, true, false, false, false);
						}
					}
				}
			}
			
			if(learnAbilities)
			{
				newClass.abilityDevelopment.Init(this);
			}
			this.Equipment.CheckAvailableParts(true);
			
			
			// update shortcuts
			if(this.setting.useClassShortcuts)
			{
				if(this.classShortcutList.ContainsKey(prevClassID))
				{
					this.classShortcutList[prevClassID] = this.shortcutList;
				}
				else
				{
					this.classShortcutList.Add(prevClassID, this.shortcutList);
				}
				
				if(this.classShortcutList.ContainsKey(this.currentClassID))
				{
					this.shortcutList = this.classShortcutList[this.currentClassID];
				}
				else
				{
					this.shortcutList = new CombatantShortcuts[newClass.shortcutListCount];
					for(int i=0; i<this.shortcutList.Length; i++)
					{
						this.shortcutList[i] = new CombatantShortcuts(this);
					}
					
					// set default shortcuts
					for(int i=0; i<newClass.defaultShortcut.Length; i++)
					{
						newClass.defaultShortcut[i].Assign(this);
					}
				}
			}
			
			this.markReset++;
			
			// notify
			if(this.ClassChanged != null)
			{
				this.ClassChanged(this, this.currentClassID);
			}
			this.FireChanged();
		}
		
		/// <summary>
		/// Marks this combatant for a status recalculation in the next Update tick.
		/// </summary>
		public void MarkResetStatus()
		{
			this.markReset++;
		}
		
		/// <summary>
		/// Marks this combatant for a status value bounds theck in the next Update tick.
		/// </summary>
		public void MarkStatusBoundsCheck()
		{
			this.markBoundsCheck++;
		}
		
		/// <summary>
		/// Sets the group of this combatant.
		/// </summary>
		/// <param name='g'>
		/// The Group.
		/// </param>
		public void SetGroup(Group g)
		{
			if(this.group != g)
			{
				if(this.group != null)
				{
					this.group.Remove(this, false, false);
					this.group.Abilities.Changed -= this.Abilities.GroupAbilitiesChanged;
				}
				this.group = g;
				if(this.group == null && 
					this.inventory == null)
				{
					this.inventory = new Inventory(this);
				}
				else if(this.group != null && 
					this.group.IsPlayerControlled() &&
					ORK.InventorySettings.IsGroup())
				{
					this.group.Inventory.Add(this.inventory);
					this.inventory = null;
				}
				
				if(this.group != null)
				{
					this.group.Abilities.Changed += this.Abilities.GroupAbilitiesChanged;
				}
				this.Abilities.GroupAbilitiesChanged(this.group);
				this.FireChanged();
				this.FireGroupChanged();
			}
		}
		
		
		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public CombatantSetting Setting
		{
			get{ return this.setting;}
		}
		
		public int RealID
		{
			get{ return this.realID;}
			set{ this.realID = value;}
		}
		
		public Group Group
		{
			get
			{
				if(this.group == null)
				{
					new Group().Join(this);
				}
				return this.group;
			}
		}
		
		public bool IsLeader
		{
			get{ return this == this.Group.Leader;}
		}
		
		public bool IsTemporary
		{
			get{ return this.isTemporary;}
			set{ this.isTemporary = value;}
		}
		
		public CombatantStatus Status
		{
			get{ return this.status;}
		}
		
		public CombatantAbilities Abilities
		{
			get{ return this.abilities;}
		}
		
		public CombatantEquipment Equipment
		{
			get{ return this.equipment;}
		}
		
		public CombatantActions Actions
		{
			get{ return this.actions;}
		}
		
		public CombatantAnimations Animations
		{
			get{ return this.animations;}
		}
		
		public int ClassID
		{
			get{ return this.currentClassID;}
		}
		
		public int Level
		{
			get{ return this.currentLevel;}
		}
		
		public int MaxLevel
		{
			get
			{
				if(!this.setting.noStatusDevelopment)
				{
					return ORK.StatusDevelopments.Get(this.setting.statusDevelopmentID).maxLevel;
				}
				else
				{
					return this.currentLevel;
				}
			}
		}
		
		public int ClassLevel
		{
			get
			{
				if(!this.currentClassLevel.ContainsKey(this.currentClassID))
				{
					this.currentClassLevel.Add(this.currentClassID, this.setting.startClassLevel);
				}
				return this.currentClassLevel[this.currentClassID];
			}
		}
		
		public int MaxClassLevel
		{
			get
			{
				Class cl = ORK.Classes.Get(this.ClassID);
				if(cl.useClassLevel)
				{
					return cl.GetStatusDevelopment().maxLevel;
				}
				else
				{
					return this.ClassLevel;
				}
			}
		}
		
		public string NameCount
		{
			get{ return this.nameCount;}
			set
			{
				this.nameCount = value;
				
				if(this.prefabInstance != null && this.setting.setObjectName)
				{
					this.prefabInstance.name = this.GetName();
				}
			}
		}
		
		// inventory
		public Inventory Inventory
		{
			get
			{
				if(this.inventory != null)
				{
					return this.inventory;
				}
				else
				{
					return this.Group.Inventory;
				}
			}
		}
		
		public bool ItemStolen
		{
			get{ return this.itemStolen;}
			set{ this.itemStolen = value;}
		}
		
		public bool MoneyStolen
		{
			get{ return this.moneyStolen;}
			set{ this.moneyStolen = value;}
		}
		
		// battle
		public bool InBattle
		{
			get{ return this.inBattle;}
		}
		
		public ActiveBattleMenu BattleMenu
		{
			get
			{
				if(this.Group.IsPlayerControlled())
				{
					if(this.battleMenu == null || this.battleMenu.MenuID != this.BattleMenuID)
					{
						this.battleMenu = new ActiveBattleMenu(this, this.BattleMenuID);
					}
				}
				else
				{
					this.battleMenu = null;
				}
				return this.battleMenu;
			}
		}
		
		public int BattleMenuID
		{
			get
			{
				// combatant battle menu
				if(this.setting.ownBM)
				{
					if(this.setting.useTurnBasedMenu && ORK.Battle.IsTurnBased())
					{
						return this.setting.turnBasedMenuID;
					}
					else if(this.setting.useActiveTimeMenu && ORK.Battle.IsActiveTime())
					{
						return this.setting.activeTimeMenuID;
					}
					else if(this.setting.useRealTimeMenu && ORK.Battle.IsRealTime())
					{
						return this.setting.realTimeMenuID;
					}
					else if(this.setting.usePhaseMenu && ORK.Battle.IsPhase())
					{
						return this.setting.phaseMenuID;
					}
					return this.setting.menuID;
				}
				// class battle menu
				else
				{
					Class cl = ORK.Classes.Get(this.ClassID);
					if(cl.ownBM)
					{
						if(cl.useTurnBasedMenu && ORK.Battle.IsTurnBased())
						{
							return cl.turnBasedMenuID;
						}
						else if(cl.useActiveTimeMenu && ORK.Battle.IsActiveTime())
						{
							return cl.activeTimeMenuID;
						}
						else if(cl.useRealTimeMenu && ORK.Battle.IsRealTime())
						{
							return cl.realTimeMenuID;
						}
						else if(cl.usePhaseMenu && ORK.Battle.IsPhase())
						{
							return cl.phaseMenuID;
						}
						return cl.menuID;
					}
				}
				// default battle menu
				if(ORK.BattleSettings.useTurnBasedMenu && ORK.Battle.IsTurnBased())
				{
					return ORK.BattleSettings.turnBasedMenuID;
				}
				else if(ORK.BattleSettings.useActiveTimeMenu && ORK.Battle.IsActiveTime())
				{
					return ORK.BattleSettings.activeTimeMenuID;
				}
				else if(ORK.BattleSettings.useRealTimeMenu && ORK.Battle.IsRealTime())
				{
					return ORK.BattleSettings.realTimeMenuID;
				}
				else if(ORK.BattleSettings.usePhaseMenu && ORK.Battle.IsPhase())
				{
					return ORK.BattleSettings.phaseMenuID;
				}
				return ORK.BattleSettings.menuID;
			}
		}
		
		public List<Combatant> LastTargets
		{
			get
			{
				if(this.lastTargets == null)
				{
					this.lastTargets = new List<Combatant>();
				}
				return this.lastTargets;
			}
			set
			{
				if(value != null)
				{
					this.lastTargets = new List<Combatant>(value);
				}
				else
				{
					this.lastTargets = new List<Combatant>();
				}
			}
		}
		
		public SelectedTargets SelectedTargets
		{
			get
			{
				if(this.selectedTargets == null)
				{
					this.selectedTargets = new SelectedTargets(this);
				}
				return this.selectedTargets;
			}
		}
		
		public int LastTurnIndex
		{
			get{ return this.lastTurnIndex;}
			set{ this.lastTurnIndex = value;}
		}
		
		public bool TurnPerformed
		{
			get{ return this.turnPerformed;}
			set{ this.turnPerformed = value;}
		}
		
		public int Turn
		{
			get{ return this.currentTurn;}
		}
		
		public float TurnValue
		{
			get{ return this.turnValue;}
			set
			{
				if(this.turnValue != value)
				{
					this.turnValue = value;
					this.FireHUDUpdate();
				}
			}
		}
		
		public float TurnValueDummy
		{
			get{ return this.turnValueDummy;}
			set{ this.turnValueDummy = value;}
		}
		
		public float TimeBar
		{
			get{ return this.timeBar;}
			set
			{
				if(this.timeBar != value)
				{
					this.timeBar = value;
					if(this.timeBar < 0)
					{
						this.timeBar = 0;
					}
					this.MarkHUDUpdate();
				}
			}
		}
		
		public float UsedTimeBar
		{
			get{ return this.usedTimeBar;}
			set
			{
				this.usedTimeBar = value;
				if(this.usedTimeBar < 0)
				{
					this.usedTimeBar = 0;
				}
			}
		}
		
		public float DelayTime
		{
			get{ return this.delayTime;}
			set
			{
				if(this.delayTime != value)
				{
					this.delayTime = value;
					if(this.delayTime < 0)
					{
						this.delayTime = 0;
					}
					this.delayTimeMax = this.delayTime;
					this.MarkHUDUpdate();
				}
			}
		}
		
		public float DelayTimeMax
		{
			get{ return this.delayTimeMax;}
		}
		
		public bool PhasePerformed
		{
			get{ return this.phasePerformed;}
			set{ this.phasePerformed = value;}
		}
		
		public bool Dead
		{
			get{ return this.isDead;}
			set{ this.isDead = value;}
		}
		
		public bool Defending
		{
			get{ return this.isDefending;}
			set{ this.isDefending = value;}
		}
		
		public bool IsAggressive
		{
			get{ return this.isAggressive;}
			set
			{
				if(this.isAggressive != value)
				{
					this.isAggressive = value;
					if(this.setting.aggressionNotifyGroup)
					{
						this.Group.AggressionChangeGroup(this);
					}
					if(this.setting.aggressionNotifyFaction)
					{
						List<Group> list = ORK.Game.Combatants.GetFactionGroups(this.Group.FactionID);
						for(int i=0; i<list.Count; i++)
						{
							list[i].AggressionChangeFaction(this);
						}
					}
				}
			}
		}
		
		// ability
		public int LastAbilityID
		{
			get{ return this.lastAbilityID;}
			set{ this.lastAbilityID = value;}
		}
		
		public bool RespawnFlag
		{
			get{ return this.respawnFlag;}
			set{ this.respawnFlag = value;}
		}
		
		public int AttackIndex
		{
			get{ return this.attackIndex;}
			set{ this.attackIndex = value;}
		}
		
		// control
		public MoveAIComponent MoveAI
		{
			get{ return this.moveAIComponent;}
		}
		
		public float SprintEnergy
		{
			get{ return this.sprintEnergy;}
			set{ this.sprintEnergy = value;}
		}
		
		public float SprintEnergyMax
		{
			get{ return this.sprintEnergyMax;}
			set{ this.sprintEnergyMax = value;}
		}
		
		public float GetCounterChance(Combatant target)
		{
			return this.setting.counterChance.GetValue(this, target) + 
				this.status.GetCounterBonus();
		}
		
		public float GetBlockChance(Combatant user)
		{
			return this.setting.blockChance.GetValue(user, this) + 
				this.status.GetBlockBonus();
		}
		
		public float GetEscapeChance()
		{
			return ORK.BattleSettings.escapeChance.GetValue(this, this) + 
				this.status.GetEscapeBonus();
		}
		
		public float ExperienceFactor
		{
			get
			{
				return Mathf.Max(0, 
					this.setting.experienceFactor.GetValue(this, this) + 
						this.status.GetExperienceFactorBonus());
			}
		}
		
		
		/*
		============================================================================
		Shortcut functions
		============================================================================
		*/
		public CombatantShortcuts Shortcuts
		{
			get
			{
				if(this.shortcutIndex >= 0 && this.shortcutIndex < this.shortcutList.Length)
				{
					return this.shortcutList[this.shortcutIndex];
				}
				else
				{
					return this.shortcutList[0];
				}
			}
		}
		
		public CombatantShortcuts GetShortcutList(int index)
		{
			if(index >= 0 && index < this.shortcutList.Length)
			{
				return this.shortcutList[index];
			}
			return null;
		}
		
		public void ChangeShortcutList(int change, bool loop)
		{
			this.shortcutIndex += change;
			
			if(this.shortcutIndex < 0)
			{
				this.shortcutIndex = loop ? this.shortcutList.Length - 1 : 0;
			}
			else if(this.shortcutIndex >= this.shortcutList.Length)
			{
				this.shortcutIndex = loop ?  0 : this.shortcutList.Length - 1;
			}
			this.FireHUDUpdate();
		}
		
		public void SetShortcutList(int index)
		{
			this.shortcutIndex = index;
			
			if(this.shortcutIndex < 0)
			{
				this.shortcutIndex = 0;
			}
			else if(this.shortcutIndex >= this.shortcutList.Length)
			{
				this.shortcutIndex = this.shortcutList.Length - 1;
			}
			this.FireHUDUpdate();
		}
		
		
		/*
		============================================================================
		Level functions
		============================================================================
		*/
		public string CheckLevelUp()
		{
			string changes = "";
			Class c = ORK.Classes.Get(this.currentClassID);
			StatusDevelopment classStatDev = c.GetStatusDevelopment();
			string lvlText = "";
			string cLvlText = "";
			
			for(int i=0; i<ORK.StatusValues.Count; i++)
			{
				// base level up
				if(!this.setting.noStatusDevelopment && 
					this.status[i].IsBaseLevel())
				{
					while(this.currentLevel < ORK.StatusDevelopments.Get(this.setting.statusDevelopmentID).maxLevel && 
						this.status[i].GetValue() >= this.status.GetValueAtLevel(i, this.currentLevel + 1))
					{
						lvlText = this.LevelUp();
						
						if(lvlText != "")
						{
							if(changes != "")
							{
								changes += TextCode.NextPage;
							}
							changes += lvlText;
						}
					}
				}
				
				// class level up
				if(classStatDev != null && this.status[i].IsClassLevel())
				{
					while(this.ClassLevel < classStatDev.maxLevel && 
						this.status[i].GetValue() >= classStatDev.GetValueAtLevel(i, this.ClassLevel + 1))
					{
						cLvlText = this.ClassLevelUp();
						
						if(cLvlText != "")
						{
							if(changes != "")
							{
								changes += TextCode.NextPage;
							}
							changes += cLvlText;
						}
					}
				}
			}
			return changes;
		}
		
		public string ForceLevelUp()
		{
			string changes = "";
			for(int i=0; i<ORK.StatusValues.Count; i++)
			{
				if(this.status[i].IsBaseLevel())
				{
					this.status[i].SetValue(this.status.GetValueAtLevel(i, this.currentLevel + 1), 
						false, true, false, false, false, false);
				}
			}
			string tmp = this.LevelUp();
			if("" != tmp)
			{
				changes = tmp;
			}
			return changes;
		}
		
		public string ForceClassLevelUp()
		{
			string changes = "";
			StatusDevelopment classStatDev = ORK.Classes.Get(this.currentClassID).GetStatusDevelopment();
			if(classStatDev != null)
			{
				for(int i=0; i<ORK.StatusValues.Count; i++)
				{
					if(this.status[i].IsClassLevel())
					{
						this.status[i].SetValue(classStatDev.GetValueAtLevel(i, this.ClassLevel + 1), 
							false, true, false, false, false, false);
					}
				}
				string tmp = this.ClassLevelUp();
				if("" != tmp)
				{
					changes = tmp;
				}
			}
			return changes;
		}
		
		public string LevelUp()
		{
			string changes = "";
			StatusDevelopment statDev = ORK.StatusDevelopments.Get(this.setting.statusDevelopmentID);
			if(statDev != null && this.currentLevel < statDev.maxLevel)
			{
				this.currentLevel++;
				if(ORK.BattleTexts.useLevelUpNotification && ORK.BattleTexts.levelUpTextSettings != null)
				{
					ORK.BattleTexts.levelUpTextSettings.ShowText(this.currentLevel.ToString(), this.GameObject);
				}
				
				string levelText = ORK.BattleEnd.GetLevelUpText(this, this.currentLevel);
				string statusText = statDev.IncreaseStatus(this, this.currentLevel, true);
				string abilityText = this.setting.abilityDevelopment.Learn(this);
				
				if(!ORK.Classes.Get(this.currentClassID).useClassLevel)
				{
					string tmp = ORK.Classes.Get(this.currentClassID).abilityDevelopment.Learn(this);
					if("" != tmp)
					{
						abilityText += tmp;
					}
				}
				changes = ORK.BattleEnd.GetLevelText(levelText, statusText, abilityText);
				
				if(ORK.ConsoleSettings.displayLevelUp)
				{
					if(this.setting.ownConsoleLevelUp)
					{
						this.setting.consoleLevelUp.Print(this, ORK.Classes.Get(this.ClassID), this.currentLevel);
					}
					else
					{
						ORK.ConsoleSettings.levelUp.Print(this, ORK.Classes.Get(this.ClassID), this.currentLevel);
					}
				}
				
				// level up bonuses
				if(this.setting.ownLvlUp)
				{
					this.setting.lvlUp.LevelUp(this);
				}
				else
				{
					ORK.BattleSettings.lvlUp.LevelUp(this);
				}
				
				// notify
				if(this.LevelChanged != null)
				{
					this.LevelChanged(this, this.currentLevel);
				}
				this.FireChanged();
			}
			return changes;
		}
		
		public string ClassLevelUp()
		{
			string changes = "";
			Class c = ORK.Classes.Get(this.currentClassID);
			StatusDevelopment classStatDev = c.GetStatusDevelopment();
			if(classStatDev != null && this.ClassLevel < classStatDev.maxLevel)
			{
				this.currentClassLevel[this.currentClassID]++;
				if(ORK.BattleTexts.useClassLevelUpNotification && ORK.BattleTexts.classLevelUpTextSettings != null)
				{
					ORK.BattleTexts.classLevelUpTextSettings.ShowText(this.ClassLevel.ToString(), this.GameObject);
				}
				
				string levelText = ORK.BattleEnd.GetClassLevelUpText(
					this, this.currentClassID, this.ClassLevel);
				string statusText = classStatDev.IncreaseStatus(this, this.ClassLevel, false);
				string abilityText = c.abilityDevelopment.Learn(this);
				
				changes = ORK.BattleEnd.GetLevelText(levelText, statusText, abilityText);
				
				if(ORK.ConsoleSettings.displayLevelUp)
				{
					if(this.setting.ownConsoleLevelUpClass)
					{
						this.setting.consoleLevelUpClass.Print(this, ORK.Classes.Get(this.ClassID), this.currentClassLevel[this.currentClassID]);
					}
					else
					{
						ORK.ConsoleSettings.levelUpClass.Print(this, ORK.Classes.Get(this.ClassID), this.currentClassLevel[this.currentClassID]);
					}
				}
				
				// level up bonuses
				if(c.ownLvlUp)
				{
					c.lvlUp.LevelUp(this);
				}
				else
				{
					ORK.BattleSettings.cLvlUp.LevelUp(this);
				}
				
				// notify
				if(this.ClassLevelChanged != null)
				{
					this.ClassLevelChanged(this, this.currentClassLevel[this.currentClassID]);
				}
				this.FireChanged();
			}
			return changes;
		}
		
		
		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public string PrefabRoot
		{
			get
			{
				if(this.prefabIndex >= 0 && this.prefabIndex < this.setting.conditionalPrefab.Length)
				{
					return this.setting.conditionalPrefab[this.prefabIndex].prefabRoot;
				}
				else
				{
					return this.setting.prefabRoot;
				}
			}
		}
		
		public Vector3 SpawnOffset
		{
			get
			{
				if(this.prefabIndex >= 0 && this.prefabIndex < this.setting.conditionalPrefab.Length)
				{
					return this.setting.conditionalPrefab[this.prefabIndex].spawnOffset;
				}
				else
				{
					return this.setting.spawnOffset;
				}
			}
		}
		
		public float BoxRadius
		{
			get
			{
				if(this.prefabIndex >= 0 && this.prefabIndex < this.setting.conditionalPrefab.Length)
				{
					return this.setting.conditionalPrefab[this.prefabIndex].boxRadius;
				}
				else
				{
					return this.setting.boxRadius;
				}
			}
		}
		
		public GameObject GameObject
		{
			get{ return this.prefabInstance;}
			set
			{
				this.prefabInstance = value;
				
				if(this.prefabInstance != null)
				{
					if(this.setting.setObjectName)
					{
						this.prefabInstance.name = this.GetName();
					}
					
					this.prefabInstance = TransformHelper.GetChild(
						this.PrefabRoot, this.prefabInstance.transform).gameObject;
					
					this.status.AddComponents();
					
					// get a renderer for object bound HUDs
					this.renderer = this.prefabInstance.transform.root.GetComponentInChildren<Renderer>();
					
					this.combatantComponent = this.prefabInstance.AddComponent<CombatantComponent>();
					this.combatantComponent.combatant = this;
					
					// move AI
					if(this.Group.Spawner != null && 
						this.Group.Spawner.OwnMoveAI(this.Group.SpawnerIndex))
					{
						int index = this.Group.Spawner.GetMoveAI(this.Group.SpawnerIndex);
						if(index >= 0)
						{
							this.moveAIComponent = ORK.MoveAIs.Get(index).AddAIMover(this);
						}
					}
					else if(this.setting.useMoveAI && 
						(this.Group.Spawner == null || 
							!this.Group.Spawner.IsBlockMoveAI(this.Group.SpawnerIndex)))
					{
						this.moveAIComponent = ORK.MoveAIs.Get(this.setting.moveID).AddAIMover(this);
					}
					
					this.animations.UpdateGameObject();
					
					if(this.setting.useObjectVariables)
					{
						ObjectVariablesComponent comp = this.setting.objectVariables.AddComponent(this.prefabInstance);
						if(comp != null && (comp.localVariables || comp.objectID == ""))
						{
							if(this.variableHandler != null)
							{
								comp.SetHandler(this.variableHandler);
							}
							else
							{
								this.variableHandler = comp.GetHandler();
							}
						}
					}
					
					// register object variable changes
					if(this.setting.conditionalPrefab.Length > 0)
					{
						ObjectVariablesComponent[] comps = this.prefabInstance.GetComponentsInChildren<ObjectVariablesComponent>();
						for(int i=0; i<comps.Length; i++)
						{
							comps[i].GetHandler().Changed += this.VariablesChanged;
						}
						this.CheckSpawnedPrefab();
					}
				}
				else
				{
					this.combatantComponent = null;
				}
				
				this.OpenHUD();
			}
		}
		
		public void SetGameObjectSimple(GameObject gameObject)
		{
			this.prefabInstance = gameObject;
		}
		
		public CombatantComponent Component
		{
			get{ return this.combatantComponent;}
		}
		
		public GameObject BattleSpot
		{
			get
			{
				if(this.battleSpot == null && this.prefabInstance != null)
				{
					return this.prefabInstance;
				}
				else
				{
					return this.battleSpot;
				}
			}
			set{ this.battleSpot = value;}
		}
		
		public GameObject CursorObject
		{
			get{ return this.cursorInstance;}
			set{ this.cursorInstance = value;}
		}
		
		public void CheckSpawnedPrefab()
		{
			if(this.prefabInstance != null)
			{
				int tmp = -1;
				this.setting.GetPrefab(this, ref tmp);
				
				if(tmp != this.prefabIndex)
				{
					this.Spawn(this.prefabInstance.transform.position, 
						true, this.prefabInstance.transform.eulerAngles.y, 
						tmp >= 0 && tmp < this.setting.conditionalPrefab.Length ? 
							this.setting.conditionalPrefab[tmp].useSpawnedScale : true, 
						this.prefabInstance.transform.localScale);
					
					if(this == ORK.Game.ActiveGroup.Leader)
					{
						ORK.GameControls.AddPlayerComponents(this);
					}
				}
			}
		}
		
		public GameObject GetRealRootObject()
		{
			if(this.prefabInstance != null)
			{
				return this.prefabInstance.transform.root.gameObject;
			}
			else
			{
				return null;
			}
		}
		
		public void DestroyPrefab()
		{
			this.renderer = null;
			this.ClearHUD();
			if(this.prefabInstance != null)
			{
				// unregister object variable changes
				if(this.setting.conditionalPrefab.Length > 0)
				{
					ObjectVariablesComponent[] comps = this.prefabInstance.GetComponentsInChildren<ObjectVariablesComponent>();
					for(int i=0; i<comps.Length; i++)
					{
						comps[i].GetHandler().Changed -= this.VariablesChanged;
					}
				}
				
				GameObject.Destroy(this.GetRealRootObject());
			}
			if(this.cursorInstance != null)
			{
				GameObject.Destroy(this.cursorInstance);
			}
		}
		
		public float DistanceTo(Combatant combatant, bool ignoreYDistance, bool ignoreComRad)
		{
			if(this.GameObject != null && combatant.GameObject != null)
			{
				return VectorHelper.Distance(
						this.GameObject.transform.position, 
						combatant.GameObject.transform.position, ignoreYDistance) - 
					(ignoreComRad ? (this.BoxRadius + combatant.BoxRadius) : 0);
			}
			else
			{
				return Mathf.Infinity;
			}
		}
		
		public void StorePosition()
		{
			if(this.prefabInstance != null && 
				this.rememberPosition)
			{
				this.storedPosition = this.prefabInstance.transform.position;
				this.storedRotation = this.prefabInstance.transform.eulerAngles;
			}
		}
		
		public bool RememberPosition
		{
			get{ return this.rememberPosition;}
			set{ this.rememberPosition = value;}
		}
		
		
		/*
		============================================================================
		Spawn functions
		============================================================================
		*/
		public GameObject Spawn(Vector3 position, bool setRotation, float yRotation, bool setScale, Vector3 scale)
		{
			this.DestroyPrefab();
			GameObject prefab = this.setting.GetPrefab(this, ref prefabIndex);
			if(prefab != null)
			{
				this.GameObject = (GameObject)GameObject.Instantiate(prefab);
			}
			this.PlaceAt(position, setRotation, yRotation, setScale, scale);
			return this.prefabInstance;
		}
		
		public void PlaceAt(Vector3 position, bool setRotation, float yRotation, bool setScale, Vector3 scale)
		{
			if(this.GameObject != null)
			{
				this.prefabInstance.transform.position = position + this.SpawnOffset;
				if(setRotation)
				{
					Vector3 ea = this.GameObject.transform.eulerAngles;
					ea.y = yRotation;
					this.prefabInstance.transform.eulerAngles = ea;
				}
				if(setScale)
				{
					this.prefabInstance.transform.localScale = scale;
				}
			}
		}
		
		
		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public AudioSource GetAudioSource()
		{
			AudioSource audio = null;
			if(this.prefabInstance != null)
			{
				audio = this.prefabInstance.GetComponent<AudioSource>();
				if(audio == null)
				{
					audio = this.prefabInstance.GetComponentInChildren<AudioSource>();
				}
				if(audio == null)
				{
					audio = this.prefabInstance.AddComponent<AudioSource>();
				}
			}
			return audio;
		}
		
		
		/*
		============================================================================
		Movement functions
		============================================================================
		*/
		public float GetMoveSpeed(MoveSpeedType moveType)
		{
			if(MoveSpeedType.Walk.Equals(moveType))
			{
				return this.moveSpeed[0];
			}
			else if(MoveSpeedType.Run.Equals(moveType))
			{
				return this.moveSpeed[1];
			}
			else if(MoveSpeedType.Sprint.Equals(moveType))
			{
				return this.moveSpeed[2];
			}
			return 0;
		}
		
		public void UpdateMoveSpeed()
		{
			this.moveSpeed = new float[] {
				this.setting.moveSettings.GetWalkSpeed(this), 
				this.setting.moveSettings.GetRunSpeed(this), 
				this.setting.moveSettings.GetSprintSpeed(this)
			};
		}
		
		
		/*
		============================================================================
		Base attack functions
		============================================================================
		*/
		public AbilityShortcut GetCurrentBaseAttack()
		{
			for(int i=0; i<ORK.EquipmentParts.Count; i++)
			{
				if(this.equipment[i].Equipped)
				{
					AbilityShortcut ab = this.equipment[i].Equipment.GetCurrentBaseAttack(this.attackIndex);
					if(ab != null)
					{
						return ab;
					}
				}
			}
			return this.abilities.GetBaseAttack(ref this.attackIndex);
		}
		
		public AbilityShortcut GetBaseAttack(int index)
		{
			for(int i=0; i<ORK.EquipmentParts.Count; i++)
			{
				if(this.equipment[i].Equipped)
				{
					AbilityShortcut ab = this.equipment[i].Equipment.GetCurrentBaseAttack(index);
					if(ab != null)
					{
						return ab;
					}
				}
			}
			return this.abilities.GetBaseAttack(ref index);
		}
		
		public void NextBaseAttack()
		{
			this.attackIndex++;
			bool found = false;
			for(int i=0; i<ORK.EquipmentParts.Count; i++)
			{
				if(this.equipment[i].Equipped && 
					this.equipment[i].Equipment.CheckNextBaseAttack(ref this.attackIndex, ref this.baTimeout))
				{
					found = true;
					break;
				}
			}
			if(!found)
			{
				AbilityShortcut attack = this.abilities.GetBaseAttack(ref this.attackIndex);
				if(attack != null)
				{
					float bat = attack.GetAvailableTime();
					if(bat > 0)
					{
						this.baTimeout = bat;
					}
					else
					{
						this.baTimeout = -10;
					}
				}
			}
		}
		
		public void ResetBaseAttack()
		{
			this.attackIndex = 0;
			this.baTimeout = -10;
		}
		
		public bool InAttackRange(Combatant target)
		{
			AbilityShortcut ab = this.GetCurrentBaseAttack();
			return ab.InRange(this, target);
		}
		
		public AbilityShortcut GetCounterAttack()
		{
			for(int i=0; i<ORK.EquipmentParts.Count; i++)
			{
				if(this.equipment[i].Equipped)
				{
					AbilityShortcut ability = this.equipment[i].Equipment.GetCounterAttack();
					if(ability != null)
					{
						return ability;
					}
				}
			}
			return this.Abilities.GetCounterAttack();
		}
		
		public bool UseCounter(Combatant target)
		{
			if(!this.isDead && ORK.Battle.CanCounter)
			{
				if(ORK.GameSettings.CheckRandom(this.GetCounterChance(target)))
				{
					if(ORK.Battle.IsRealTime())
					{
						this.actions.RTCounter = target;
					}
					else
					{
						return true;
					}
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Ability functions
		============================================================================
		*/
		public void AddAbilityBlock(AbilityBlock block)
		{
			this.abilityReuseBlock.Add(block);
		}
		
		public void RemoveAbilityBlock(AbilityBlock block)
		{
			this.abilityReuseBlock.Remove(block);
		}
		
		public bool IsReuseBlocked(int abilityID)
		{
			for(int i=0; i<this.abilityReuseBlock.Count; i++)
			{
				if(this.abilityReuseBlock[i].abilityID == abilityID)
				{
					return true;
				}
			}
			return false;
		}
		
		public void ClearAbilityBlock()
		{
			this.abilityReuseBlock.Clear();
		}
		
		
		/*
		============================================================================
		Aggression functions
		============================================================================
		*/
		public void SetAttackedBy(Combatant c, bool addFaction)
		{
			if(!this.atkByCombatant.Contains(c))
			{
				this.atkByCombatant.Add(c);
			}
			if(addFaction && !this.atkByFaction.Contains(c.Group.FactionID))
			{
				this.atkByFaction.Add(c.Group.FactionID);
			}
		}
		
		public List<Combatant> GetAttackedBy()
		{
			return this.atkByCombatant;
		}
		
		public void ClearAttackedBy()
		{
			this.atkByCombatant = new List<Combatant>();
			this.atkByFaction = new List<int>();
		}
		
		public void CheckAggressive(AggressionType aggressionType, Combatant origin)
		{
			if(this.setting.aggressionType.Equals(aggressionType))
			{
				this.IsAggressive = true;
				if(origin != null)
				{
					this.SetAttackedBy(origin, true);
				}
			}
		}
		
		
		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		public void ClearBattle(bool start)
		{
			this.ClearAttackedBy();
			this.EndBattleMenu(true);
			this.actions.Clear(start);
			
			this.turnEnded = false;
			this.turnPerformed = true;
			this.phasePerformed = false;
			this.currentTurn = 0;
			this.lastTurnIndex = -1;
			this.TurnValue = 0;
			this.TimeBar = 0;
			this.UsedTimeBar = 0;
			this.DelayTime = 0;
			this.lastTargets = new List<Combatant>();
			this.itemStolen = false;
			this.moneyStolen = false;
			
			this.inBattle = start;
			this.markReset++;
			
			if(this.moveAIComponent != null)
			{
				this.moveAIComponent.ClearTarget(false);
			}
			
			this.FireHUDUpdate();
			this.SetStartEffects();
		}
		
		public void StartBattle()
		{
			this.ClearBattle(true);
		}
		
		public void EndBattle()
		{
			this.battleSpot = null;
			this.status.EndBattle();
			for(int i=0; i<this.abilityReuseBlock.Count; i++)
			{
				if(this.abilityReuseBlock[i].IsRemoveOnBattleEnd())
				{
					this.abilityReuseBlock.RemoveAt(i--);
				}
			}
			this.ClearBattle(false);
			ORK.Battle.EndBonus(this);
			ORK.Battle.ReviveBonus(this);
		}
		
		public bool EnableAutoAttack
		{
			get{ return this.enableAutoAttack;}
			set{ this.enableAutoAttack = value;}
		}
		
		public bool InitNewTurn(bool canPerform)
		{
			this.currentTurn++;
			
			// ability blocks turn
			for(int i=0; i<this.abilityReuseBlock.Count; i++)
			{
				if(this.abilityReuseBlock[i].ReduceTurn())
				{
					this.abilityReuseBlock.RemoveAt(i--);
				}
			}
			
			this.status.CheckEffectsTurn();
			
			if(canPerform)
			{
				this.turnPerformed = true;
				this.actions.IsWaiting = true;
				this.isDefending = false;
			
				// turn bonuses
				ORK.Battle.TurnBonus(this);
				
				if(ORK.MenuSettings.useTurnFlash && ORK.MenuSettings.hudTurnFlash != null)
				{
					this.HUDStartFade(ORK.MenuSettings.hudTurnFlash);
				}
			}
			
			return !this.CheckDeath();
		}
		
		public void EndTurn()
		{
			this.EndBattleMenu(false);
			this.actions.IsChoosing = false;
			if(ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase())
			{
				this.actions.Add(new NoneAction(this), false);
			}
			else if(ORK.Battle.IsActiveTime())
			{
				if(this.actions.Count > 0 || this.actions.Fired)
				{
					this.turnEnded = true;
					if(!this.actions.Fired)
					{
						this.actions.DequeueNextAction();
					}
				}
				else
				{
					/*this.TimeBar = 0;
					this.UsedTimeBar = 0;
					this.actions.IsWaiting = false;*/
					this.turnEnded = true;
					this.actions.Add(new NoneAction(this), false);
				}
			}
		}
		
		public bool TurnEnded
		{
			get{ return this.turnEnded;}
			set{ this.turnEnded = value;}
		}
		
		public void Escape()
		{
			if(this.Group.IsPlayerControlled())
			{
				ORK.Battle.BattleEscaped();
			}
			else
			{
				ORK.Battle.RemoveCombatant(this, false);
			}
		}
		
		public bool CanUse(bool endTurn, float time)
		{
			// turn based, phase > only in battle menu
			if((ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase()) && 
				!this.actions.IsChoosing)
			{
				return false;
			}
			// active time > only if timebar allows it
			else if(ORK.Battle.IsActiveTime() && 
				((!endTurn && this.UsedTimeBar + time > ORK.BattleSystem.activeTime.maxTimebar) ||
					(endTurn && this.UsedTimeBar > 0)))
			{
				return false;
			}
			// real time or in field > always
			return true;
		}
		
		
		/*
		============================================================================
		Battle menu functions
		============================================================================
		*/
		public void ShowBattleMenu()
		{
			if(this.BattleMenu != null)
			{
				this.BattleMenu.IsOpen = true;
				if(!ORK.Battle.MenuActive)
				{
					this.battleMenu.Show();
				}
				ORK.Battle.AddMenuUser(this);
			}
		}
		
		public void EndBattleMenu(bool cancel)
		{
			if(this.battleMenu != null && this.actions.IsChoosing)
			{
				this.battleMenu.Close();
				if(cancel)
				{
					this.actions.IsWaiting = false;
					this.actions.IsChoosing = false;
					ORK.Battle.BattleMenuCanceled(this);
				}
			}
		}
		
		
		/*
		============================================================================
		Time functions
		============================================================================
		*/
		public void Tick(float time, float battleTime)
		{
			if(this.markBoundsCheck > 0)
			{
				this.markBoundsCheck = 0;
				this.status.CheckStatusBounds();
			}
			if(this.markReset > 0)
			{
				this.markReset = 0;
				this.Status.ResetStatus();
			}
			
			// status value ticks (display value update)
			for(int i=0; i<ORK.StatusValues.Count; i++)
			{
				this.Status[i].Tick(Time.deltaTime);
			}
			
			// HUD check
			this.HUDDoFade();
			this.HUDNextEffect();
			if(this.renderer != null)
			{
				if(this.hudLastCheckTime == 0 || 
					(Time.time - this.hudLastCheckTime) > ORK.MenuSettings.hudCheckTime)
				{
					this.CheckHUD();
				}
				for(int i=0; i<this.hud.Count; i++)
				{
					this.hud[i].visible = this.renderer.isVisible && 
						StatusRequirement.Check(this, this.hud[i].Settings.statusRequirement, this.hud[i].Settings.needed);
					this.hud[i].Tick();
					
					if(this.hud[i].ResetIndividual)
					{
						this.hud[i].SetCombatant(this);
					}
				}
			}
			
			// update animations
			this.animations.Tick();
			
			// status updates in field and battle
			if(!ORK.Game.Paused && !this.isDead && 
				(!ORK.Control.Blocked || this.inBattle) && 
				ORK.Battle.DoCombatantTick())
			{
				// status time changes
				if(this.inBattle)
				{
					for(int i=0; i<this.setting.battleStatusChange.Length; i++)
					{
						this.setting.battleStatusChange[i].Tick(battleTime, this);
					}
				}
				else if(!ORK.Control.Blocked)
				{
					for(int i=0; i<this.setting.fieldStatusChange.Length; i++)
					{
						this.setting.fieldStatusChange[i].Tick(time, this);
					}
				}
				
				this.status.CheckEffectsTime(battleTime);
				
				// ability reuse
				for(int i=0; i<this.abilityReuseBlock.Count; i++)
				{
					if(this.abilityReuseBlock[i].ReduceTime(battleTime))
					{
						this.abilityReuseBlock.RemoveAt(i--);
					}
				}
				
				// delay time
				if(this.delayTime > 0)
				{
					this.MarkHUDUpdate();
					this.delayTime -= battleTime;
					if(this.delayTime < 0)
					{
						this.delayTime = 0;
						this.delayTimeMax = 0;
					}
				}
				
				this.actions.Tick(battleTime);
				
				if(!this.actions.InAction && this.baTimeout != -10)
				{
					this.baTimeout -= battleTime;
					if(this.baTimeout <= 0)
					{
						this.ResetBaseAttack();
					}
				}
			}
			
			if(this.battleMenu != null && this.battleMenu.RayAction != null)
			{
				this.battleMenu.Tick(null);
			}
			
			if(this.markHUDUpdate > 0)
			{
				this.FireHUDUpdate();
			}
		}
		
		public bool ControlMapTick()
		{
			if(!this.isDead)
			{
				if(this.controlMaps == null)
				{
					this.controlMaps = new List<ControlMap>();
					for(int i=0; i<this.setting.controlMap.Length; i++)
					{
						this.controlMaps.Add(ORK.ControlMaps.Get(this.setting.controlMap[i]));
					}
					Class cl = ORK.Classes.Get(this.currentClassID);
					for(int i=0; i<cl.controlMap.Length; i++)
					{
						this.controlMaps.Add(ORK.ControlMaps.Get(cl.controlMap[i]));
					}
				}
				for(int i=0; i<this.controlMaps.Count; i++)
				{
					if(this.controlMaps[i].Tick(this))
					{
						return true;
					}
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Status effect functions
		============================================================================
		*/
		public void SetStartEffects()
		{
			if(this.isInitialized)
			{
				this.setting.autoEffects.ChangeEffects(this, this);
				ORK.Classes.Get(this.currentClassID).autoEffects.ChangeEffects(this, this);
				this.status.SetStartEffects();
				this.equipment.SetStartEffects();
				this.abilities.SetStartEffects();
			}
		}
		
		public bool CanApplyEffect(int effectID)
		{
			if(!this.setting.autoEffects.CanApplyEffect(this, effectID) || 
				!ORK.Classes.Get(this.currentClassID).autoEffects.CanApplyEffect(this, effectID) || 
				!this.status.CanApplyEffect(effectID) || 
				!this.equipment.CanApplyEffect(effectID) || 
				!this.abilities.CanApplyEffect(effectID))
			{
				return false;
			}
			return true;
		}
		
		public bool CanRemoveEffect(int effectID)
		{
			if(!this.setting.autoEffects.CanRemoveEffect(this, effectID) || 
				!ORK.Classes.Get(this.currentClassID).autoEffects.CanRemoveEffect(this, effectID) || 
				!this.status.CanRemoveEffect(effectID) || 
				!this.equipment.CanRemoveEffect(effectID) || 
				!this.abilities.CanRemoveEffect(effectID))
			{
				return false;
			}
			return true;
		}
		
		public void UseAttackEffects(Combatant target)
		{
			ORK.Classes.Get(this.currentClassID).autoEffects.UseAttackEffects(this, target);
			this.setting.autoEffects.UseAttackEffects(this, target);
			this.abilities.UseAttackEffects(target);
			this.equipment.UseAttackEffects(target);
			this.status.UseAttackEffects(target);
		}
		
		public void UseDefenceEffects(Combatant target)
		{
			ORK.Classes.Get(this.currentClassID).autoEffects.UseDefenceEffects(this, target);
			this.setting.autoEffects.UseDefenceEffects(this, target);
			this.abilities.UseDefenceEffects(target);
			this.equipment.UseDefenceEffects(target);
			this.status.UseDefenceEffects(target);
		}
		
		
		/*
		============================================================================
		Death functions
		============================================================================
		*/
		public bool CheckDeath()
		{
			if(!this.isDead)
			{
				for(int i=0; i<ORK.StatusValues.Count; i++)
				{
					if(this.status[i].IsDead())
					{
						this.Death();
						return true;
					}
				}
			}
			return false;
		}
		
		public void Death()
		{
			if(!this.isDead)
			{
				this.EndBattleMenu(true);
				this.isDead = true;
				this.lastAbilityID = -1;
				this.TurnValue = 0;
				this.TimeBar = 0;
				this.UsedTimeBar = 0;
				this.DelayTime = 0;
				this.turnEnded = false;
				
				this.actions.Clear(false);
				
				this.status.CheckEffectEndDeath();
				
				for(int i=0; i<this.atkByFaction.Count; i++)
				{
					ORK.Game.Faction.MemberKilled(this.Group.FactionID, this.atkByFaction[i], this.setting.sympathyChange);
				}
				
				ORK.Battle.Actions.Unshift(new DeathAction(this));
			}
		}
		
		public void Died()
		{
			this.isDead = true;
			this.actions.InAction = false;
			this.Animations.StopAll();
			this.setting.DoDeathChanges(this);
			
			// set spawner variables
			if(this.Group.Spawner != null)
			{
				this.Group.Spawner.SetVariables();
			}
			
			if(this.Group.IsPlayerControlled())
			{
				if(this.inBattle)
				{
					if(this.setting.leaveOnDeath)
					{
						ORK.Battle.RemoveCombatant(this, true);
						if(this.group != null)
						{
							this.group.Remove(this, true, true);
						}
					}
					if(ORK.Battle.IsRealTimeArea())
					{
						ORK.Game.CheckGameOver();
					}
					else
					{
						ORK.Battle.CheckBattleEnd();
					}
				}
				else
				{
					if(this.setting.leaveOnDeath)
					{
						if(this.group != null)
						{
							this.group.Remove(this, true, true);
						}
					}
					ORK.Game.CheckGameOver();
				}
			}
			else
			{
				if(this.Group.IsEnemy(ORK.Game.ActiveGroup.Leader) && 
					this.atkByFaction.Contains(ORK.Game.ActiveGroup.FactionID))
				{
					ORK.Battle.EnemyDefeated(this);
				}
				else
				{
					ORK.Battle.RemoveCombatant(this, true);
				}
				
				this.group.CheckSpawner(false);
				
				if(this.setting.leaveOnDeath && this.group != null)
				{
					this.group.Remove(this, true, true);
				}
			}
			this.ClearAttackedBy();
			this.FireChanged();
		}
		
		public void GetLoot(ref List<IShortcut> list, bool autoStack)
		{
			// start inventory loot
			if(this.setting.lootInventory)
			{
				for(int i=0; i<this.setting.money.Length; i++)
				{
					if(this.setting.money[i] > 0)
					{
						ShortcutHelper.Add(ref list, new MoneyShortcut(i, this.setting.money[i]), autoStack);
					}
				}
				for(int i=0; i<this.setting.itemDrop.Length; i++)
				{
					if(this.setting.itemDrop[i].CheckChance())
					{
						ShortcutHelper.Add(ref list, this.setting.itemDrop[i].CreateShortcut(), autoStack);
					}
				}
			}
			// loot tables
			else
			{
				if(this.setting.lootRandom)
				{
					ORK.Loot.Get(this.setting.lootID[Random.Range(0, this.setting.lootID.Length)]).
						Get(ref list, this, autoStack);
				}
				else
				{
					for(int i=0; i<this.setting.lootID.Length; i++)
					{
						ORK.Loot.Get(this.setting.lootID[i]).Get(ref list, this, autoStack);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Battle event functions
		============================================================================
		*/
		public bool GetDefendEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateDefend && this.setting.defendEvent != null)
			{
				for(int i=0; i<this.setting.defendEvent.Length; i++)
				{
					this.setting.defendEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		public bool GetEscapeEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateEscape && this.setting.escapeEvent != null)
			{
				for(int i=0; i<this.setting.escapeEvent.Length; i++)
				{
					this.setting.escapeEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		public bool GetDeathEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateDeath && this.setting.deathEvent != null)
			{
				for(int i=0; i<this.setting.deathEvent.Length; i++)
				{
					this.setting.deathEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		public bool GetNoneEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateNone && this.setting.noneEvent != null)
			{
				for(int i=0; i<this.setting.noneEvent.Length; i++)
				{
					this.setting.noneEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		public bool GetRetreatEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateRetreat && this.setting.retreatEvent != null)
			{
				for(int i=0; i<this.setting.retreatEvent.Length; i++)
				{
					this.setting.retreatEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		public bool GetEnterBattleEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateEnterBattle && this.setting.enterBattleEvent != null)
			{
				for(int i=0; i<this.setting.enterBattleEvent.Length; i++)
				{
					this.setting.enterBattleEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		public bool GetJoinBattleEvent(ref List<BattleEvent> list)
		{
			if(this.setting.animateJoinBattle && this.setting.joinBattleEvent != null)
			{
				for(int i=0; i<this.setting.joinBattleEvent.Length; i++)
				{
					this.setting.joinBattleEvent[i].GetEvent(ref list, this);
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Look at functions
		============================================================================
		*/
		public void LookAt(Combatant c)
		{
			if(c != null && c.prefabInstance != null)
			{
				this.LookAt(new Vector3(
						c.prefabInstance.transform.position.x,
						this.prefabInstance.transform.position.y,
						c.prefabInstance.transform.position.z));
			}
		}
		
		public void LookAt(Vector3 v)
		{
			if(this.prefabInstance != null)
			{
				this.prefabInstance.transform.LookAt(v);
			}
		}
		
		
		/*
		============================================================================
		HUD functions
		============================================================================
		*/
		public void ClearHUD()
		{
			for(int i=0; i<this.hud.Count; i++)
			{
				this.hud[i].CloseHUD();
			}
			this.hud.Clear();
		}
		
		public void OpenHUD()
		{
			this.hud = ORK.HUDs.Create(true, this.hudLastFaction);
			for(int i=0; i<this.hud.Count; i++)
			{
				this.hud[i].SetCombatant(this);
			}
		}
		
		public void CheckHUD()
		{
			this.hudLastCheckTime = Time.time;
			bool tmp = this.IsEnemy(ORK.Game.ActiveGroup.Leader);
			if(this.hudLastFaction != this.Group.FactionID ||
				this.hudPlayerEnemy != tmp)
			{
				this.hudLastFaction = this.Group.FactionID;
				this.hudPlayerEnemy = tmp;
				
				this.ClearHUD();
				this.OpenHUD();
				
				this.FireHUDUpdate();
			}
		}
		
		public void HUDNextEffect()
		{
			if(this.status.Effects.Count > 1)
			{
				this.hudEffectTime -= Time.deltaTime;
				
				if(this.hudEffectTime <= 0)
				{
					this.hudEffectIndex++;
					if(this.hudEffectIndex >= this.status.GetHUDEffects().Count)
					{
						this.hudEffectIndex = 0;
					}
					this.hudEffectTime = ORK.MenuSettings.hudSETime;
					
					this.FireHUDUpdate();
				}
			}
		}
		
		public int HUDEffectIndex
		{
			get{ return this.hudEffectIndex;}
			set
			{
				this.hudEffectIndex = value;
				if(this.hudEffectIndex >= this.status.GetHUDEffects().Count)
				{
					this.hudEffectIndex = 0;
				}
			}
		}
		
		
		/*
		============================================================================
		HUD color functions
		============================================================================
		*/
		public Color HUDColor
		{
			get{ return this.hudCol;}
		}
		
		public bool IsHUDFade()
		{
			return this.hudColState > 0 && this.fade != null;
		}
		
		public void HUDStartFade(FadeColorSettings f)
		{
			this.fade = f;
			this.hudCol = new Color(1, 1, 1, 1);
			this.hudColStart = this.hudCol;
			if(this.fade != null)
			{
				this.fade.GetStart(ref this.hudColStart);
				this.hudCol = this.hudColStart;
				this.hudColTime = 0;
				this.hudColTime2 = fade.time / 2;
				this.hudColState = 1;
			}
		}
		
		private void HUDDoFade()
		{
			if(this.hudColState == 1)
			{
				this.hudColTime += Time.deltaTime;
				if(this.fade.Fade(ref this.hudCol, this.hudColStart, this.hudColTime, this.hudColTime2))
				{
					this.hudColState = 2;
					this.hudColTime = 0;
				}
			}
			else if(this.hudColState == 2)
			{
				this.hudColTime += Time.deltaTime;
				if(this.fade.RevertFade(ref this.hudCol, this.hudColStart, this.hudColTime, this.hudColTime2))
				{
					this.hudColState = 0;
					this.fade = null;
				}
			}
		}
		
		
		/*
		============================================================================
		Battle info functions
		============================================================================
		*/
		public GUIBox BattleInfo
		{
			get
			{
				if(this.battleInfo.Count > 0)
				{
					return this.battleInfo[0];
				}
				return null;
			}
			set
			{
				ORK.GUI.AddNotification(ref this.battleInfo, value, 
					ORK.BattleTexts.queueInfos);
			}
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			data.Set("realID", this.realID);
			data.Set("currentClassID", this.currentClassID);
			data.Set("currentLevel", this.currentLevel);
			data.Set("isDead", this.isDead);
			data.Set("autoMoveAnimation", this.animations.autoMoveAnimation);
			data.Set("isTemporary", this.isTemporary);
			
			DataObject clvl = new DataObject();
			foreach(KeyValuePair<int, int> pair in this.currentClassLevel)
			{
				clvl.Set(pair.Key.ToString(), pair.Value);
			}
			data.Set("clvl", clvl);
			
			DataObject clvlexp = new DataObject();
			foreach(KeyValuePair<int, int> pair in this.classLevelExp)
			{
				clvlexp.Set(pair.Key.ToString(), pair.Value);
			}
			data.Set("clvlexp", clvlexp);
			
			data.Set("status", this.status.SaveGame());
			data.Set("abilities", this.abilities.SaveGame());
			data.Set("equipment", this.equipment.SaveGame());
			
			// shortcuts
			DataObject[] tmp = new DataObject[this.shortcutList.Length];
			for(int i=0; i<this.shortcutList.Length; i++)
			{
				tmp[i] = this.shortcutList[i].SaveGame();
			}
			data.Set("shortcutList", tmp);
			
			DataObject cshortcutList = new DataObject();
			foreach(KeyValuePair<int, CombatantShortcuts[]> pair in this.classShortcutList)
			{
				tmp = new DataObject[pair.Value.Length];
				for(int i=0; i<pair.Value.Length; i++)
				{
					tmp[i] = pair.Value[i].SaveGame();
				}
				
				cshortcutList.Set(pair.Key.ToString(), tmp);
			}
			data.Set("cshortcutList", cshortcutList);
			
			// name
			if(this.newName != "")
			{
				data.Set("newName", this.newName);
			}
			if(this.nameCount != "")
			{
				data.Set("nameCount", this.nameCount);
			}
			
			// inventory
			if(this.inventory != null)
			{
				data.Set("inventory", this.inventory.SaveGame());
			}
			
			// position
			if(this.prefabInstance != null)
			{
				data.Set("pos", ArrayHelper.ToArray(this.prefabInstance.transform.position));
				data.Set("rot", ArrayHelper.ToArray(this.prefabInstance.transform.eulerAngles));
			}
			else if(this.rememberPosition)
			{
				data.Set("pos", ArrayHelper.ToArray(this.storedPosition));
				data.Set("rot", ArrayHelper.ToArray(this.storedRotation));
			}
			
			// variables
			if(this.variableHandler != null)
			{
				data.Set("variables", this.variableHandler.SaveGame());
			}
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.currentClassLevel = new Dictionary<int, int>();
			this.classLevelExp = new Dictionary<int, int>();
			this.classShortcutList = new Dictionary<int, CombatantShortcuts[]>();
			
			if(data != null)
			{
				DataObject inv = data.GetFile("inventory");
				if(inv != null)
				{
					this.inventory = new Inventory(this);
					this.inventory.LoadGame(inv);
				}
				
				data.Get("currentClassID", ref this.currentClassID);
				data.Get("currentLevel", ref this.currentLevel);
				data.Get("isDead", ref this.isDead);
				data.Get("autoMoveAnimation", ref this.animations.autoMoveAnimation);
				data.Get("isTemporary", ref this.isTemporary);
				
				DataObject clvl = data.GetFile("clvl");
				if(clvl != null)
				{
					Dictionary<string, int> list = clvl.GetData<int>(typeof(int));
					foreach(KeyValuePair<string, int> pair in list)
					{
						this.currentClassLevel.Add(int.Parse(pair.Key), pair.Value);
					}
				}
				
				DataObject clvlexp = data.GetFile("clvlexp");
				if(clvlexp != null)
				{
					Dictionary<string, int> list = clvlexp.GetData<int>(typeof(int));
					foreach(KeyValuePair<string, int> pair in list)
					{
						this.classLevelExp.Add(int.Parse(pair.Key), pair.Value);
					}
				}
				
				this.Init(this.currentLevel, this.ClassLevel, this.currentClassID);
				
				this.status.LoadGame(data.GetFile("status"));
				this.equipment.LoadGame(data.GetFile("equipment"));
				this.abilities.LoadGame(data.GetFile("abilities"));
				
				// shortcuts
				if(data.Contains<DataObject>("shortcuts"))
				{
					this.shortcutList[0].LoadGame(data.GetFile("shortcuts"));
				}
				else
				{
					DataObject[] sl = data.GetFileArray("shortcutList");
					if(sl != null)
					{
						for(int i=0; i<sl.Length; i++)
						{
							if(i < this.shortcutList.Length)
							{
								this.shortcutList[i].LoadGame(sl[i]);
							}
						}
					}
					
					DataObject cshortcutList = data.GetFile("cshortcutList");
					if(cshortcutList != null)
					{
						Dictionary<string, DataObject[]> list = cshortcutList.GetArrayData<DataObject>(typeof(DataObject));
						foreach(KeyValuePair<string, DataObject[]> pair in list)
						{
							CombatantShortcuts[] tmpList = new CombatantShortcuts[pair.Value.Length];
							for(int i=0; i<tmpList.Length; i++)
							{
								tmpList[i] = new CombatantShortcuts(this);
								tmpList[i].LoadGame(pair.Value[i]);
							}
							this.classShortcutList.Add(int.Parse(pair.Key), tmpList);
						}
					}
				}
				
				DataObject tmp = data.GetFile("variables");
				if(tmp != null)
				{
					this.variableHandler = new VariableHandler(false);
					this.variableHandler.LoadGame(tmp);
				}
				
				data.Get("newName", ref this.newName);
				data.Get("nameCount", ref this.nameCount);
				
				this.abilities.ResetEquipmentAbilities();
				this.status.ResetStatus();
			}
		}
		
		public void LoadPosition(DataObject data)
		{
			if(data != null && 
				data.ContainsArray<float>("pos") && !this.Dead)
			{
				float[] tmp2 = null;
				data.Get("pos", out tmp2);
				if(tmp2 != null)
				{
					float yRotation = 0;
					float[] tmp3 = null;
					data.Get("rot", out tmp3);
					if(tmp2 != null)
					{
						yRotation = ArrayHelper.GetVector3(tmp3).y;
					}
					this.Spawn(ArrayHelper.GetVector3(tmp2), true, yRotation, false, Vector3.one);
				}
			}
		}
	}
}
