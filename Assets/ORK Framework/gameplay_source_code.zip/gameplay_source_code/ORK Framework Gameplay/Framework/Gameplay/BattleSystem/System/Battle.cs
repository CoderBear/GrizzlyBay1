
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using ORKFramework.Behaviours;
using ORKFramework.Events;

namespace ORKFramework
{
	public delegate void EnemyKilled(Combatant enemy);
	
	public class Battle
	{
		private static Battle instance;
		
		protected BattleSystemType type = BattleSystemType.TurnBased;
		
		
		// battle
		private BaseBattle currentSystem;
		
		private bool inBattle = false;
		
		private bool battleEnd = false;
		
		private bool canEscape = true;
		
		
		// battle advantages
		private GroupAdvantageType battleAdvantage = GroupAdvantageType.None;
		
		
		// actions
		private BattleActionHandler actionHandler = new BattleActionHandler();
		
		
		// gains
		private List<IShortcut> loot = new List<IShortcut>();
		
		private Dictionary<int, List<ExperienceLoot>> expGains = new Dictionary<int, List<ExperienceLoot>>();
		
		
		// battle arena
		private BattleComponent battleArena;
		
		private GameObject groupCenter;
		
		private GameObject combatantCenter;
		
		
		// real time areas
		private int realTimeAreaCount = 0;
		
		
		// battle menu
		private List<Combatant> menuUser = new List<Combatant>();
		
		private int menuIndex = 0;
		
		
		// outcome
		private BattleOutcome waitForLastActionOutcome = BattleOutcome.None;
		
		
		// enemy counting
		private Dictionary<int, int> enemyCounter = new Dictionary<int, int>();
		
		private Dictionary<int, int> enemyCounter2 = new Dictionary<int, int>();
		
		
		// events
		public EnemyKilled EnemyKilled;
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private Battle()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of Battle!");
			}
			else
			{
				instance = this;
			}
		}
		
		public static Battle Instance()
		{
			if(instance == null)
			{
				new Battle();
			}
			return instance;
		}
		
		
		/*
		============================================================================
		Clearing functions
		============================================================================
		*/
		public void ClearBattle()
		{
			ORK.Control.ClearInBattle();
			this.EndBattle();
			this.Actions.StopActiveActions();
			ORK.Game.Combatants.EndBattle();
			this.currentSystem = null;
			this.battleEnd = false;
			this.waitForLastActionOutcome = BattleOutcome.None;
		}
		
		
		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public BattleActionHandler Actions
		{
			get{ return this.actionHandler;}
		}
		
		public BaseBattle System
		{
			get{ return this.currentSystem;}
		}
		
		public bool InBattle
		{
			get{ return this.inBattle;}
		}
		
		public bool BattleEnd
		{
			get{ return this.battleEnd;}
		}
		
		public bool WaitForLastAction
		{
			get{ return !BattleOutcome.None.Equals(this.waitForLastActionOutcome);}
		}
		
		public bool CanEscape
		{
			get{ return this.canEscape;}
		}
		
		public bool CanCounter
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.CanCounter;
				}
				else
				{
					return ORK.BattleSystem.fieldMode.canCounter;
				}
			}
		}
		
		public bool DeathImmediately
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.DeathImmediately;
				}
				else
				{
					return true;
				}
			}
		}
		
		public bool MenuBlockAutoAttack
		{
			get
			{
				return this.currentSystem != null && 
					this.currentSystem.MenuBlockAutoAttack;
			}
		}
		
		public bool CanAutoAttack
		{
			get
			{
				return this.currentSystem != null && 
					this.inBattle && !this.battleEnd && 
					this.currentSystem.CanAutoAttack;
			}
		}
		
		public bool DefendFirst
		{
			get
			{
				return this.currentSystem != null && 
					this.currentSystem.DefendFirst;
			}
		}
		
		public float GainsCloseTime
		{
			get
			{
				if(this.currentSystem != null && 
					this.currentSystem.gainsAutoClose)
				{
					return this.currentSystem.gainsAutoCloseTime;
				}
				return -1;
			}
		}
		
		public bool GainsBlockAccept
		{
			get
			{
				if(this.currentSystem != null && 
					this.currentSystem.gainsAutoClose)
				{
					return this.currentSystem.gainsAutoCloseBlockAccept;
				}
				return false;
			}
		}
		
		public BattleComponent BattleArena
		{
			get{ return this.battleArena;}
		}
		
		public int RealTimeAreaCount
		{
			get{ return this.realTimeAreaCount;}
			set
			{
				this.realTimeAreaCount = value;
				if(this.realTimeAreaCount < 0)
				{
					this.realTimeAreaCount = 0;
				}
				
				// end battle
				if(this.IsBattleRunning() && 
					this.realTimeAreaCount == 0)
				{
					this.EndBattle();
					
					if(this.HasGains())
					{
						this.CollectGains(true, 
							ORK.Battle.GainsCloseTime, ORK.Battle.GainsBlockAccept, 
							null, -1);
					}
					this.ClearGains();
					this.ClearObjectsAndAnimations();
					ORK.Game.Combatants.EndBattle();
					
					ORK.Control.SetInBattle(-1);
					this.DoBattleBlock(-1);
					this.DoMoveAIBlock(-1);
					this.ClearBattle();
				}
				// start battle
				else if(!this.IsBattleRunning() && 
					this.realTimeAreaCount > 0)
				{
					ORK.Control.SetInBattle(1);
					this.SetType(BattleSystemType.RealTime);
					this.DoBattleBlock(1);
					
					// TODO: spawn whole groups
					
					// join all spawned combatants
					List<Combatant> combatants = ORK.Game.Combatants.GetAll();
					for(int i=0; i<combatants.Count; i++)
					{
						if(combatants[i].Group == ORK.Game.ActiveGroup || 
							BattleSystemType.RealTime.Equals(combatants[i].Group.BattleType))
						{
							this.Join(combatants[i]);
						}
					}
					
					this.StartBattle(false);
				}
			}
		}
		
		public GroupAdvantageType Advantage
		{
			get{ return this.battleAdvantage;}
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsTurnBased()
		{
			return this.currentSystem != null && 
				BattleSystemType.TurnBased.Equals(this.type);
		}
		
		public bool IsActiveTime()
		{
			return this.currentSystem != null && 
				BattleSystemType.ActiveTime.Equals(this.type);
		}
		
		public bool IsRealTime()
		{
			return this.currentSystem != null && 
				BattleSystemType.RealTime.Equals(this.type);
		}
		
		public bool IsRealTimeArea()
		{
			return this.currentSystem != null && 
				BattleSystemType.RealTime.Equals(this.type) && 
				this.realTimeAreaCount > 0;
		}
		
		public bool IsPhase()
		{
			return this.currentSystem != null && 
				BattleSystemType.Phase.Equals(this.type);
		}
		
		public bool IsType(BattleSystemType type)
		{
			return this.currentSystem != null && 
				type.Equals(this.type);
		}
		
		public bool IsBattleRunning()
		{
			return this.currentSystem != null && this.inBattle && !this.battleEnd;
		}
		
		public bool IsDynamicCombat()
		{
			return this.currentSystem != null && 
				this.currentSystem.IsDynamicCombat();
		}
		
		
		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public void Join(List<Combatant> list)
		{
			for(int i=0; i<list.Count; i++)
			{
				this.Join(list[i]);
			}
		}
		
		public void Join(Combatant combatant)
		{
			bool fireAction = false;
			ORK.Game.Combatants.Add(combatant);
			ORK.Game.Bestiary.Encounter(combatant);
			
			// create/set spots
			if(this.battleArena != null)
			{
				// player spots
				if(combatant.Group == ORK.Game.ActiveGroup)
				{
					this.battleArena.SetNextPlayerSpot(combatant, this.battleAdvantage);
				}
				// enemy spots
				else if(combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader))
				{
					this.battleArena.SetNextEnemySpot(combatant, this.battleAdvantage);
				}
				// ally spots
				else
				{
					this.battleArena.SetNextAllySpot(combatant, this.battleAdvantage);
				}
			}
			
			// spawn and counting
			if(this.IsBattleRunning())
			{
				// enemy counting
				if(combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader) && 
					!EnemyCounting.None.Equals(ORK.BattleSettings.enemyCounter))
				{
					if(this.enemyCounter.ContainsKey(combatant.RealID))
					{
						this.enemyCounter[combatant.RealID]++;
					}
					else
					{
						this.enemyCounter.Add(combatant.RealID, 1);
						this.enemyCounter2.Add(combatant.RealID, 0);
					}
					
					if(this.enemyCounter[combatant.RealID] > 1)
					{
						combatant.NameCount = TextHelper.GetEnemyCounting(this.enemyCounter2[combatant.RealID]++);
					}
				}
				
				if(combatant.BattleSpot != null)
				{
					if(combatant.GameObject == null)
					{
						combatant.Spawn(combatant.BattleSpot.transform.position, 
							true, combatant.BattleSpot.transform.eulerAngles.y, 
							ORK.BattleSpots.useScale, combatant.BattleSpot.transform.localScale);
					}
					else if(combatant.Setting.animateJoinBattle)
					{
						fireAction = true;
					}
					else
					{
						combatant.PlaceAt(combatant.BattleSpot.transform.position, 
							true, combatant.BattleSpot.transform.eulerAngles.y, 
							ORK.BattleSpots.useScale, combatant.BattleSpot.transform.localScale);
					}
				}
				
				// look at enemies
				if(!fireAction && combatant.Setting.joinLookAt)
				{
					this.DoLookAt(combatant, ORK.Game.Combatants.Get(combatant, true, 
						Range.Infinity, Consider.Yes, Consider.No, Consider.Yes));
				}
			}
			
			// start battle for combatant
			combatant.StartBattle();
			if(this.IsActiveTime())
			{
				combatant.TimeBar = ORK.Formulas.Get(ORK.BattleSystem.activeTime.startFormulaID).
					Calculate(ORK.BattleSystem.activeTime.initialValueStart, combatant, combatant);
				if(combatant.TimeBar > ORK.BattleSystem.activeTime.maxTimebar)
				{
					combatant.TimeBar = ORK.BattleSystem.activeTime.maxTimebar;
				}
			}
			
			// fire join action
			if(fireAction)
			{
				this.Actions.Unshift(new JoinBattleAction(combatant));
			}
		}
		
		public void RemoveCombatant(Combatant combatant, bool died)
		{
			combatant.EndBattle();
			
			if(!died || !combatant.Setting.deathKeepPrefab)
			{
				combatant.DestroyPrefab();
			}
			
			// free battle spot
			if(this.battleArena != null)
			{
				this.battleArena.SetSpot(combatant, null);
			}
			
			this.CheckBattleEnd();
		}
		
		public void EnemyDefeated(Combatant enemy)
		{
			// exp+items
			if(enemy != null)
			{
				ORK.Statistic.EnemyKilled(enemy.RealID);
				
				// update bestiary
				if(ORK.GameSettings.bestiary.useBestiary)
				{
					List<Combatant> attackedBy = enemy.GetAttackedBy();
					for(int i=0; i<attackedBy.Count; i++)
					{
						if(attackedBy[i] != null && 
							attackedBy[i].IsPlayerControlled())
						{
							ORK.Game.Bestiary.Killed(enemy);
							break;
						}
					}
				}
				
				// battle gains
				if(this.currentSystem != null)
				{
					// items
					if(enemy.GameObject != null && 
						this.currentSystem.gainsCollectImmediately && 
						this.currentSystem.gainsDropItems)
					{
						List<IShortcut> drops = new List<IShortcut>();
						enemy.GetLoot(ref drops, this.currentSystem.gainsStack);
						for(int i=0; i<drops.Count; i++)
						{
							ORK.Game.Scene.Drop(enemy.GameObject.transform.position, drops[i]);
						}
					}
					else
					{
						enemy.GetLoot(ref this.loot, this.currentSystem.gainsStack);
					}
					
					// money
					if(enemy.GameObject != null && 
						this.currentSystem.gainsCollectImmediately && 
						this.currentSystem.gainsDropMoney)
					{
						for(int i=0; i<enemy.Setting.money.Length; i++)
						{
							if(enemy.Setting.money[i] > 0)
							{
								ORK.Game.Scene.Drop(enemy.GameObject.transform.position, 
									new MoneyShortcut(i, enemy.Setting.money[i]));
							}
						}
					}
					else
					{
						for(int i=0; i<enemy.Setting.money.Length; i++)
						{
							if(enemy.Setting.money[i] > 0)
							{
								ShortcutHelper.Add(ref this.loot, 
									new MoneyShortcut(i, enemy.Setting.money[i]), 
									this.currentSystem.gainsStack);
							}
						}
					}
				}
				
				// group gains
				if(enemy.Group.AllDeadBattle())
				{
					for(int i=0; i<enemy.Group.Loot.Count; i++)
					{
						ShortcutHelper.Add(ref this.loot, enemy.Group.Loot[i], 
							this.currentSystem.gainsStack);
					}
				}
				
				// experience
				if(enemy.Setting.useExpReward)
				{
					if(enemy.Setting.expReward != null)
					{
						for(int i=0; i<enemy.Setting.expReward.Length; i++)
						{
							DifficultyFaction factionMultipliers = ORK.Difficulties.Get(ORK.Game.Difficulty).
								GetMultipliers(enemy.Group.FactionID);
							int exp = (int)(enemy.Setting.expReward[i].rewardValue.GetValue(enemy, enemy) * 
								(factionMultipliers != null ? 
									factionMultipliers.statusMultiplier[enemy.Setting.expReward[i].statusID] : 1));
							if(exp != 0)
							{
								if(ORK.BattleEnd.splitExp)
								{
									if(ORK.BattleEnd.wholePartyExp)
									{
										exp /= ORK.Game.ActiveGroup.Size;
									}
									else
									{
										exp /= ORK.Game.ActiveGroup.BattleSize;
									}
								}
								
								this.AddExperienceReward(enemy.Setting.expReward[i].statusID, 
									exp, enemy.Level, enemy.ClassLevel);
							}
						}
					}
				}
				else
				{
					for(int i=0; i<ORK.StatusValues.Count; i++)
					{
						if(enemy.Status[i].IsExperience())
						{
							int exp = enemy.Status[i].GetBaseValue();
							if(exp != 0)
							{
								if(ORK.BattleEnd.splitExp)
								{
									if(ORK.BattleEnd.wholePartyExp)
									{
										exp /= ORK.Game.ActiveGroup.Size;
									}
									else
									{
										exp /= ORK.Game.ActiveGroup.BattleSize;
									}
								}
								
								this.AddExperienceReward(i, exp, enemy.Level, enemy.ClassLevel);
							}
						}
					}
				}
				
				// remove enemy
				if(this.currentSystem != null && 
					this.currentSystem.gainsCollectImmediately)
				{
					this.CollectGains(this.currentSystem.gainsShowText, 
						ORK.Battle.GainsCloseTime, ORK.Battle.GainsBlockAccept, 
						null, -1);
				}
				this.RemoveCombatant(enemy, true);
				
				// fire killed enemy callback
				if(this.EnemyKilled != null)
				{
					this.EnemyKilled(enemy);
				}
			}
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void Tick()
		{
			if(!ORK.Game.Paused)
			{
				this.Actions.Tick();
				
				if(this.inBattle && this.currentSystem != null)
				{
					// camera
					ORK.BattleSettings.camera.Tick();
					
					// battle system type
					this.currentSystem.Tick();
					
					if(!BattleOutcome.None.Equals(this.waitForLastActionOutcome) && 
						this.Actions.CanEndBattle())
					{
						this.battleEnd = true;
						if(BattleOutcome.Victory.Equals(this.waitForLastActionOutcome))
						{
							this.BattleVictory();
						}
						else if(BattleOutcome.Defeat.Equals(this.waitForLastActionOutcome))
						{
							this.BattleLost();
						}
						else if(BattleOutcome.LeaveArena.Equals(this.waitForLastActionOutcome))
						{
							this.BattleLeftArena();
						}
					}
					else if(this.battleArena != null)
					{
						// leave arena
						if(this.currentSystem.useLeaveArena && 
							this.currentSystem.leaveArenaRange.OutOfRange(
								this.battleArena.transform.position, ORK.Game.ActiveGroup.Leader))
						{
							if(this.currentSystem.EndImmediately)
							{
								this.BattleLeftArena();
							}
							else
							{
								this.waitForLastActionOutcome = BattleOutcome.LeaveArena;
							}
						}
						// auto join
						else if(this.battleArena.useDefaultAutoJoin && 
							ORK.BattleSettings.autoJoin.runningBattle)
						{
							this.Join(ORK.BattleSettings.autoJoin.GetCombatants(this.battleArena.transform.position));
						}
						else if(this.battleArena.autoJoin != null && 
							this.battleArena.autoJoin.runningBattle)
						{
							this.Join(this.battleArena.autoJoin.GetCombatants(this.battleArena.transform.position));
						}
					}
				}
			}
		}
		
		public bool DoCombatantTick()
		{
			if(this.currentSystem != null)
			{
				return this.currentSystem.DoCombatantTick();
			}
			return true;
		}
		
		public void RemoveFromOrder(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.RemoveFromOrder(combatant);
			}
		}
		
		public void OrderChange(Combatant combatant, int change)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.OrderChange(combatant, change);
			}
		}
		
		public void CombatantChanged(Combatant oldCombatant, Combatant newCombatant)
		{
			ORK.Battle.Actions.RemoveFromUser(oldCombatant);
			ORK.Battle.Actions.RemoveTarget(oldCombatant);
			if(this.currentSystem != null)
			{
				this.currentSystem.CombatantChanged(oldCombatant, newCombatant);
			}
			// add player controls if old combatant is player
			Combatant realPlayer = ORK.Game.ActiveGroup.MemberAt(0);
			if(oldCombatant == realPlayer || newCombatant == realPlayer)
			{
				ORK.GameControls.AddPlayerComponents(newCombatant);
			}
		}
		
		
		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public void SetType(BattleSystemType type)
		{
			if(BattleSystemType.TurnBased.Equals(type))
			{
				this.currentSystem = ORK.BattleSystem.turnBased;
			}
			else if(BattleSystemType.ActiveTime.Equals(type))
			{
				this.currentSystem = ORK.BattleSystem.activeTime;
			}
			else if(BattleSystemType.RealTime.Equals(type))
			{
				this.currentSystem = ORK.BattleSystem.realTime;
			}
			else if(BattleSystemType.Phase.Equals(type))
			{
				this.currentSystem = ORK.BattleSystem.phase;
			}
			this.type = type;
			ORK.Battle.DoMoveAIBlock(1);
		}
		
		public void SetBattleArena(BattleComponent arena)
		{
			this.battleArena = arena;
			this.battleAdvantage = GroupAdvantageType.None;
			
			float rnd = ORK.GameSettings.GetRandom();
			
			float paChance = ORK.BattleSettings.playerAdvantage.chance;
			if(this.battleArena.overridePAChance)
			{
				paChance = this.battleArena.paChance;
			}
			
			float eaChance = ORK.BattleSettings.enemyAdvantage.chance;
			if(this.battleArena.overrideEAChance)
			{
				eaChance = this.battleArena.eaChance;
			}
			
			if(ORK.BattleSettings.playerAdvantage.enabled && 
				this.battleArena.enablePA && 
				paChance > 0 && rnd <= paChance)
			{
				this.battleAdvantage = GroupAdvantageType.Player;
			}
			else if(ORK.BattleSettings.enemyAdvantage.enabled && 
				this.battleArena.enableEA && 
				eaChance > 0 && rnd >= ORK.GameSettings.maxRandomRange - eaChance)
			{
				this.battleAdvantage = GroupAdvantageType.Enemy;
			}
		}
		
		public void StartBattle(bool canEscape)
		{
			this.canEscape = canEscape;
			this.ClearGains();
			this.waitForLastActionOutcome = BattleOutcome.None;
			
			if(this.battleArena != null)
			{
				// additional item gains
				for(int i=0; i<this.battleArena.itemGains.Length; i++)
				{
					if(this.battleArena.itemGains[i].CheckChance())
					{
						ShortcutHelper.Add(ref this.loot, this.battleArena.itemGains[i].CreateShortcut(), true);
					}
				}
				ORK.BattleSettings.camera.StartBattle(this.battleArena);
			}
			
			if(this.IsRealTime())
			{
				this.battleAdvantage = GroupAdvantageType.None;
			}
			
			if((GroupAdvantageType.Player.Equals(this.battleAdvantage) && ORK.BattleSettings.playerAdvantage.blockEscape) ||
				(GroupAdvantageType.Enemy.Equals(this.battleAdvantage) && ORK.BattleSettings.enemyAdvantage.blockEscape))
			{
				this.canEscape = false;
			}
			
			List<Combatant> allies = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
				true, Range.Infinity, Consider.No, Consider.No, Consider.Yes);
			List<Combatant> enemies = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
				true, Range.Infinity, Consider.Yes, Consider.No, Consider.Yes);
			
			// player/allies set up
			for(int i=0; i<allies.Count; i++)
			{
				if(GroupAdvantageType.Player.Equals(this.battleAdvantage))
				{
					ORK.BattleSettings.playerAdvantage.playerGroupCondition.Apply(allies[i]);
				}
				else if(GroupAdvantageType.Enemy.Equals(this.battleAdvantage))
				{
					ORK.BattleSettings.enemyAdvantage.playerGroupCondition.Apply(allies[i]);
				}
				else
				{
					if(this.IsActiveTime())
					{
						allies[i].TimeBar = ORK.Formulas.Get(ORK.BattleSystem.activeTime.startFormulaID).
							Calculate(ORK.BattleSystem.activeTime.initialValueStart, allies[i], allies[i]);
						if(allies[i].TimeBar > ORK.BattleSystem.activeTime.maxTimebar)
						{
							allies[i].TimeBar = ORK.BattleSystem.activeTime.maxTimebar;
						}
					}
					this.StartBonus(allies[i]);
				}
			}
			
			// prepare enemy name counting
			this.enemyCounter.Clear();
			this.enemyCounter2.Clear();
			
			if(!EnemyCounting.None.Equals(ORK.BattleSettings.enemyCounter))
			{
				for(int i=0; i<enemies.Count; i++)
				{
					if(this.enemyCounter.ContainsKey(enemies[i].RealID))
					{
						this.enemyCounter[enemies[i].RealID]++;
					}
					else
					{
						this.enemyCounter.Add(enemies[i].RealID, 1);
						this.enemyCounter2.Add(enemies[i].RealID, 0);
					}
				}
			}
			
			// enemies set up
			for(int i=0; i<enemies.Count; i++)
			{
				if(!EnemyCounting.None.Equals(ORK.BattleSettings.enemyCounter) && 
					this.enemyCounter[enemies[i].RealID] > 1)
				{
					enemies[i].NameCount = TextHelper.GetEnemyCounting(this.enemyCounter2[enemies[i].RealID]++);
				}
				
				if(GroupAdvantageType.Player.Equals(this.battleAdvantage))
				{
					ORK.BattleSettings.playerAdvantage.enemyGroupCondition.Apply(enemies[i]);
				}
				else if(GroupAdvantageType.Enemy.Equals(this.battleAdvantage))
				{
					ORK.BattleSettings.enemyAdvantage.enemyGroupCondition.Apply(enemies[i]);
				}
				else
				{
					if(this.IsActiveTime())
					{
						enemies[i].TimeBar = ORK.Formulas.Get(ORK.BattleSystem.activeTime.startFormulaID).
							Calculate(ORK.BattleSystem.activeTime.initialValueStart, enemies[i], enemies[i]);
						if(enemies[i].TimeBar > ORK.BattleSystem.activeTime.maxTimebar)
						{
							enemies[i].TimeBar = ORK.BattleSystem.activeTime.maxTimebar;
						}
					}
					this.StartBonus(enemies[i]);
				}
			}
			
			this.ClearMenuUsers();
			this.Actions.Clear();
			
			this.battleEnd = false;
			this.inBattle = true;
			
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleStarted();
			}
			
			this.currentSystem.StartBattle(false);
		}
		
		public void ChangeType(BattleSystemType type, bool clearActions, bool stopActions)
		{
			if(this.inBattle && !this.battleEnd && 
				this.currentSystem != null && !this.IsType(type))
			{
				if(clearActions)
				{
					this.Actions.ClearStack();
				}
				if(stopActions)
				{
					this.Actions.StopActiveActions();
				}
				
				this.currentSystem.EndBattle();
				this.DoMoveAIBlock(-1);
				this.SetType(type);
				this.currentSystem.StartBattle(true);
			}
		}
		
		
		/*
		============================================================================
		Bonus functions
		============================================================================
		*/
		public void StartBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.StartBonus(combatant);
			}
		}
		
		public void TurnBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.TurnBonus(combatant);
			}
		}
		
		public void EndBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.EndBonus(combatant);
			}
		}
		
		public void ReviveBonus(Combatant combatant)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.bonuses.ReviveBonus(combatant);
			}
		}
		
		
		/*
		============================================================================
		End functions
		============================================================================
		*/
		public void CheckBattleEnd()
		{
			if(this.IsBattleRunning() && 
				BattleOutcome.None.Equals(this.waitForLastActionOutcome) && 
				(!this.IsRealTime() || this.realTimeAreaCount == 0))
			{
				this.waitForLastActionOutcome = BattleOutcome.None;
				ORK.Game.Combatants.CheckDeath();
				
				// all enemies gone
				if(this.IsAllEnemiesDefeated())
				{
					if(this.currentSystem.EndImmediately)
					{
						this.BattleVictory();
					}
					else
					{
						this.waitForLastActionOutcome = BattleOutcome.Victory;
					}
				}
				// check player group
				else
				{
					bool alive = false;
					if(this.currentSystem.DefeatOnPlayerDeath)
					{
						if(!ORK.Game.ActiveGroup.Leader.Dead)
						{
							alive = true;
						}
					}
					else
					{
						List<Combatant> group = ORK.Game.ActiveGroup.GetBattle();
						for(int i=0; i<group.Count; i++)
						{
							if(!group[i].Dead)
							{
								alive = true;
								break;
							}
						}
					}
					if(!alive)
					{
						if(this.currentSystem.EndImmediately)
						{
							this.BattleLost();
						}
						else
						{
							this.waitForLastActionOutcome = BattleOutcome.Defeat;
						}
					}
				}
			}
		}
		
		private bool IsAllEnemiesDefeated()
		{
			List<Combatant> enemies = ORK.Game.Combatants.Get(
				ORK.Game.ActiveGroup.Leader, false, Range.Infinity, 
				Consider.Yes, Consider.Ignore, Consider.Yes);
			
			for(int i=0; i<enemies.Count; i++)
			{
				if(enemies[i] != null && !enemies[i].Dead)
				{
					return false;
				}
			}
			return true;
		}
		
		private void EndBattle()
		{
			this.waitForLastActionOutcome = BattleOutcome.None;
			if(this.currentSystem != null)
			{
				this.currentSystem.EndBattle();
			}
			this.battleEnd = true;
			ORK.BattleSettings.camera.EndBattle();
			this.inBattle = false;
			this.ClearMenuUsers();
		}
		
		public void BattleVictory()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleWon();
			}
			this.EndBattle();
			
			// player/allies celebrate
			List<Combatant> group = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
				true, Range.Infinity, Consider.No, Consider.Ignore, Consider.Yes);
			for(int i=0; i<group.Count; i++)
			{
				if(!group[i].Dead)
				{
					group[i].Animations.Play(ORK.AnimationTypes.victoryID);
				}
			}
			
			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.Victory);
			}
		}
		
		public void BattleEscaped()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleEscaped();
			}
			this.EndBattle();
			
			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.Escape);
			}
		}
		
		public void BattleLost()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleLost();
			}
			this.EndBattle();
			
			// enemies celebrate
			List<Combatant> group = ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
				true, Range.Infinity, Consider.Yes, Consider.Ignore, Consider.Yes);
			for(int i=0; i<group.Count; i++)
			{
				if(!group[i].Dead)
				{
					group[i].Animations.Play(ORK.AnimationTypes.victoryID);
				}
			}
			
			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.Defeat);
			}
		}
		
		public void BattleLeftArena()
		{
			if(!this.IsRealTime())
			{
				ORK.Statistic.BattleEscaped();
			}
			this.EndBattle();
			
			if(this.battleArena != null)
			{
				this.battleArena.BattleFinished(BattleOutcome.LeaveArena);
			}
		}
		
		public void ClearObjectsAndAnimations()
		{
			if(this.groupCenter)
			{
				GameObject.Destroy(this.groupCenter);
			}
			if(this.combatantCenter)
			{
				GameObject.Destroy(this.combatantCenter);
			}
			
			List<Combatant> list = ORK.Game.Combatants.Get(true, Consider.No, Consider.Yes);
			for(int i=0; i<list.Count; i++)
			{
				if(!list[i].Dead)
				{
					list[i].Animations.Stop(ORK.AnimationTypes.victoryID);
					list[i].Animations.Play(ORK.AnimationTypes.idleID);
				}
			}
			
			List<Combatant> group = ORK.Game.ActiveGroup.GetBattle();
			for(int i=0; i<group.Count; i++)
			{
				if(!group[i].Dead)
				{
					group[i].Animations.Stop(ORK.AnimationTypes.victoryID);
					group[i].Animations.Play(ORK.AnimationTypes.idleID);
				}
			}
			if(this.IsRealTime())
			{
				ORK.Control.ClearInBattle();
			}
			
			// if player not spawned, spawn it again
			ORK.Game.PlayerHandler.AfterBattleSpawn();
		}
		
		
		/*
		============================================================================
		Gain functions
		============================================================================
		*/
		public bool HasGains()
		{
			return this.loot.Count > 0 || this.expGains.Count > 0;
		}
		
		public void ClearGains()
		{
			this.loot = new List<IShortcut>();
			this.expGains = new Dictionary<int, List<ExperienceLoot>>();
		}
		
		public void AddLoot(ItemGain item)
		{
			if(this.currentSystem != null && 
				item != null && item.CheckChance())
			{
				ShortcutHelper.Add(ref this.loot, item.CreateShortcut(), 
							this.currentSystem.gainsStack);
			}
		}
		
		public void AddExperienceReward(int statusID, int exp, int level, int classLevel)
		{
			if(!this.expGains.ContainsKey(statusID))
			{
				this.expGains.Add(statusID, new List<ExperienceLoot>());
			}
			this.expGains[statusID].Add(new ExperienceLoot(exp, level, classLevel));
		}
		
		public void CollectGains(bool showGains, float autoClose, bool autoCloseControlable, 
			BaseEvent baseEvent, int next)
		{
			List<string> endTexts = new List<string>();
			
			string moneyText = "";
			string itemText = "";
			string expText = "";
			int[] totalMoney = new int[ORK.Currencies.Count];
			
			// item gains
			for(int i=0; i<this.loot.Count; i++)
			{
				if(ORK.Game.ActiveGroup.Leader.Inventory.Add(this.loot[i], true, true))
				{
					if(this.loot[i] is MoneyShortcut)
					{
						totalMoney[this.loot[i].ID] += this.loot[i].Quantity;
					}
					else if(this.loot[i] is ItemShortcut || 
						this.loot[i] is EquipShortcut)
					{
						string tmp = ORK.BattleEnd.GetItemText(
							ORK.Game.ActiveGroup.Leader, this.loot[i]);
						if("" != tmp)
						{
							itemText += tmp + "\n";
						}
					}
				}
			}
			
			for(int i=0; i<totalMoney.Length; i++)
			{
				if(totalMoney[i] > 0)
				{
					moneyText = ORK.BattleEnd.GetMoneyText(
						ORK.Game.ActiveGroup.Leader, i, totalMoney[i]) + "\n";
				}
			}
			
			List<Combatant> group = null;
			if(ORK.BattleEnd.wholePartyExp)
			{
				group = ORK.Game.ActiveGroup.GetGroup();
			}
			else
			{
				group = ORK.Game.ActiveGroup.GetBattle();
			}
			
			// experience gains
			for(int i=0; i<group.Count; i++)
			{
				if(ORK.BattleEnd.deadExp || !group[i].Dead)
				{
					foreach(KeyValuePair<int, List<ExperienceLoot>> pair in this.expGains)
					{
						int exp = 0;
						for(int j=0; j<pair.Value.Count; j++)
						{
							exp += group[i].Status[pair.Key].Setting.GetExperience(
								pair.Value[j].experience, 
								group[i].Level - pair.Value[j].baseLevel, 
								group[i].ClassLevel - pair.Value[j].classLevel);
						}
						
						if(exp > 0)
						{
							exp = (int)(exp * group[i].ExperienceFactor);
							string tmp = ORK.BattleEnd.GetExperienceText(group[i], pair.Key, exp);
							if("" != tmp)
							{
								expText += tmp + "\n";
							}
							
							group[i].Status[pair.Key].AddValue(exp, false, true, false, false, true, true);
						}
					}
				}
			}
			
			// check level up
			for(int i=0; i<group.Count; i++)
			{
				string tmp = group[i].CheckLevelUp();
				if("" != tmp && ORK.BattleEnd.showLevelUp)
				{
					endTexts.Add(tmp);
				}
			}
			
			if(moneyText != "" || itemText != "" || expText != "")
			{
				string tmpText = ORK.BattleEnd.GetGainText(moneyText, itemText, expText);
				if(ORK.BattleEnd.showGains && "" != tmpText)
				{
					endTexts.Insert(0, tmpText);
				}
			}
			
			this.ClearGains();
			
			if(endTexts.Count > 0)
			{
				StringBuilder builder = new StringBuilder();
				for(int i=0; i<endTexts.Count; i++)
				{
					if(i > 0)
					{
						builder.Append(TextCode.NextPage);
					}
					builder.Append(endTexts[i]);
				}
				
				string gainsText = builder.ToString();
				if(showGains && gainsText != "")
				{
					ORK.BattleEnd.end.Show(gainsText, autoClose, autoCloseControlable, baseEvent, next);
				}
			}
		}
		
		
		/*
		============================================================================
		Looking functions
		============================================================================
		*/
		public void SetLooks(Combatant user)
		{
			this.DoLookAt(user, 
				ORK.Game.Combatants.Get(user != null ? user : ORK.Game.ActiveGroup.Leader, 
					true, Range.Infinity, Consider.No, Consider.Ignore, Consider.Yes), 
				ORK.Game.Combatants.Get(user != null ? user : ORK.Game.ActiveGroup.Leader, 
					true, Range.Infinity, Consider.Yes, Consider.Ignore, Consider.Yes));
		}
		
		public void DoLookAt(Combatant user, List<Combatant> group, List<Combatant> enemies)
		{
			if(enemies != null && enemies.Count > 0 &&
				group != null && group.Count > 0)
			{
				this.GroupLookAt(user, this.GetGroupCenter(enemies), group);
				this.GroupLookAt(user, this.GetGroupCenter(group), enemies);
			}
		}
		
		public void DoLookAt(Combatant user, List<Combatant> targets)
		{
			if(user != null && targets.Count > 0)
			{
				this.UserLookAt(this.GetGroupCenter(targets), user);
			}
		}
		
		public GameObject GetGroupCenter(List<Combatant> cs)
		{
			int count = 0;
			Vector3 cen = Vector3.zero;
			for(int i=0; i<cs.Count; i++)
			{
				if(cs[i] != null && cs[i].GameObject != null)
				{
					cen += cs[i].GameObject.transform.position;
					count++;
				}
			}
			if(count > 0)
			{
				cen /= count;
				if(this.groupCenter == null)
				{
					this.groupCenter = new GameObject("_tmp");
					if(this.battleArena != null)
					{
						this.groupCenter.transform.parent = this.battleArena.transform.parent;
					}
				}
				this.groupCenter.transform.position = cen;
			}
			return this.groupCenter;
		}
		
		public void GroupLookAt(Combatant user, GameObject cen, List<Combatant> cs)
		{
			for(int i=0; i<cs.Count; i++)
			{
				if(cs[i] != null && cs[i].GameObject != null && 
					(!cs[i].Actions.InAction || cs[i] == user))
				{
					cs[i].GameObject.transform.LookAt(new Vector3(cen.transform.position.x, 
							cs[i].GameObject.transform.position.y, cen.transform.position.z));
				}
			}
		}
		
		public void UserLookAt(GameObject cen, Combatant user)
		{
			if(user != null && user.GameObject != null)
			{
				user.GameObject.transform.LookAt(new Vector3(cen.transform.position.x, 
						user.GameObject.transform.position.y, cen.transform.position.z));
			}
		}
		
		public GameObject GetCombatantCenter()
		{
			if(this.combatantCenter == null)
			{
				this.combatantCenter = new GameObject();
			}
			int count = 0;
			this.combatantCenter.transform.position = Vector3.zero;
			
			List<Combatant> list = ORK.Game.Combatants.Get(true, Consider.No, Consider.Yes);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null && list[i].GameObject != null)
				{
					this.combatantCenter.transform.position += list[i].GameObject.transform.position;
					count++;
				}
			}
			if(count > 0)
			{
				this.combatantCenter.transform.position /= count;
			}
			return this.combatantCenter;
		}
		
		public GameObject GetArenaCenter()
		{
			if(this.battleArena == null)
			{
				return this.GetCombatantCenter();
			}
			else
			{
				return this.battleArena.gameObject;
			}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public bool DisplayInfoTexts()
		{
			if(this.currentSystem != null)
			{
				if(this.IsTurnBased())
				{
					return ORK.BattleTexts.infoInTurnBased;
				}
				else if(this.IsActiveTime())
				{
					return ORK.BattleTexts.infoInActiveTime;
				}
				else if(this.IsRealTime())
				{
					return ORK.BattleTexts.infoInRealTime;
				}
				else if(this.IsPhase())
				{
					return ORK.BattleTexts.infoPhase;
				}
			}
			else
			{
				return ORK.BattleTexts.infoInField;
			}
			return false;
		}
		
		public bool IsMenuBackAllowed
		{
			get
			{
				if(this.currentSystem != null)
				{
					return this.currentSystem.IsMenuBackAllowed;
				}
				return true;
			}
		}
		
		public bool MenuActive
		{
			get{ return this.menuUser.Count > 0;}
		}
		
		public int MenuCount
		{
			get{ return this.menuUser.Count;}
		}
		
		public Combatant GetMenuUser()
		{
			if(this.menuIndex >= 0 && this.menuIndex < this.menuUser.Count)
			{
				return this.menuUser[this.menuIndex];
			}
			return null;
		}
		
		public void AddMenuUser(Combatant c)
		{
			if(!this.menuUser.Contains(c))
			{
				this.menuUser.Add(c);
				
				if(this.menuUser.Count == 1)
				{
					this.CheckMenuIndex();
					if(ORK.BattleSettings.camera.blockEventCams && 
						this.menuUser[this.menuIndex].GameObject != null)
					{
						ORK.BattleSettings.camera.SetMenuUser(this.menuUser[this.menuIndex].GameObject.transform);
					}
				}
			}
		}
		
		public void RemoveMenuUser(Combatant c)
		{
			this.menuUser.Remove(c);
			if(ORK.BattleSettings.camera.blockEventCams && 
				this.menuUser.Count == 0)
			{
				ORK.BattleSettings.camera.SetMenuUser(null);
			}
			if(this.menuUser.Count > 0)
			{
				this.CheckMenuIndex();
				this.menuUser[this.menuIndex].BattleMenu.Reset(true);
			}
		}
		
		public void ClearMenuUsers()
		{
			for(int i=0; i<this.menuUser.Count; i++)
			{
				this.menuUser[i].EndBattleMenu(true);
			}
			this.menuUser = new List<Combatant>();
			
			if(ORK.BattleSettings.camera.blockEventCams)
			{
				ORK.BattleSettings.camera.SetMenuUser(null);
			}
		}
		
		public void SetMenuFinished()
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.BattleMenuFinished();
			}
		}
		
		public bool CombatantClicked(Combatant combatant)
		{
			if(this.menuUser.Count > 0)
			{
				return this.menuUser[this.menuIndex].BattleMenu.CombatantClicked(combatant);
			}
			else if(this.currentSystem != null)
			{
				return this.currentSystem.CombatantClicked(combatant);
			}
			return false;
		}
		
		private void CheckMenuIndex()
		{
			if(this.menuIndex < 0)
			{
				this.menuIndex = this.menuUser.Count - 1;
			}
			else if(this.menuIndex >= this.menuUser.Count)
			{
				this.menuIndex = 0;
			}
		}
		
		public void ChangeMenuUserIndex(int change)
		{
			if(this.menuUser.Count > 1 && 
				this.menuUser[this.menuIndex].BattleMenu.Controlable)
			{
				if(this.menuUser[this.menuIndex].BattleMenu.Box != null)
				{
					this.menuUser[this.menuIndex].BattleMenu.Box.Audio.PlayUserChange();
				}
				this.menuUser[this.menuIndex].BattleMenu.Reset(false);
				this.menuIndex += change;
				this.CheckMenuIndex();
				this.menuUser[this.menuIndex].BattleMenu.Reset(true);
				
				if(ORK.BattleSettings.camera.blockEventCams && 
					this.menuUser[this.menuIndex].GameObject != null)
				{
					ORK.BattleSettings.camera.SetMenuUser(this.menuUser[this.menuIndex].GameObject.transform);
				}
			}
		}
		
		public void ChangeMenuAbilityLevel(int change)
		{
			if(this.menuUser.Count > 0)
			{
				this.menuUser[this.menuIndex].BattleMenu.ChangeAbilityLevel(change);
			}
		}
		
		public void BattleMenuCanceled(Combatant user)
		{
			if(this.currentSystem != null)
			{
				this.currentSystem.BattleMenuCanceled(user);
			}
		}
		
		
		/*
		============================================================================
		Control block functions
		============================================================================
		*/
		public void DoBattleBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(BattleControlBlock.Battle.Equals(this.currentSystem.playerControl))
				{
					ORK.Control.SetBlockPlayer(add);
				}
				if(BattleControlBlock.Battle.Equals(this.currentSystem.cameraControl))
				{
					ORK.Control.SetBlockCamera(add);
				}
			}
		}
		
		public void DoBattleMenuBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(this.currentSystem.playerBattleMenu)
				{
					ORK.Control.SetBlockPlayer(add);
				}
				if(this.currentSystem.cameraBattleMenu)
				{
					ORK.Control.SetBlockCamera(add);
				}
			}
			else
			{
				if(ORK.BattleSystem.fieldMode.playerBattleMenu)
				{
					ORK.Control.SetBlockPlayer(add);
				}
				if(ORK.BattleSystem.fieldMode.cameraBattleMenu)
				{
					ORK.Control.SetBlockCamera(add);
				}
			}
		}
		
		public void DoAllActionsBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(BattleControlBlock.AllActions.Equals(this.currentSystem.playerControl))
				{
					ORK.Control.SetBlockPlayer(add);
				}
				if(BattleControlBlock.AllActions.Equals(this.currentSystem.cameraControl))
				{
					ORK.Control.SetBlockCamera(add);
				}
			}
		}
		
		public void DoPlayerActionsBlock(int add)
		{
			if(this.currentSystem != null)
			{
				if(BattleControlBlock.PlayerActions.Equals(this.currentSystem.playerControl))
				{
					ORK.Control.SetBlockPlayer(add);
				}
				if(BattleControlBlock.PlayerActions.Equals(this.currentSystem.cameraControl))
				{
					ORK.Control.SetBlockCamera(add);
				}
			}
			else
			{
				if(ORK.BattleSystem.fieldMode.blockPlayerControl)
				{
					ORK.Control.SetBlockPlayer(add);
				}
				if(ORK.BattleSystem.fieldMode.blockCameraControl)
				{
					ORK.Control.SetBlockCamera(add);
				}
			}
		}
		
		
		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		public bool CanUseMoveAI(Combatant combatant)
		{
			if(this.IsBattleRunning())
			{
				return combatant.MoveAI != null && this.currentSystem.allowMoveAI && 
					(!this.currentSystem.blockInBattleMoveAI || !combatant.InBattle) && 
					this.currentSystem.moveAIRange.InRange(combatant, ORK.Game.ActiveGroup.Leader);
			}
			return combatant.MoveAI != null && 
				ORK.BattleSettings.moveAIRange.InRange(combatant, ORK.Game.ActiveGroup.Leader);
		}
		
		public void DoMoveAIBlock(int add)
		{
			if(this.currentSystem != null && !this.currentSystem.allowMoveAI)
			{
				ORK.Control.SetBlockMoveAI(add);
			}
		}
	}
}
