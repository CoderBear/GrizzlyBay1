
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionSelection : BaseData
	{
		[ORKEditorHelp("Action Type", "Select the action type the combatant will perform:\n" +
			"- Attack: Performs a base attack.\n" +
			"- Counter Attack: Performs a counter attack. Counter attacks can't be countered.\n" +
			"- Ability: Uses an ability.\n" +
			"- Item: Uses an item.\n" +
			"- Defend: Uses the defend command.\n" +
			"- Escape: Uses the escape command.\n" +
			"- Death: The combatant dies.\n" +
			"- None: Does nothing.\n" +
			"- Change Member: The combatant is exchanged with a non-battle group member.", "")]
		public ActionSelectType type = ActionSelectType.Attack;
		
		// ability
		[ORKEditorHelp("Ability", "Select the ability the combatant will use.\n" +
			"If the combatant doesn't have the ability, the ability wont be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("type", ActionSelectType.Ability, endCheckGroup=true)]
		public int abilityID = 0;
		
		// item
		[ORKEditorHelp("Item", "Select the item the combatant will use.\n" +
			"If the combatant doesn't have the item in his inventory, the item wont be used.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout("type", ActionSelectType.Item, endCheckGroup=true)]
		public int itemID = 0;
		
		// member index
		[ORKEditorHelp("Member Index", "The index of the non-battle member the combatant will be exchanged with.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("type", ActionSelectType.ChangeMember, endCheckGroup=true)]
		public int memberIndex = 0;
		
		public ActionSelection()
		{
			
		}
		
		public BaseAction GetAction(Combatant combatant, bool checkTime)
		{
			BaseAction action = null;
			
			if(ActionSelectType.Attack.Equals(this.type) && 
				!combatant.Status.BlockAttack)
			{
				ActionSelection.UseAbility(combatant, combatant.GetCurrentBaseAttack(), 
					checkTime, true, false, out action);
			}
			// counter
			else if(ActionSelectType.CounterAttack.Equals(this.type) && 
				!combatant.Status.BlockAttack)
			{
				ActionSelection.UseAbility(combatant, combatant.GetCounterAttack(), 
					checkTime, true, false, out action);
			}
			// ability
			else if(ActionSelectType.Ability.Equals(this.type) && 
				!combatant.Status.BlockAbilities)
			{
				AbilityShortcut ability = combatant.Abilities.Get(this.abilityID);
				if(ability != null)
				{
					ability.SetHighestUseLevel(combatant);
					ActionSelection.UseAbility(combatant, ability, 
						checkTime, true, false, out action);
				}
			}
			// item
			else if(ActionSelectType.Item.Equals(this.type) && !combatant.Status.BlockItems)
			{
				ActionSelection.UseItem(combatant, combatant.Inventory.GetItem(this.itemID), 
					checkTime, true, false, out action);
			}
			// defend
			else if(ActionSelectType.Defend.Equals(this.type) && 
				!combatant.Status.BlockDefend)
			{
				action = new DefendAction(combatant);
			}
			// escape
			else if(ActionSelectType.Escape.Equals(this.type) && 
				!combatant.Status.BlockEscape)
			{
				action = new EscapeAction(combatant);
			}
			// death
			else if(ActionSelectType.Death.Equals(this.type))
			{
				action = new DeathAction(combatant, false);
			}
			// none
			else if(ActionSelectType.None.Equals(this.type))
			{
				action = new NoneAction(combatant);
			}
			// change member
			else if(ActionSelectType.ChangeMember.Equals(this.type))
			{
				Combatant target = combatant.Group.NonBattleMemberAt(this.memberIndex);
				if(target != null)
				{
					action = new ChangeMemberAction(combatant, target);
				}
			}
			
			return action;
		}
		
		public static bool UseAbility(Combatant user, AbilityShortcut ability, bool checkTime, 
			bool useAutoTarget, bool needTargets, out BaseAction action)
		{
			action = null;
			if(ability != null && 
				ability.CanUse(user, checkTime && !AbilityActionType.CounterAttack.Equals(ability.Type)))
			{
				// target self
				if(ability.TargetSelf())
				{
					action = new AbilityAction(user, ability);
					action.SetTarget(user);
				}
				// auto target
				else if(useAutoTarget)
				{
					action = new AbilityAction(user, ability);
					action.AutoTarget(user.LastTargets, 
						ORK.Game.Combatants.Get(user, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Yes), 
						ORK.Game.Combatants.Get(user, false, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes));
				}
				else
				{
					// group target
					Combatant target = user.Group.SelectedTargets.GetAbilityTarget(user, ability);
					if(target != null)
					{
						action = new AbilityAction(user, ability);
						action.SetTarget(target);
					}
					else
					{
						// individual target
						target = user.SelectedTargets.GetAbilityTarget(user, ability);
						if(target != null)
						{
							action = new AbilityAction(user, ability);
							action.SetTarget(target);
						}
						// select target
						else if(!needTargets || ability.GetPossibleTargets(user, 
							ORK.Game.Combatants.Get(user, true, Range.Battle, 
								Consider.No, Consider.Ignore, user.InBattle ? Consider.Yes : Consider.Ignore), 
							ORK.Game.Combatants.Get(user, true, Range.Battle, 
								Consider.Yes, Consider.Ignore, user.InBattle ? Consider.Yes : Consider.Ignore)).Count > 0)
						{
							new AbilityBMItem(ability, null).Selected(user);
							return true;
						}
					}
				}
			}
			return false;
		}
		
		public static bool UseItem(Combatant user, ItemShortcut item, bool checkTime, 
			bool useAutoTarget, bool needTargets, out BaseAction action)
		{
			action = null;
			if(item != null && item.CanUse(user, checkTime))
			{
				// target self
				if(item.Setting.targetSettings.TargetSelf())
				{
					action = new ItemAction(user, item);
					action.SetTarget(user);
				}
				// auto target
				else if(useAutoTarget)
				{
					action = new ItemAction(user, item);
					action.AutoTarget(user.LastTargets, 
						ORK.Game.Combatants.Get(user, true, Range.Battle, Consider.No, Consider.Ignore, Consider.Yes), 
						ORK.Game.Combatants.Get(user, false, Range.Battle, Consider.Yes, Consider.Ignore, Consider.Yes));
				}
				else
				{
					// group target
					Combatant target = user.Group.SelectedTargets.GetItemTarget(user, item);
					if(target != null)
					{
						action = new ItemAction(user, item);
						action.SetTarget(target);
					}
					else
					{
						// individual target
						target = user.SelectedTargets.GetItemTarget(user, item);
						if(target != null)
						{
							action = new ItemAction(user, item);
							action.SetTarget(target);
						}
						// select target
						else if(!needTargets || item.Setting.targetSettings.GetPossibleTargets(user, 
							ORK.Game.Combatants.Get(user, true, Range.Battle, 
								Consider.No, Consider.Ignore, user.InBattle ? Consider.Yes : Consider.Ignore), 
							ORK.Game.Combatants.Get(user, true, Range.Battle, 
								Consider.Yes, Consider.Ignore, user.InBattle ? Consider.Yes : Consider.Ignore)).Count > 0)
						{
							new ItemBMItem(item, null).Selected(user);
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
