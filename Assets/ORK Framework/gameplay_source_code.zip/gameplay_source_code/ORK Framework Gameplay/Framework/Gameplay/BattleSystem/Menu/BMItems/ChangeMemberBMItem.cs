
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChangeMemberBMItem : BMItem
	{
		private Combatant combatant;
		
		public ChangeMemberBMItem(ChoiceContent content, Combatant combatant)
		{
			this.content = content;
			this.combatant = combatant;
		}
		
		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && this.combatant != null && 
				owner.BattleMenu.Settings.showChangePortraits)
			{
				this.content.portrait = this.combatant.GetPortrait(
					owner.BattleMenu.Settings.changePortraitTypeID);
			}
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			// sub menu
			if(this.combatant == null)
			{
				this.content.Active = owner.Group.NonBattleSize > 0;
			}
			else
			{
				this.content.Active = !combatant.Dead;
			}
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				// list non-battle combatants
				if(this.combatant == null)
				{
					List<BMItem> list = new List<BMItem>();
					
					// back button first
					if(owner.BattleMenu.Settings.addBack && 
						owner.BattleMenu.Settings.backFirst)
					{
						list.Add(new BackBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}
					
					List<Combatant> members = owner.Group.GetNonBattle();
					for(int i=0; i<members.Count; i++)
					{
						if(members[i] != owner)
						{
							list.Add(new ChangeMemberBMItem(
								owner.BattleMenu.GetCombatantChoice(members[i]), 
								members[i]));
						}
					}
					
					// back button last
					if(owner.BattleMenu.Settings.addBack && 
						!owner.BattleMenu.Settings.backFirst)
					{
						list.Add(new BackBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}
					
					owner.BattleMenu.Show(list, 0, BattleMenuMode.ChangeMember);
				}
				// fire change action
				else
				{
					owner.BattleMenu.AddAction(new ChangeMemberAction(owner, this.combatant));
				}
			}
		}
		
		public override void Blink(bool doBlink)
		{
			if(this.combatant != null)
			{
				TargetHelper.Blink(this.combatant, doBlink);
				if(doBlink && ORK.BattleSettings.camera.blockEventCams && 
					this.combatant.GameObject != null)
				{
					ORK.BattleSettings.camera.SetSelection(this.combatant.GameObject.transform);
				}
			}
		}
	}
}
