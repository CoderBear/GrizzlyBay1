
using System.Collections.Generic;

namespace ORKFramework
{
	public class EquipmentBMItem : BMItem
	{
		private int partID = -1;
		
		private EquipShortcut equip;
		
		public EquipmentBMItem(int partID, EquipShortcut equip, ChoiceContent content)
		{
			this.partID = partID;
			this.equip = equip;
			this.content = content;
		}
		
		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && 
				owner.BattleMenu.Settings.showEquipPortraits && 
				this.equip.HasPortrait())
			{
				this.content.portrait = this.equip.GetPortrait();
			}
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			this.content.Active = this.equip.CanEquip(owner);
			return tmp != this.content.Active;
		}

		public override void Selected(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				owner.Equipment.Equip(this.partID, this.equip, owner.Inventory, true);
				
				if(owner.BattleMenu.CommandedBy != null)
				{
					owner.EndBattleMenu(true);
				}
				else
				{
					owner.BattleMenu.Show(true);
				}
			}
		}
	}
}
