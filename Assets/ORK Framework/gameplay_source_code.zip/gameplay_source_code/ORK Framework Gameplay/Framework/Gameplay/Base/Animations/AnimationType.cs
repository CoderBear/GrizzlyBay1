
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class AnimationType : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this animation type.", "")]
		[ORKEditorInfo("Base Settings", "Set the name of this animation type.", "", 
			expandWidth=true, endFoldout=true)]
		public string name = "";

		public AnimationType()
		{
			
		}
		
		public AnimationType(string name)
		{
			this.name = name;
		}
	}
}
