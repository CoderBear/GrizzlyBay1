
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class ChangeGameVariable : BaseData
	{
		[ORKEditorInfo(labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Remove", "The game variable will be removed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool remove = false;
		
		[ORKEditorHelp("Type", "Select the type of the game variable:\n" +
			"- String: A string variable.\n" +
			"- Bool: A bool variable.\n" +
			"- Float: A float variable.\n" +
			"- Vector3: A Vector3 variable.", "")]
		[ORKEditorLayout("remove", false)]
		public GameVariableType type = GameVariableType.String;
		
		
		// string
		[ORKEditorInfo(labelText="String Value")]
		[ORKEditorLayout("type", GameVariableType.String, endCheckGroup=true, autoInit=true)]
		public StringValue stringValue;
		
		
		// bool
		[ORKEditorHelp("Value", "The value the game variable will be set to.", "")]
		[ORKEditorLayout("type", GameVariableType.Bool, endCheckGroup=true)]
		public bool boolValue = false;
		
		
		// float
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		[ORKEditorLayout("type", GameVariableType.Float)]
		public FormulaOperator floatOperator = FormulaOperator.Add;
		
		[ORKEditorInfo(labelText="Float Value", label=new string[] {"The player is used as user and target when using Formula."})]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FloatValue floatValue;
		
		
		// vector3
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Set: Sets the current variable value to the value.\n" +
			"- Cross: The cross product of the current value (left hand side) and the defined value (right hand side).\n" +
			"- Min: A new vector created of the smallest values of the current value and the defined value.\n" +
			"- Max: A new vector created of the largest values of the current value and the defined value.\n" +
			"- Scale: Multiplies each component of the current value by the same component of the defined value.\n" +
			"- Project: Projects the current value using the defind value as 'onNormal'.\n" +
			"- Reflect: Reflects the current value using the defined value as 'inNormal.\n" +
			"More information on Vector3 operations can be found in the Unity documentation.", "")]
		[ORKEditorLayout("type", GameVariableType.Vector3)]
		public Vector3Operator vector3Operator = Vector3Operator.Set;
		
		[ORKEditorHelp("Normalize", "The Vector3 value will be normalized after the operation.", "")]
		public bool vector3Normalize = false;
		
		[ORKEditorInfo(labelText="Vector3 Value")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true)]
		public Vector3Value vector3Value;
		
		public ChangeGameVariable()
		{
			
		}
		
		public void Change(VariableHandler handler)
		{
			if(this.remove)
			{
				handler.Remove(this.key.GetValue());
			}
			else if(GameVariableType.String.Equals(this.type))
			{
				handler.Set(this.key.GetValue(), this.stringValue.GetValue());
			}
			else if(GameVariableType.Bool.Equals(this.type))
			{
				handler.Set(this.key.GetValue(), this.boolValue);
			}
			else if(GameVariableType.Float.Equals(this.type))
			{
				handler.ChangeFloat(
					this.key.GetValue(), 
					this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
					this.floatOperator);
			}
			else if(GameVariableType.Vector3.Equals(this.type))
			{
				handler.ChangeVector3(
					this.key.GetValue(), 
					this.vector3Value.GetValue(), 
					this.vector3Operator, 
					this.vector3Normalize);
			}
		}
	}
}
