
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using ORKFramework.Formulas;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Change Game Variables", "Changes game variables.", "")]
	[ORKNodeInfo("Variable Steps")]
	public class ChangeGameVariableStep : BaseFormulaStep
	{
		// object variables
		[ORKEditorHelp("Use Object Variable", "Use an object variable of a combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"otherwise no variables will be set.", "")]
		public bool useObjectVariable = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useObjectVariable", true, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;
		
		
		// variables
		[ORKEditorInfo(separator=true)]
		public VariableSetter change = new VariableSetter();
		
		public ChangeGameVariableStep()
		{
			
		}

		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			if(this.useObjectVariable)
			{
				Combatant combatant = this.origin.GetCombatant(user, target);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						this.change.SetVariables(comp.GetHandler());
					}
				}
			}
			else
			{
				this.change.SetVariables(ORK.Game.Variables);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObjectVariable ? this.origin.GetInfoText() : "Global Variables";
		}
	}
	
	[ORKEditorHelp("Check Game Variables", "Checks if game variables have certain values.\n" +
		"If the check is true, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKNodeInfo("Variable Steps", "Check Steps")]
	public class CheckGameVariableStep : BaseFormulaCheckStep
	{
		// object variables
		[ORKEditorHelp("Use Object Variable", "Use an object variable of a combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"otherwise the check fails.", "")]
		public bool useObjectVariable = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useObjectVariable", true, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;
		
		
		// variables
		[ORKEditorInfo(separator=true)]
		public VariableCondition condition = new VariableCondition();
		
		public CheckGameVariableStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			bool check = false;
			if(this.useObjectVariable)
			{
				Combatant combatant = this.origin.GetCombatant(user, target);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						check = this.condition.CheckVariables(comp.GetHandler());
					}
				}
			}
			else
			{
				check = this.condition.CheckVariables(ORK.Game.Variables);
			}
			
			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObjectVariable ? this.origin.GetInfoText() : "Global Variables";
		}
	}
	
	[ORKEditorHelp("Game Variable Fork", "Checks if a single game variable for certain values.\n" +
		"If a variable condition is valid, it's next step will be executed.\n" +
		"If no variable condition is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Variable Steps", "Check Steps")]
	public class GameVariableForkStep : BaseFormulaCheckStep
	{
		// object variables
		[ORKEditorHelp("Use Object Variable", "Use an object variable of a combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"otherwise the check fails.", "")]
		public bool useObjectVariable = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useObjectVariable", true, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;
		
		
		// variable
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorArray(false, "Add Condition", "Adds a new game variable condition.", "", 
			"Remove", "Removes the game variable condition.", "", isMove=true, isCopy=true, 
			noRemoveCount=1, foldout=true, foldoutText=new string[] {
				"Variable Condition", "Define the game variable condition that must be valid.", ""
		})]
		public CheckVariableNextNode[] condition = new CheckVariableNextNode[] {new CheckVariableNextNode()};
		
		public GameVariableForkStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			int check = this.next;
			
			if(this.useObjectVariable)
			{
				Combatant combatant = this.origin.GetCombatant(user, target);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						this.Check(ref check, this.key.GetValue(), comp.GetHandler());
					}
				}
			}
			else
			{
				this.Check(ref check, this.key.GetValue(), ORK.Game.Variables);
			}
			
			return check;
		}
		
		private bool Check(ref int check, string varKey, VariableHandler handler)
		{
			for(int i=0; i<this.condition.Length; i++)
			{
				if(this.condition[i].Check(varKey, handler))
				{
					check = this.condition[i].next;
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObjectVariable ? this.origin.GetInfoText() : "Global Variables";
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Condition " + (index - 1) + ": " + this.condition[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.condition.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.condition[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.condition[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Store Formula Value", "Stores the current value of the formula into a float game variable.", "")]
	[ORKNodeInfo("Variable Steps")]
	public class StoreFormulaValueStep : BaseFormulaStep
	{
		// object variables
		[ORKEditorHelp("Use Object Variable", "Use an object variable of a combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"otherwise no variables will be set.", "")]
		public bool useObjectVariable = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useObjectVariable", true, endCheckGroup=true, autoInit=true)]
		public FormulaStatusOrigin origin;
		
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Add;
		
		public StoreFormulaValueStep()
		{
			
		}

		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			if(this.useObjectVariable)
			{
				Combatant combatant = this.origin.GetCombatant(user, target);
				if(combatant != null && combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						comp.GetHandler().Set(this.key.GetValue(), result);
					}
				}
			}
			else
			{
				ORK.Game.Variables.Set(this.key.GetValue(), result);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useObjectVariable ? 
				this.origin.GetInfoText() : "Global Variables") + ": " + 
				this.key.GetInfoText() + " " + this.floatOperator.ToString();
		}
	}
}
