
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FindObjectSetting : BaseData
	{
		[ORKEditorHelp("Search Type", "Select how the object will be searched:\n" +
			"- Name: The object is searched using it's name.\n" +
			"- Tag: The object is searched using it's tag.\n" +
			"- Component: The object is searched using an attached component.", "")]
		public FindObjectType type = FindObjectType.Name;
		
		[ORKEditorHelp("Find All", "Find all objects with the defined name, tag or component.\n" +
			"If disabled, the first object found will be used.", "")]
		public bool multiple = false;
		
		[ORKEditorHelp("Search Name", "The name, tag or component to search for.\n" +
			"When searching for a name, you can use '/' to traverse hierarchies like a path to get child objects.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		
		// range
		[ORKEditorHelp("Only in Range", "Search only for objects within a defined range.", "")]
		public bool useRange = false;
		
		[ORKEditorHelp("Search Range", "The range in world units.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useRange", true)]
		public float range = 10;
		
		[ORKEditorHelp("Ignore Y Distance", "Ignore the distance along the Y-axis.", "")]
		public bool ignoreYDistance = false;
		
		[ORKEditorHelp("Nearest Object", "Find the nearest object in range.\n" +
			"If disabled, the first object in range will be used.", "")]
		[ORKEditorLayout("multiple", false, endCheckGroup=true, endGroups=2, 
			setDefault=true, defaultValue=false)]
		public bool useNearest = false;
		
		public FindObjectSetting()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<bool>("isTag"))
			{
				bool tmp = false;
				data.Get("isTag", ref tmp);
				if(tmp)
				{
					this.type = FindObjectType.Tag;
				}
			}
		}
		
		public List<GameObject> Find(GameObject user)
		{
			List<GameObject> list = new List<GameObject>();
			
			if(this.multiple || this.useRange)
			{
				if(FindObjectType.Name.Equals(this.type))
				{
					GameObject[] tmp = GameObject.FindObjectsOfType(typeof(GameObject)) as GameObject[];
					if(tmp != null && tmp.Length > 0)
					{
						for(int i=0; i<tmp.Length; i++)
						{
							if(tmp[i].name == this.name && 
								(!this.useRange || VectorHelper.Distance(user, tmp[i], this.ignoreYDistance) <= this.range))
							{
								list.Add(tmp[i]);
								if(!this.multiple && this.useRange && !this.useNearest)
								{
									break;
								}
							}
						}
					}
				}
				else if(FindObjectType.Tag.Equals(this.type))
				{
					GameObject[] tmp = GameObject.FindGameObjectsWithTag(this.name);
					if(tmp != null && tmp.Length > 0)
					{
						if(this.useRange)
						{
							for(int i=0; i<tmp.Length; i++)
							{
								if(VectorHelper.Distance(user, tmp[i], this.ignoreYDistance) <= this.range)
								{
									list.Add(tmp[i]);
									if(!this.multiple && !this.useNearest)
									{
										break;
									}
								}
							}
						}
						else
						{
							list.AddRange(tmp);
						}
					}
				}
				else if(FindObjectType.Component.Equals(this.type))
				{
					System.Type type = ORK.Core.TypeHandler.GetType(this.name, typeof(Component));
					if(type != null)
					{
						GameObject[] tmp = GameObject.FindObjectsOfType(typeof(GameObject)) as GameObject[];
						if(tmp != null && tmp.Length > 0)
						{
							for(int i=0; i<tmp.Length; i++)
							{
								if(tmp[i].GetComponent(type) != null && 
									(!this.useRange || VectorHelper.Distance(user, tmp[i], this.ignoreYDistance) <= this.range))
								{
									list.Add(tmp[i]);
									if(!this.multiple && this.useRange && !this.useNearest)
									{
										break;
									}
								}
							}
						}
					}
				}
			}
			else
			{
				if(FindObjectType.Name.Equals(this.type))
				{
					GameObject tmp = GameObject.Find(this.name);
					if(tmp != null)
					{
						list.Add(tmp);
					}
				}
				else if(FindObjectType.Tag.Equals(this.type))
				{
					GameObject tmp = GameObject.FindGameObjectWithTag(this.name);
					if(tmp != null)
					{
						list.Add(tmp);
					}
				}
				else if(FindObjectType.Component.Equals(this.type))
				{
					System.Type type = ORK.Core.TypeHandler.GetType(this.name, typeof(Component));
					if(type != null)
					{
						GameObject[] tmp = GameObject.FindObjectsOfType(typeof(GameObject)) as GameObject[];
						if(tmp != null && tmp.Length > 0)
						{
							for(int i=0; i<tmp.Length; i++)
							{
								if(tmp[i].GetComponent(type) != null)
								{
									list.Add(tmp[i]);
									break;
								}
							}
						}
					}
				}
			}
			
			if(!this.multiple && this.useRange && this.useNearest)
			{
				int nearest = -1;
				float dist = Mathf.Infinity;
				for(int i=0; i<list.Count; i++)
				{
					float tmpDist = VectorHelper.Distance(user, list[i], this.ignoreYDistance);
					if(tmpDist < dist)
					{
						dist = tmpDist;
						nearest = i;
					}
				}
				if(nearest >= 0 && nearest < list.Count)
				{
					GameObject tmpObj = list[nearest];
					list.Clear();
					list.Add(tmpObj);
				}
			}
			
			return list;
		}
	}
}
