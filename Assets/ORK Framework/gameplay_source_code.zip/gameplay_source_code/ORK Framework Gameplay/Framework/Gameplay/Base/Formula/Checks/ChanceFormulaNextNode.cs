
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class ChanceFormulaNextNode : BaseData
	{
		[ORKEditorInfo(labelText="Minimum Range")]
		public FormulaFloat minimum = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Maximum Range")]
		public FormulaFloat maximum = new FormulaFloat();
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public ChanceFormulaNextNode()
		{
			
		}
		
		public bool Contains(float chance, Combatant user, Combatant target)
		{
			return this.minimum.GetValue(user, target) <= chance && 
				chance <= this.maximum.GetValue(user, target);
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.minimum.GetInfoText() + " - " + this.maximum.GetInfoText();
		}
	}
}
