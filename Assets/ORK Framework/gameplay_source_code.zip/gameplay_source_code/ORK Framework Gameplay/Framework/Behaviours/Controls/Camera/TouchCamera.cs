
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Touch Camera")]
	public class TouchCamera : BaseCameraControl
	{
		public string onChild = "";

		public float distance = 10.0f;

		public float minHeight = 5.0f;

		public float height = 5.0f;

		public float maxHeight = 30.0f;

		public float heightDamping = 2.0f;
	
		public bool allowRotation = true;

		public bool allowZoom = true;

		public float rotation = 0;

		public float rotationDamping = 3.0f;
	
		public float rotationFactor = 1;

		public float zoomFactor = 1;
		
		public bool zoomAxis = false;
		
		public int zoomAxisKey = 0;
	
		public int zoomPlusKey = 0;

		public int zoomMinusKey = 0;

		public float zoomKeyChange = 3;
	
		public bool limitChange = true;
	
		public MouseTouchControl mouseTouch = new MouseTouchControl(false, 1, true, 2, 1, MouseTouch.Move);
	
		void LateUpdate()
		{
			GameObject obj = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(obj != null)
			{
				Transform target = obj.transform;
			
				Vector3 add = Vector3.zero;
				if((this.allowRotation || this.allowZoom) &&
				this.mouseTouch.Interacted(ref add))
				{
					add = this.mouseTouch.GetLastChange();
				
					if(this.allowRotation && this.allowZoom && this.limitChange)
					{
						if(Mathf.Abs(add.x) >= Mathf.Abs(add.y))
						{
							add.y = 0;
						}
						else
						{
							add.x = 0;
						}
					}
				
					if(this.allowRotation)
					{
						this.rotation += add.x * this.rotationFactor;
					}
					if(this.allowZoom)
					{
						this.height += add.y * this.zoomFactor;
					}
				
					if(this.rotation < 0)
					{
						this.rotation += 360;
					}
					else if(this.rotation > 360)
					{
						this.rotation -= 360;
					}
				}
				
				if(this.allowZoom)
				{
					if(this.zoomAxis)
					{
						this.height += ORK.InputKeys.Get(this.zoomAxisKey).GetAxis() * this.zoomKeyChange;
					}
					else
					{
						if(ORK.InputKeys.Get(this.zoomPlusKey).GetButton())
						{
							this.height -= this.zoomKeyChange;
						}
						else if(ORK.InputKeys.Get(this.zoomMinusKey).GetButton())
						{
							this.height += this.zoomKeyChange;
						}
					}
				}
			
				if(this.height < this.minHeight)
				{
					this.height = this.minHeight;
				}
				else if(this.height > this.maxHeight)
				{
					this.height = this.maxHeight;
				}
			
				float wantedHeight = target.position.y + this.height;
				float currentHeight = this.transform.position.y;
				if(this.heightDamping > 0)
				{
					currentHeight = Mathf.Lerp(currentHeight, wantedHeight, this.heightDamping * Time.deltaTime);
				}
				else
				{
					currentHeight = wantedHeight;
				}
			
				Vector3 pos = target.position - Vector3.forward * distance;
				pos.y = currentHeight;
				this.transform.position = pos;
			
				float wantedRotation = this.rotation;
				if(this.rotationDamping > 0)
				{
					wantedRotation = Mathf.LerpAngle(this.transform.eulerAngles.y, this.rotation, this.rotationDamping * Time.deltaTime);
				}
				this.transform.RotateAround(target.position, Vector3.up, wantedRotation);
				this.transform.LookAt(target);
			}
		}
	}
}
