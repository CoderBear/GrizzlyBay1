
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Player: Mouse Controller")]
	public class MousePlayerController : MonoBehaviour
	{
		public bool moveDead = true;

		public MouseTouchControl mouseTouch = new MouseTouchControl(true);
		
		
		// click
		public float raycastDistance = 100.0f;

		public LayerMask layerMask = -1;
	
		
		// move
		public GameObject cursorObject;

		public Vector3 cursorOffset = Vector3.zero;
	
		public float speedSmoothing = 10.0f;

		public bool useCharacterSpeed = false;

		public float runSpeed = 8.0f;

		public float gravity = Physics.gravity.y;

		public float minimumMoveDistance = 0.2f;

		public bool ignoreYDistance = true;

		public bool useEventMover = false;
	
		
		// outside field
		public bool autoRemoveCursor = true;
		
		public bool autoRemoveCursorTarget = true;

		public bool autoStopMove = true;
		
		
		// secure move
		public bool secureMove = false;
		
		public float secureTime = 0.5f;
	
		
		// ingame
		private Vector3 targetPosition = Vector3.zero;

		private CharacterController controller;

		private GameObject targetCursor;
	
		private bool moveToTarget = false;

		private Vector3 moveDirection = Vector3.zero;

		private bool moveStopped = false;

		private float moveSpeed = 0.0f;
	
		private ActorEventMover mover = null;

		private Combatant combatant = null;
	
		void Start()
		{
			this.controller = this.GetComponent<CharacterController>();
			this.combatant = ComponentHelper.GetCombatant(this.transform.root.gameObject);
		}
	
		void Update()
		{
			if(this.combatant == null || 
				((this.moveDead || !this.combatant.Dead) && 
				!this.combatant.Status.StopMovement))
			{
				if(this.useCharacterSpeed && this.combatant != null)
				{
					this.runSpeed = this.combatant.GetMoveSpeed(MoveSpeedType.Run);
				}
			
				// get click
				Vector3 point = Vector3.zero;
				if(this.mouseTouch.Interacted(ref point))
				{
					bool doMove = true;
					Ray ray = Camera.main.ScreenPointToRay(point);
					RaycastOutput hit;
					if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.raycastDistance, this.layerMask))
					{
						if(ORK.Game.Scene.WithinNoClickMove(hit.point))
						{
							this.ClearCursor();
							doMove = false;
						}
						else
						{
							BaseInteraction[] interactions = hit.transform.gameObject.GetComponentsInChildren<BaseInteraction>();
							for(int i=0; i<interactions.Length; i++)
							{
								if(interactions[i] != null && EventStartType.Interact.Equals(interactions[i].startType))
								{
									doMove = false;
									break;
								}
							}
						
							if(doMove)
							{
								if(this.useEventMover)
								{
									this.moveStopped = false;
									this.targetPosition = hit.point;
									if(this.cursorObject != null)
									{
										if(this.targetCursor == null)
										{
											this.targetCursor = (GameObject)GameObject.Instantiate(this.cursorObject);
										}
										this.targetCursor.transform.position = this.targetPosition + this.cursorOffset;
									}
									float distance = Vector3.Distance(this.targetPosition, this.transform.position);
									if(this.mover == null)
									{
										this.mover = ComponentHelper.Get<ActorEventMover>(this.gameObject);
									}
									this.mover.MoveToPosition(
										this.transform, true, true, true, true, this.targetPosition, 
										EaseType.Linear, distance / this.runSpeed);
								}
								else
								{
									this.combatant.Component.LastMoveTime = Time.time;
								}
							}
						}
					}
					
					if(doMove && !this.useEventMover)
					{
						this.moveStopped = false;
						this.targetPosition = hit.point;
						this.moveToTarget = true;
						if(this.cursorObject != null)
						{
							if(this.targetCursor == null)
							{
								this.targetCursor = (GameObject)GameObject.Instantiate(this.cursorObject);
							}
							this.targetCursor.transform.position = this.targetPosition + this.cursorOffset;
						}
					}
					else
					{
						this.moveToTarget = false;
					}
				}
				// move to target
				if(this.moveToTarget && this.controller != null && !this.useEventMover)
				{
					Vector3 v1 = this.transform.position;
					Vector3 v2 = this.targetPosition;
					if(this.ignoreYDistance)
						v1.y = v2.y;
					if(this.minimumMoveDistance >= Vector3.Distance(v1, v2) || 
						(this.secureMove && this.combatant.Component.LastMoveTime + this.secureTime < Time.time))
					{
						this.moveSpeed = 0;
						this.controller.Move(Vector3.zero);
						
						if(this.autoRemoveCursorTarget && this.targetCursor != null)
						{
							GameObject.Destroy(this.targetCursor);
						}
					}
					else
					{
						float t = ORK.Game.DeltaMovementTime;
						this.SetDirection(this.targetPosition);
						float curSmooth = speedSmoothing * t;
						this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.runSpeed, curSmooth);
						Vector3 movement = this.moveDirection * this.moveSpeed + new Vector3(0, this.gravity, 0);
						movement *= t;
						this.controller.Move(movement);
					}
				}
			}
			else
			{
				if(this.autoRemoveCursor && this.targetCursor != null)
				{
					GameObject.Destroy(this.targetCursor);
				}
				if(this.autoStopMove && !this.moveStopped)
				{
					if(this.mover != null)
						this.mover.StopMoving();
					this.moveSpeed = 0;
					this.moveStopped = true;
					this.moveToTarget = false;
					this.controller.Move(Vector3.zero);
				}
			}
		}
	
		private void SetDirection(Vector3 pos)
		{
			pos.y = this.transform.position.y;
			this.transform.LookAt(pos);
			this.moveDirection = this.transform.TransformDirection(Vector3.forward);
		}
	
		public void ClearCursor()
		{
			if(this.targetCursor != null)
			{
				GameObject.Destroy(this.targetCursor);
			}
			if(this.mover != null)
				this.mover.StopMoving();
			this.moveSpeed = 0;
			this.moveStopped = true;
			this.moveToTarget = false;
			if(this.controller != null)
				this.controller.Move(Vector3.zero);
		}
		
		void OnDisable()
		{
			if(this.autoRemoveCursor && this.targetCursor != null)
			{
				GameObject.Destroy(this.targetCursor);
			}
			this.mouseTouch.Clear();
		}
	}
}
