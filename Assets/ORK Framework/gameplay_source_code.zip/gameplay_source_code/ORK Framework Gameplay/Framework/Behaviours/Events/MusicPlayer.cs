
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Music Player")]
	public class MusicPlayer : BaseInteraction
	{
		[ORKEditorInfo(ORKDataType.MusicClip)]
		public int musicID = 0;
		
		public MusicPlayType playType = MusicPlayType.Play;
		
		public float fadeTime = 1;
		
		public EaseType interpolate = EaseType.Linear;
		
		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;
			
			if(MusicPlayType.Play.Equals(this.playType))
			{
				ORK.Music.Play(this.musicID);
			}
			else if(MusicPlayType.Stop.Equals(this.playType))
			{
				ORK.Music.Stop();
			}
			else if(MusicPlayType.FadeIn.Equals(this.playType))
			{
				ORK.Music.FadeIn(this.musicID, this.fadeTime, this.interpolate);
			}
			else if(MusicPlayType.FadeOut.Equals(this.playType))
			{
				ORK.Music.FadeOut(this.fadeTime, this.interpolate);
			}
			else if(MusicPlayType.FadeTo.Equals(this.playType))
			{
				ORK.Music.FadeTo(this.musicID, this.fadeTime, this.interpolate);
			}
			this.SetVariables();
		}
		
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "MusicPlayer.psd");
		}
		
		
		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get{ return InteractionType.MusicPlayer;}
		}
	}
}
