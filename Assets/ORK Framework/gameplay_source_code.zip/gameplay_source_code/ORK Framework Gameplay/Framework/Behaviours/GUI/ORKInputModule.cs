
using System.Collections.Generic;
using System.Reflection;
using ORKFramework;
using UnityEngine;
using UnityEngine.EventSystems;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
    public class ORKInputModule : PointerInputModule
	{
		private InputMode m_CurrentInputMode = InputMode.Mouse;

		private Vector2 m_LastMousePosition;

		private Vector2 m_MousePosition;
		
		
		// ORK input
		private InputKey accept;
		
		private InputKey cancel;

		protected ORKInputModule()
		{
			
		}
		
		protected override void Start()
		{
			base.Start();
			
			if(ORK.Initialized)
			{
				this.accept = ORK.InputKeys.Get(ORK.GameControls.acceptKey);
				this.cancel = ORK.InputKeys.Get(ORK.GameControls.cancelKey);
			}
		}

		public enum InputMode
		{
			Mouse,
			Buttons
		}

		public InputMode inputMode
		{
			get { return m_CurrentInputMode; }
		}

		[SerializeField]
		private bool m_AllowActivationOnMobileDevice;

		public bool allowActivationOnMobileDevice
		{
			get { return m_AllowActivationOnMobileDevice; }
			set { m_AllowActivationOnMobileDevice = value; }
		}

		public override void UpdateModule()
		{
			m_LastMousePosition = m_MousePosition;
			m_MousePosition = Input.mousePosition;
		}

		public override bool IsModuleSupported()
		{
			// Check for mouse presence instead of whether touch is supported,
			// as you can connect mouse to a tablet and in that case we'd want
			// to use StandaloneInputModule for non-touch input events.
			return m_AllowActivationOnMobileDevice || Input.mousePresent;
		}

		public override bool ShouldActivateModule()
		{
			if(!base.ShouldActivateModule())
				return false;

			bool shouldActivate = this.accept.GetButton();
			shouldActivate |= this.cancel.GetButton();
			shouldActivate |= (m_MousePosition - m_LastMousePosition).sqrMagnitude > 0.0f;
			shouldActivate |= Input.GetMouseButtonDown(0);
			return shouldActivate;
		}

		public override void ActivateModule()
		{
			base.ActivateModule();
			m_MousePosition = Input.mousePosition;
			m_LastMousePosition = Input.mousePosition;

			GameObject toSelect = eventSystem.currentSelectedGameObject;
			if(toSelect == null)
				toSelect = eventSystem.lastSelectedGameObject;
			if(toSelect == null)
				toSelect = eventSystem.firstSelectedGameObject;

			eventSystem.SetSelectedGameObject(null, GetBaseEventData());
			eventSystem.SetSelectedGameObject(toSelect, GetBaseEventData());
		}

		public override void DeactivateModule()
		{
			base.DeactivateModule();
			ClearSelection();
		}

		public override void Process()
		{
			SendUpdateEventToSelectedObject();

			ProcessMouseEvent();
		}

		private bool ResetSelection()
		{
			BaseEventData baseEventData = GetBaseEventData();
			// clear all selection
			// & figure out what the mouse is over
			PointerEventData lastMousePointer = GetLastPointerEventData(kMouseLeftId);
			GameObject hoveredObject = lastMousePointer == null ? null : lastMousePointer.pointerEnter;
			HandlePointerExitAndEnter(lastMousePointer, null);
			eventSystem.SetSelectedGameObject(null, baseEventData);

			// if we were hovering something...
			// use this as the basis for the selection
			bool resetSelection = false;
			GameObject toSelect = ExecuteEvents.GetEventHandler<ISelectHandler>(hoveredObject);
			if(toSelect == null)
			{
				// if there was no hover
				// then use the last selected
				toSelect = eventSystem.lastSelectedGameObject;
				resetSelection = true;
			}

			eventSystem.SetSelectedGameObject(toSelect, baseEventData);
			return resetSelection;
		}

		/// <summary>
		/// Process all mouse events.
		/// </summary>
		private void ProcessMouseEvent()
		{
			MouseState mouseData = GetMousePointerEventData();

			bool pressed = mouseData.AnyPressesThisFrame();
			bool released = mouseData.AnyReleasesThisFrame();

			MouseButtonEventData leftButtonData = mouseData.GetButtonState(PointerEventData.InputButton.Left).eventData;

			if(!UseMouse(pressed, released, leftButtonData.buttonData))
				return;

			// Process the first mouse button fully
			ProcessMousePress(leftButtonData);
			ProcessMove(leftButtonData.buttonData);
			ProcessDrag(leftButtonData.buttonData);

			// Now process right / middle clicks
			ProcessMousePress(mouseData.GetButtonState(PointerEventData.InputButton.Right).eventData);
			ProcessDrag(mouseData.GetButtonState(PointerEventData.InputButton.Right).eventData.buttonData);
			ProcessMousePress(mouseData.GetButtonState(PointerEventData.InputButton.Middle).eventData);
			ProcessDrag(mouseData.GetButtonState(PointerEventData.InputButton.Middle).eventData.buttonData);

			if(!Mathf.Approximately(leftButtonData.buttonData.scrollDelta.sqrMagnitude, 0.0f))
			{
				GameObject scrollHandler = ExecuteEvents.GetEventHandler<IScrollHandler>(leftButtonData.buttonData.pointerCurrentRaycast.gameObject);
				ExecuteEvents.ExecuteHierarchy(scrollHandler, leftButtonData.buttonData, ExecuteEvents.scrollHandler);
			}
		}

		private bool UseMouse(bool pressed, bool released, PointerEventData pointerData)
		{
			if(m_CurrentInputMode == InputMode.Mouse)
				return true;

			// On mouse action switch back to mouse control scheme
			if(pressed || released)
			{
				m_CurrentInputMode = InputMode.Mouse;
				eventSystem.SetSelectedGameObject(null);
			}

			return m_CurrentInputMode == InputMode.Mouse;
		}

		private bool SendUpdateEventToSelectedObject()
		{
			if(eventSystem.currentSelectedGameObject == null)
				return false;

			BaseEventData data = GetBaseEventData();
			ExecuteEvents.Execute(eventSystem.currentSelectedGameObject, data, ExecuteEvents.updateSelectedHandler);
			return data.used;
		}

		/// <summary>
		/// Process the current mouse press.
		/// </summary>
		private void ProcessMousePress(MouseButtonEventData data)
		{
			PointerEventData pointerEvent = data.buttonData;
			GameObject currentOverGo = pointerEvent.pointerCurrentRaycast.gameObject;

			// PointerDown notification
			if(data.PressedThisFrame())
			{
				pointerEvent.eligibleForClick = true;
				pointerEvent.delta = Vector2.zero;
				pointerEvent.dragging = false;
				pointerEvent.useDragThreshold = true;
				pointerEvent.pressPosition = pointerEvent.position;
				pointerEvent.pointerPressRaycast = pointerEvent.pointerCurrentRaycast;

				DeselectIfSelectionChanged(currentOverGo, pointerEvent);

				// search for the control that will receive the press
				// if we can't find a press handler set the press
				// handler to be what would receive a click.
				GameObject newPressed = ExecuteEvents.ExecuteHierarchy(currentOverGo, pointerEvent, ExecuteEvents.pointerDownHandler);

				// didnt find a press handler... search for a click handler
				if(newPressed == null)
					newPressed = ExecuteEvents.GetEventHandler<IPointerClickHandler>(currentOverGo);

				float time = Time.unscaledTime;

				if(newPressed == pointerEvent.lastPress)
				{
					float diffTime = time - pointerEvent.clickTime;
					if(diffTime < 0.3f)
						++pointerEvent.clickCount;
					else
						pointerEvent.clickCount = 1;

					pointerEvent.clickTime = time;
				}
				else
				{
					pointerEvent.clickCount = 1;
				}

				pointerEvent.pointerPress = newPressed;
				pointerEvent.rawPointerPress = currentOverGo;

				pointerEvent.clickTime = time;

				// Save the drag handler as well
				pointerEvent.pointerDrag = ExecuteEvents.GetEventHandler<IDragHandler>(currentOverGo);

				if(pointerEvent.pointerDrag != null)
					ExecuteEvents.Execute(pointerEvent.pointerDrag, pointerEvent, ExecuteEvents.initializePotentialDrag);
			}

			// PointerUp notification
			if(data.ReleasedThisFrame())
			{
				ExecuteEvents.Execute(pointerEvent.pointerPress, pointerEvent, ExecuteEvents.pointerUpHandler);

				// see if we mouse up on the same element that we clicked on...
				GameObject pointerUpHandler = ExecuteEvents.GetEventHandler<IPointerClickHandler>(currentOverGo);

				// PointerClick and Drop events
				if(pointerEvent.pointerPress == pointerUpHandler && pointerEvent.eligibleForClick)
				{
					ExecuteEvents.Execute(pointerEvent.pointerPress, pointerEvent, ExecuteEvents.pointerClickHandler);
				}
				else if(pointerEvent.pointerDrag != null)
				{
					ExecuteEvents.ExecuteHierarchy(currentOverGo, pointerEvent, ExecuteEvents.dropHandler);
				}

				pointerEvent.eligibleForClick = false;
				pointerEvent.pointerPress = null;
				pointerEvent.rawPointerPress = null;
				pointerEvent.dragging = false;

				if(pointerEvent.pointerDrag != null)
					ExecuteEvents.Execute(pointerEvent.pointerDrag, pointerEvent, ExecuteEvents.endDragHandler);

				pointerEvent.pointerDrag = null;

				// redo pointer enter / exit to refresh state
				// so that if we moused over somethign that ignored it before
				// due to having pressed on something else
				// it now gets it.
				if(currentOverGo != pointerEvent.pointerEnter)
				{
					HandlePointerExitAndEnter(pointerEvent, null);
					HandlePointerExitAndEnter(pointerEvent, currentOverGo);
				}
			}
		}
	}
}