
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetSelection : BaseData
	{
		// base settings
		[ORKEditorHelp("No Action Only", "The target can only be selected while the player " +
			"doesn't perform an action (i.e. when you can call the battle menu).", "")]
		public bool noActionOnly = false;
		
		[ORKEditorHelp("In Menus", "The target can be selected while displaying menus (e.g. the battle menu).", "")]
		public bool inMenus = false;
		
		[ORKEditorHelp("Auto Select", "The target is automatically selected.\n" +
			"If no target is set (e.g. the current target dies) the nearest one is selected.", "")]
		public bool autoSelect = false;
		
		
		// range
		[ORKEditorHelp("Only In Battle Range", "Only targets in battle range can be selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Range Settings")]
		public bool onlyInBattleRange = true;
		
		[ORKEditorLayout("onlyInBattleRange", false, endCheckGroup=true, autoInit=true)]
		public Range range;
		
		
		// target settings
		[ORKEditorHelp("Select Enemies", "Select if enemies are selected:\n" +
			"- Yes: Only enemies of the player can be selected.\n" +
			"- No: Only allies of the player can be selected.\n" +
			"- Ignore: All combatants can be selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Settings")]
		public Consider selectEnemies = Consider.Yes;
		
		[ORKEditorHelp("Select Dead", "Select if dead combatants are selected:\n" +
			"- Yes: Only dead combatants can be selected.\n" +
			"- No: Only alive combatants can be selected.\n" +
			"- Ignore: All combatants can be selected.", "")]
		public Consider selectDead = Consider.No;
		
		
		// system types
		[ORKEditorHelp("Field", "The target can be selected in the field (i.e. outside of battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Useable In")]
		public bool field = false;
		
		[ORKEditorHelp("Turn Based", "The target can be selected in 'Turn Based' battles.", "")]
		public bool turnBased = false;
		
		[ORKEditorHelp("Active Time", "The target can be selected in 'Active Time' battles.", "")]
		public bool activeTime = false;
		
		[ORKEditorHelp("Real Time", "The target can be selected in 'Real Time' battles.", "")]
		public bool realTime = false;
		
		[ORKEditorHelp("Phase", "The target can be selected in 'Phase' battles.", "")]
		public bool phase = false;
		
		
		// input keys
		[ORKEditorHelp("Next Target Key", "The key to select the next target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, labelText="Key Settings")]
		public int nextKey = 0;
		
		[ORKEditorHelp("Previous Target Key", "The key to select the previous target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int previousKey = 0;
		
		[ORKEditorHelp("Nearest Target Key", "The key to select the nearest target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int nearestKey = 0;
		
		[ORKEditorHelp("Remove Target Key", "The key to remove the target.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("autoSelect", false, endCheckGroup=true)]
		public int removeKey = 0;
		
		
		// mouse/touch
		[ORKEditorInfo(separator=true)]
		public MouseTouchControl clickControl = new MouseTouchControl();
		
		[ORKEditorHelp("Allow Remove", "A click/touch that doesn't target a combatant will remove the target.", "")]
		public bool allowClickRemove = false;
		
		
		// cursor
		[ORKEditorHelp("Use Cursor", "The target is marked with a cursor.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Cursor")]
		public bool useTargetCursor = false;
		
		[ORKEditorHelp("Prefab", "Select the prefab used as cursor object.", "")]
		[ORKEditorLayout("useTargetCursor", true)]
		public GameObject cursorPrefab;
		
		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings cursorMount = new MountSettings();
		
		
		// auto attack
		[ORKEditorHelp("Auto Attack Target", "Auto attacks (if enabled) are performed on this target.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Attack Settings")]
		public bool autoAttackTarget = false;
		
		[ORKEditorHelp("Player Only", "Only the player performs auto attacks.", "")]
		[ORKEditorLayout("autoAttackTarget", true, endCheckGroup=true)]
		public bool aaPlayerOnly = false;
		
		
		// limit ability use
		[ORKEditorHelp("Limit Ability Use", "Limit the use of abilities on this target to " +
			"selected abilities and ability types.\n" +
			"If disabled, all abilities will be used on the selected target (if possible).", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Use Settings")]
		public bool limitAbilityUse = false;
		
		[ORKEditorHelp("Ability Type", "Select the ability type that can be used on this target.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Ability Type", "Adds an ability type that can be used.", "",
			"Remove", "Removes the ability type.", "", isHorizontal=true)]
		[ORKEditorLayout("limitAbilityUse", true, autoInit=true)]
		public int[] useAbilityType;
		
		[ORKEditorHelp("Ability", "Select the ability that can be used on this target.", "")]
		[ORKEditorInfo(ORKDataType.Ability, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Ability", "Adds an ability that can be used.", "",
			"Remove", "Removes the ability.", "", isHorizontal=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public int[] useAbility;
		
		
		// limit item use
		[ORKEditorHelp("Limit Item Use", "Limit the use of items on this target to " +
			"selected items and item types.\n" +
			"If disabled, all items will be used on the selected target (if possible).", "")]
		[ORKEditorInfo(separator=true, labelText="Item Use Settings")]
		public bool limitItemUse = false;
		
		[ORKEditorHelp("Item Type", "Select the item type that can be used on this target.", "")]
		[ORKEditorInfo(ORKDataType.ItemType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Item Type", "Adds an item type that can be used.", "",
			"Remove", "Removes the item type.", "", isHorizontal=true)]
		[ORKEditorLayout("limitItemUse", true, autoInit=true)]
		public int[] useItemType;
		
		[ORKEditorHelp("Item", "Select the item that can be used on this target.", "")]
		[ORKEditorInfo(ORKDataType.Item, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Item", "Adds an item that can be used.", "",
			"Remove", "Removes the item.", "", isHorizontal=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public int[] useItem;
		
		
		
		
		// ingame
		private GameObject cursorInstance;
		
		public TargetSelection()
		{
			
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		private bool CheckSystem(Combatant user)
		{
			return (!user.InBattle && this.field && !ORK.Control.Blocked) || 
				(user.InBattle && ORK.Control.InBattle && ORK.Battle.IsBattleRunning() && 
					((this.turnBased && ORK.Battle.IsTurnBased()) || 
					(this.activeTime && ORK.Battle.IsActiveTime()) || 
					(this.realTime && ORK.Battle.IsRealTime()) || 
					(this.phase && ORK.Battle.IsPhase())));
		}
		
		private Consider GetConsiderBattle()
		{
			if(this.field && !this.turnBased && 
				!this.activeTime && !this.realTime && !this.phase)
			{
				return Consider.No;
			}
			else if(!this.field)
			{
				return Consider.Yes;
			}
			else
			{
				return Consider.Ignore;
			}
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public void Tick(Combatant user, bool inMenu, int index, bool isGroupTarget)
		{
			if(user != null && this.CheckSystem(user) && 
				(!this.noActionOnly || user.Actions.CanChoose))
			{
				// check selected target
				if(isGroupTarget)
				{
					if(user.Group.SelectedTargets[index] != null && 
						(user.Group.SelectedTargets[index].GameObject == null || 
						!TargetHelper.CheckDeath(user.Group.SelectedTargets[index], this.selectDead)))
					{
						user.Group.SelectedTargets[index] = null;
					}
				}
				else
				{
					if(user.SelectedTargets[index] != null && 
						(user.SelectedTargets[index].GameObject == null || 
						!TargetHelper.CheckDeath(user.SelectedTargets[index], this.selectDead)))
					{
						user.SelectedTargets[index] = null;
					}
				}
				
				// click
				if(!inMenu || this.inMenus)
				{
					Vector3 point = Vector3.zero;
					if(this.clickControl.Interacted(ref point))
					{
						bool found = false;
						Ray ray = Camera.main.ScreenPointToRay(point);
						RaycastOutput hit;
						
						if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit))
						{
							Combatant target = ComponentHelper.GetCombatant(hit.transform.root.gameObject);
							if(target != null && 
								(Consider.Ignore.Equals(this.selectEnemies) || 
								Consider.Yes.Equals(this.selectEnemies) == user.IsEnemy(target)))
							{
								if(isGroupTarget)
								{
									user.Group.SelectedTargets[index] = target;
								}
								else
								{
									user.SelectedTargets[index] = target;
								}
								found = true;
							}
						}
						
						if(!found && this.allowClickRemove)
						{
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = null;
							}
							else
							{
								user.SelectedTargets[index] = null;
							}
						}
					}
					// keys
					else
					{
						if(ORK.InputKeys.Get(this.nextKey).GetButton())
						{
							Combatant target = ORK.Game.Combatants.GetOffset(
								isGroupTarget ? user.Group.SelectedTargets[index] : user.SelectedTargets[index], 1, 
								user, true, this.onlyInBattleRange ? Range.Battle : this.range, 
								this.selectEnemies, this.selectDead, this.GetConsiderBattle());
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = target;
							}
							else
							{
								user.SelectedTargets[index] = target;
							}
						}
						else if(ORK.InputKeys.Get(this.previousKey).GetButton())
						{
							Combatant target = ORK.Game.Combatants.GetOffset(
								isGroupTarget ? user.Group.SelectedTargets[index] : user.SelectedTargets[index], -1, 
								user, true, this.onlyInBattleRange ? Range.Battle : this.range, 
								this.selectEnemies, this.selectDead, this.GetConsiderBattle());
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = target;
							}
							else
							{
								user.SelectedTargets[index] = target;
							}
						}
						else if(ORK.InputKeys.Get(this.nearestKey).GetButton())
						{
							Combatant target = ORK.Game.Combatants.GetNearest(user, true, 
								this.onlyInBattleRange ? Range.Battle : this.range, 
								this.selectEnemies, this.selectDead, this.GetConsiderBattle());
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = target;
							}
							else
							{
								user.SelectedTargets[index] = target;
							}
						}
						else if(!this.autoSelect && 
							ORK.InputKeys.Get(this.removeKey).GetButton())
						{
							if(isGroupTarget)
							{
								user.Group.SelectedTargets[index] = null;
							}
							else
							{
								user.SelectedTargets[index] = null;
							}
						}
					}
				}
				
				if(this.autoSelect && 
					!(isGroupTarget ? 
						user.Group.SelectedTargets.HasTarget(index) : 
						user.SelectedTargets.HasTarget(index)))
				{
					Combatant target = ORK.Game.Combatants.GetNearest(user, false, 
						this.onlyInBattleRange ? Range.Battle : this.range, 
						this.selectEnemies, this.selectDead, this.GetConsiderBattle());
					if(isGroupTarget)
					{
						user.Group.SelectedTargets[index] = target;
					}
					else
					{
						user.SelectedTargets[index] = target;
					}
				}
			}
		}
		
		public void AddCursor(Combatant target)
		{
			// destroy old cursor
			if(this.cursorInstance != null)
			{
				GameObject.Destroy(this.cursorInstance);
			}
			// add cursor
			if(this.useTargetCursor && this.cursorPrefab != null && 
				target != null && target.GameObject != null)
			{
				this.cursorInstance = (GameObject)GameObject.Instantiate(this.cursorPrefab);
				if(this.cursorInstance != null)
				{
					this.cursorMount.MountTo(target.GameObject.transform, this.cursorInstance.transform);
				}
			}
		}
		
		
		/*
		============================================================================
		Use functions
		============================================================================
		*/
		public bool UseAutoAttackTarget(Combatant user)
		{
			return this.CheckSystem(user) && this.autoAttackTarget && 
				(!this.aaPlayerOnly || user == ORK.Game.ActiveGroup.Leader);
		}
		
		public bool CanUseAbility(int abilityID, int typeID)
		{
			if(this.limitAbilityUse)
			{
				if(this.useAbilityType != null)
				{
					for(int i=0; i<this.useAbilityType.Length; i++)
					{
						if(this.useAbilityType[i] == typeID)
						{
							return true;
						}
					}
				}
				if(this.useAbility != null)
				{
					for(int i=0; i<this.useAbility.Length; i++)
					{
						if(this.useAbility[i] == abilityID)
						{
							return true;
						}
					}
				}
				return false;
			}
			return true;
		}
		
		public bool CanUseItem(int itemID, int typeID)
		{
			if(this.limitItemUse)
			{
				if(this.useItemType != null)
				{
					for(int i=0; i<this.useItemType.Length; i++)
					{
						if(this.useItemType[i] == typeID)
						{
							return true;
						}
					}
				}
				if(this.useItem != null)
				{
					for(int i=0; i<this.useItem.Length; i++)
					{
						if(this.useItem[i] == itemID)
						{
							return true;
						}
					}
				}
				return false;
			}
			return true;
		}
	}
}
