
using UnityEngine;

namespace ORKFramework
{
	public class CamPosRotation : BaseData
	{
		[ORKEditorHelp("Camera Position", "Select the camera position that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CameraPosition)]
		public int camPosID = 0;
		
		[ORKEditorHelp("Rotation Axis", "Set at the camera's rotation axis by setting it's X, Y and Z rotation.\n" +
			"E.g. X=0, Y=1, Z=0 will rotate along the Y-axis around the battle arena.\n" +
			"A value between 0 and 1 is recommended.", "")]
		public Vector3 axis = Vector3.zero;
		
		[ORKEditorHelp("Rotation Speed", "The speed at which the camera will rotate.\n" +
			"Set the speed to 0 if no camera rotation is wanted.\n" +
			"Use negative numbers to invert rotation.", "")]
		public float speed = 0;
		
		public CamPosRotation()
		{
			
		}
		
		public void Rotate(Transform camera, Vector3 position)
		{
			if(this.speed != 0)
			{
				camera.RotateAround(position, axis, speed * Time.deltaTime);
			}
		}
	}
}

