
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class BaseAction : IEventStarter
	{
		public Combatant user;

		public List<Combatant> target;

		public List<Combatant> outOfRange;

		public List<Combatant> counter = new List<Combatant>();

		public ActionResults results;


		// battle events
		protected List<BattleEvent> events;

		protected BattleEvent activeEvent;


		// other
		protected bool userConsumeDone = false;

		protected Consider targetDead = Consider.No;

		protected bool consumeTime = true;

		public bool autoAttackFlag = false;

		protected float timeUse = 0;

		public bool endPhaseFlag = false;


		// raycast target
		public TargetRaycast targetRaycast = new TargetRaycast();

		public bool rayTargetSet = false;

		public Vector3 rayPoint = Vector3.zero;

		public GameObject rayObject = null;


		// from battle event step
		public float damageMultiplier = 1;


		/*
		============================================================================
		Helper functions
		============================================================================
		*/
		public abstract bool IsType(ActionType t);

		public static AbilityAction CreateAbility(Combatant user, AbilityShortcut ability, int lvl)
		{
			if(ability != null)
			{
				if(lvl == -1)
				{
					ability.SetHighestUseLevel(user);
				}
				else if(lvl >= 0)
				{
					ability.SetUseLevel(lvl);
				}
				if(ability.CanUse(user, !AbilityActionType.CounterAttack.Equals(ability.Type)))
				{
					return new AbilityAction(user, ability);
				}
			}
			return null;
		}

		public virtual string GetName()
		{
			return "";
		}

		public float TimeUse
		{
			get { return this.timeUse; }
		}

		public bool ConsumeTime
		{
			get { return this.consumeTime; }
			set { this.consumeTime = value; }
		}

		public virtual void SetTarget(Combatant t)
		{

		}

		public virtual void SetTargets(List<Combatant> t)
		{

		}

		public virtual void AutoTarget(List<Combatant> preferredTargets, List<Combatant> allies, List<Combatant> enemies)
		{

		}

		public virtual bool SetGroupTarget()
		{
			return false;
		}

		public virtual bool SetIndividualTarget()
		{
			return false;
		}

		public virtual bool ConsumeDone
		{
			get { return this.userConsumeDone; }
			set { this.userConsumeDone = value; }
		}

		public virtual void ConsumeCosts()
		{
			this.userConsumeDone = true;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public Consider TargetDead
		{
			get { return this.targetDead; }
		}

		public virtual bool CanDamage(Combatant c)
		{
			return false;
		}


		/*
		============================================================================
		Ability cast functions
		============================================================================
		*/
		public virtual bool IsCastingAbility()
		{
			return false;
		}

		public virtual bool CancelAbilityCast()
		{
			return false;
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		public virtual void SetRandomTarget()
		{

		}

		public void UpdateTargets()
		{
			if(this.target == null)
			{
				this.target = new List<Combatant>();
			}

			List<Combatant> tmp = new List<Combatant>();
			for(int i = 0; i < this.target.Count; i++)
			{
				if(!this.InRange(this.target[i]))
				{
					tmp.Add(this.target[i]);
					this.target.RemoveAt(i--);
				}
			}

			if(this.outOfRange != null)
			{
				for(int i = 0; i < this.outOfRange.Count; i++)
				{
					if(this.InRange(this.outOfRange[i]))
					{
						this.target.Add(this.outOfRange[i]);
						this.outOfRange.RemoveAt(i--);
					}
				}
			}

			if(tmp.Count > 0)
			{
				if(this.outOfRange == null)
				{
					this.outOfRange = new List<Combatant>();
				}
				this.outOfRange.AddRange(tmp);
			}
		}

		public void PerformCheckTargets()
		{
			this.UpdateTargets();
			if(this.target != null && target.Count > 0)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.target[i] == null ||
						!TargetHelper.CheckDeath(this.target[i], this.targetDead))
					{
						this.target.RemoveAt(i--);
					}
				}
			}

			if(!this.rayTargetSet && (this.target == null || this.target.Count == 0))
			{
				this.SetRandomTarget();
			}
		}

		public virtual bool TargetNone()
		{
			return false;
		}

		public bool HasTargets()
		{
			return this.HasTargets(this.target);
		}

		public bool HasTargets(List<Combatant> list)
		{
			if(!this.TargetNone() &&
				list != null && list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(TargetHelper.CheckDeath(list[i], this.targetDead))
					{
						return true;
					}
				}
				return false;
			}
			return true;
		}

		public bool HasOutOfRangeTargets()
		{
			return this.outOfRange != null && this.outOfRange.Count > 0;
		}

		public Combatant GetNearestTarget()
		{
			Combatant nearest = null;
			if(this.target != null && this.target.Count > 0)
			{
				nearest = TargetHelper.GetNearestTarget(this.user, this.target, this.targetDead);
			}
			if(nearest == null && this.outOfRange != null && this.outOfRange.Count > 0)
			{
				nearest = TargetHelper.GetNearestTarget(this.user, this.outOfRange, this.targetDead);
			}
			return nearest;
		}

		public void CheckTargetAggressive()
		{
			if(this.target != null && this.target.Count > 0)
			{
				for(int i = 0; i < this.target.Count; i++)
				{
					if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
					{
						this.target[i].CheckAggressive(AggressionType.OnSelection, this.user);
					}
				}
			}
		}

		public void CheckBestiary(List<Combatant> list)
		{
			if(this.user.IsPlayerControlled())
			{
				for(int i = 0; i < list.Count; i++)
				{
					ORK.Game.Bestiary.Attack(list[i]);
				}
			}
			else if(this.user.IsEnemy(ORK.Game.ActiveGroup.Leader))
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IsPlayerControlled())
					{
						ORK.Game.Bestiary.AttackedBy(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public virtual bool InRange(Combatant t)
		{
			return true;
		}

		public bool InRange()
		{
			return this.TargetNone() || this.InRange(this.GetNearestTarget());
		}

		public bool InBattleRange()
		{
			if(this.user != null)
			{
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(Range.Battle.InRange(this.user, this.target[i]))
						{
							return true;
						}
					}
				}
				if(this.outOfRange != null && this.outOfRange.Count > 0)
				{
					for(int i = 0; i < this.outOfRange.Count; i++)
					{
						if(Range.Battle.InRange(this.user, this.outOfRange[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		protected void GetNextEvent()
		{
			if(this.activeEvent != null)
			{
				this.events[0].Variables = this.activeEvent.Variables;
			}
			this.activeEvent = this.events[0];
			this.events.RemoveAt(0);
		}

		public virtual bool CanUse()
		{
			return this.user != null;
		}

		// setup action stuff, show info, get events
		protected abstract void ActionStartSetup();

		public virtual void PerformAction()
		{
			// add control blocks
			ORK.Battle.DoAllActionsBlock(1);
			if(ORK.Game.PlayerHandler.IsPlayer(this.user))
			{
				ORK.Battle.DoPlayerActionsBlock(1);
			}

			ORK.Battle.Actions.AddActive(this);
			this.PerformCheckTargets();

			if(this.CanUse())
			{
				// check target aggression
				if(this.target != null && this.target.Count > 0)
				{
					for(int i = 0; i < this.target.Count; i++)
					{
						if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
						{
							this.target[i].CheckAggressive(AggressionType.OnAction, this.user);
							this.target[i].SetAttackedBy(this.user, true);
						}
					}
				}

				// base setup
				if(this.IsType(ActionType.Ability) ||
					this.IsType(ActionType.Attack) ||
					this.IsType(ActionType.Item))
				{
					user.LastTargets = this.target;
				}
				user.Actions.InAction = true;

				if(ORK.BattleSettings.camera.blockEventCams &&
					user.GameObject != null)
				{
					ORK.BattleSettings.camera.SetLatestUser(user.GameObject.transform);
				}
				this.events = new List<BattleEvent>();
				this.ActionStartSetup();

				// start battle event
				if(this.events.Count > 0)
				{
					this.GetNextEvent();
					this.activeEvent.StartEvent(this, this.user.GameObject);
				}
				else
				{
					if(this.target != null && this.target.Count > 0)
					{
						this.Calculate(this.target, 1, true);
					}
					this.EventEnded();
				}
			}
			else
			{
				this.EventEnded();
			}
		}

		public abstract void Calculate(List<Combatant> ts, float damageFactor, bool animate);

		protected abstract void ActionEndSetup();

		public virtual void EventEnded()
		{
			if(this.events != null && this.events.Count > 0)
			{
				this.GetNextEvent();
				this.activeEvent.StartEvent(this, this.user.GameObject);
			}
			else
			{
				// remove control blocks
				ORK.Battle.DoAllActionsBlock(-1);
				if(ORK.Game.PlayerHandler.IsPlayer(this.user))
				{
					ORK.Battle.DoPlayerActionsBlock(-1);
				}

				this.activeEvent = null;
				if(this.rayObject != null)
				{
					GameObject.Destroy(this.rayObject);
				}

				if(this.endPhaseFlag && ORK.Battle.IsPhase())
				{
					ORK.BattleSystem.phase.ClearCurrentFaction();
				}

				if(this.user != null)
				{
					this.ActionEndSetup();

					if(ORK.Battle.IsActiveTime() && !this.user.Dead &&
						!this.autoAttackFlag && this.consumeTime && this.timeUse > 0)
					{
						this.user.TimeBar -= this.timeUse;
						this.user.UsedTimeBar -= this.timeUse;

						if(this.user.TimeBar >= ORK.BattleSystem.activeTime.maxTimebar)
						{
							this.user.TimeBar = ORK.BattleSystem.activeTime.maxTimebar - 0.1f;
						}
					}
					else if(ORK.Battle.IsTurnBased() && !this.user.Dead &&
						!this.autoAttackFlag && this.consumeTime)
					{
						this.user.TurnValue = 0;
					}

					if(!ORK.Battle.IsRealTime())
					{
						for(int i = 0; i < this.counter.Count; i++)
						{
							if(this.counter[i] != null && !this.counter[i].Actions.InAction)
							{
								BaseAction counterAction = new AbilityAction(this.counter[i], this.counter[i].GetCounterAttack());
								counterAction.SetTarget(this.user);
								ORK.Battle.Actions.Unshift(counterAction);
							}
						}
					}

					this.user.Actions.InAction = false;

					bool setMoveAI = true;
					if(!this.IsType(ActionType.CounterAttack))
					{
						setMoveAI = !this.user.Actions.DequeueNextAction();
					}

					if(setMoveAI && !this.IsType(ActionType.Death) &&
						ORK.Battle.CanUseMoveAI(this.user))
					{
						this.user.MoveAI.ActionFinished(this.target);
					}
				}

				ORK.Battle.Actions.RemoveActive(this);
				ORK.Battle.CheckBattleEnd();

				if(!ORK.Battle.IsDynamicCombat() || !ORK.Battle.Actions.Has())
				{
					ORK.Battle.Actions.Finished(this);
				}
			}
		}

		public void StopAction()
		{
			if(this.activeEvent != null)
			{
				this.events = new List<BattleEvent>();
				this.activeEvent.StopEvent();
			}
		}

		public void Tick()
		{
			if(this.activeEvent != null)
			{
				this.activeEvent.Tick(ORK.Game.DeltaTime);
			}
		}

		public void DontDestroy()
		{

		}

		public GameObject GameObject
		{
			get { return this.user.GameObject; }
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public virtual void AutoActivateUserDamageDealers(bool activate)
		{
			if(this.user != null && this.user.GameObject != null)
			{
				DamageDealer[] damage = this.user.GameObject.GetComponentsInChildren<DamageDealer>();
				for(int i = 0; i < damage.Length; i++)
				{
					if((!this.user.InBattle && damage[i].autoField) ||
						(this.user.InBattle &&
							((ORK.Battle.IsTurnBased() && damage[i].autoTurnBased) ||
							(ORK.Battle.IsActiveTime() && damage[i].autoActiveTime) ||
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime) ||
							(ORK.Battle.IsRealTime() && damage[i].autoRealTime))))
					{
						damage[i].SetAction(activate ? this : null);
						damage[i].SetDamageActive(activate, new string[0]);
					}
				}
			}
		}

		public virtual bool CheckDamageDealer(DamageDealer dealer)
		{
			return false;
		}

		public virtual string[] GetActivationTags()
		{
			return new string[0];
		}

		public virtual DamageDealerActivation GetDamageDealerActivation()
		{
			return null;
		}
	}
}
