
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class SpawnerData : ISaveData
	{
		public int quantity = 0;
		
		public List<Group> groups = new List<Group>();
		
		public List<float> respawn = new List<float>();
		
		public SpawnerData()
		{
			
		}
		
		public bool CanSpawn(int maxQuantity)
		{
			return this.quantity + this.respawn.Count < maxQuantity;
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			data.Set("quantity", this.quantity);
			data.Set("respawn", this.respawn.ToArray());
			
			DataObject[] tmp = new DataObject[this.groups.Count];
			for(int i=0; i<this.groups.Count; i++)
			{
				tmp[i] = this.groups[i].SaveGame();
			}
			data.Set("groups", tmp);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.groups.Clear();
			this.respawn.Clear();
			if(data != null)
			{
				data.Get("quantity", ref this.quantity);
				
				DataObject[] tmp = data.GetFileArray("groups");
				if(tmp != null)
				{
					for(int i=0; i<tmp.Length; i++)
					{
						Group group = new Group(tmp[i]);
						group.LoadMembers(tmp[i], true);
						this.groups.Add(group);
						
						List<Combatant> list = group.GetBattle();
						for(int j=0; j<list.Count; j++)
						{
							list[j].RememberPosition = true;
						}
					}
				}
				
				float[] tmp2;
				data.Get("respawn", out tmp2);
				if(tmp2 != null)
				{
					this.respawn.AddRange(tmp2);
				}
			}
		}
		
		public void UpdateSpawner(CombatantSpawner spawner, int spawnerIndex, bool respawn)
		{
			for(int i=0; i<this.groups.Count; i++)
			{
				this.groups[i].BattleType = spawner.battleType;
				this.groups[i].SetSpawner(spawner, spawnerIndex, respawn);
				spawner.SetWaypoints(this.groups[i]);
			}
		}
	}
}
