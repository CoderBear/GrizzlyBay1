
using System;

namespace ORKFramework
{
	public class UseBlock
	{
		public UseBlockType type = UseBlockType.Ability;

		public UseBlockScope scope = UseBlockScope.Single;
		
		public int id = -1;

		private int typeID = -1;

		public float time = 0;
	
		public EndAfter endType = EndAfter.None;
		
		public UseBlock(UseBlockType type, UseBlockScope scope, int id, float time, EndAfter endType)
		{
			this.type = type;
			this.scope = scope;
			this.id = id;
			this.time = time;
			this.endType = endType;

			if(UseBlockScope.Type.Equals(this.scope))
			{
				if(UseBlockType.Ability.Equals(this.type))
				{
					this.typeID = ORK.Abilities.Get(this.id).abilityType;
				}
				else if(UseBlockType.Item.Equals(this.type))
				{
					this.typeID = ORK.Items.Get(this.id).itemType;
				}
			}
			else if(UseBlockScope.RootType.Equals(this.scope))
			{
				if(UseBlockType.Ability.Equals(this.type))
				{
					this.typeID = ORK.AbilityTypes.Get(ORK.Abilities.Get(this.id).abilityType).RootType;
				}
				else if(UseBlockType.Item.Equals(this.type))
				{
					this.typeID = ORK.ItemTypes.Get(ORK.Items.Get(this.id).itemType).RootType;
				}
			}
		}
		
		public bool IsAbility
		{
			get{ return UseBlockType.Ability.Equals(this.type);}
		}
		
		public bool IsItem
		{
			get{ return UseBlockType.Item.Equals(this.type);}
		}

		public bool IsBlocked(UseBlockType checkType, int checkID)
		{
			if(this.type.Equals(checkType))
			{
				if(UseBlockScope.Single.Equals(this.scope))
				{
					return this.id == checkID;
				}
				else if(UseBlockScope.Type.Equals(this.scope))
				{
					int checkTypeID = -1;
					if(UseBlockType.Ability.Equals(this.type))
					{
						checkTypeID = ORK.Abilities.Get(checkID).abilityType;
					}
					else if(UseBlockType.Item.Equals(this.type))
					{
						checkTypeID = ORK.Items.Get(checkID).itemType;
					}
					return this.typeID == checkTypeID;
				}
				else if(UseBlockScope.RootType.Equals(this.scope))
				{
					int checkTypeID = -1;
					if(UseBlockType.Ability.Equals(this.type))
					{
						checkTypeID = ORK.AbilityTypes.Get(ORK.Abilities.Get(checkID).abilityType).RootType;
					}
					else if(UseBlockType.Item.Equals(this.type))
					{
						checkTypeID = ORK.ItemTypes.Get(ORK.Items.Get(checkID).itemType).RootType;
					}
					return this.typeID == checkTypeID;
				}
				else if(UseBlockScope.All.Equals(this.scope))
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Time functions
		============================================================================
		*/
		public bool ReduceTurn()
		{
			if(EndAfter.Turn.Equals(this.endType))
			{
				this.time -= 1;
			}
			return this.time <= 0;
		}
		
		public bool ReduceTime(float t)
		{
			if(EndAfter.Time.Equals(this.endType))
			{
				this.time -= t;
			}
			return this.time <= 0;
		}
		
		public bool IsRemoveOnBattleEnd()
		{
			return EndAfter.Turn.Equals(this.endType);
		}
	}
}
