
using UnityEngine;
using ORKFramework.Animations;
using ORKFramework.Events;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework
{
	public class CombatantAnimations
	{
		private Combatant owner;
		
		public bool autoMoveAnimation = false;
		
		
		// components
		private Animation animation;
		
		private Animator animator;
		
		private Component custom;
		
		
		// animation settings
		private List<AnimationSetting> settingsList;
		
		
		// auto movement animation
		private MoveAnimationMode moveMode = MoveAnimationMode.None;
		
		private float fallTime = 0;
		
		private List<string> stopping = new List<string>();
		
		
		// mecanim auto move speed parameters
		private string mecanimHorizontalParameter = "";
		
		private string mecanimVerticalParameter = "";
		
		// mecanim auto rotation parameters
		public MecanimAutoRotationParameter mecanimXRotation;
		
		public MecanimAutoRotationParameter mecanimYRotation;
		
		public MecanimAutoRotationParameter mecanimZRotation;
		
		public CombatantAnimations(Combatant owner)
		{
			this.owner = owner;
			this.autoMoveAnimation = this.owner.Setting.autoMoveAnimation;
		}
		
		
		/*
		============================================================================
		Sound functions
		============================================================================
		*/
		/// <summary>
		/// Gets a combatant's audio clip assigned to a sound type.
		/// </summary>
		/// <returns>
		/// The audio clip.
		/// </returns>
		/// <param name='typeID'>
		/// The ID (index) of the sound type.
		/// </param>
		public AudioClip GetAudioClip(int typeID)
		{
			if(typeID >= 0 && typeID < ORK.SoundTypes.Count)
			{
				// check equipment
				for(int i=0; i<ORK.EquipmentParts.Count; i++)
				{
					if(this.owner.Equipment[i].Available && 
						this.owner.Equipment[i].Equipped && 
						this.owner.Equipment[i].Equipment != null)
					{
						EquipmentLevel lvl = this.owner.Equipment[i].Equipment.GetEquipmentLevel();
						for(int j=0; j<lvl.battleSound.Length; j++)
						{
							if(lvl.battleSound[j].typeID == typeID)
							{
								return lvl.battleSound[j].audioClip;
							}
						}
					}
				}
				// check combatant
				for(int i=0; i<this.owner.Setting.battleSound.Length; i++)
				{
					if(this.owner.Setting.battleSound[i].typeID == typeID)
					{
						return this.owner.Setting.battleSound[i].audioClip;
					}
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		/// <summary>
		/// Plays the specified animation type.
		/// </summary>
		/// <returns>
		/// An AnimInfo containing information on the used animation.
		/// </returns>
		/// <param name='typeID'>
		/// The ID (index) of the animation type.
		/// </param>
		public AnimInfo Play(int typeID)
		{
			if(typeID >= 0 && typeID < ORK.AnimationTypes.Count)
			{
				AnimInfo info;
				// legacy
				if(this.animation != null)
				{
					for(int i=0; i<this.settingsList.Count; i++)
					{
						if(this.settingsList[i].LegacyPlay(out info, this.animation, typeID, this.owner))
						{
							return info;
						}
					}
				}
				// mecanim
				else if(this.animator != null)
				{
					for(int i=0; i<this.settingsList.Count; i++)
					{
						if(this.settingsList[i].MecanimPlay(out info, this.animator, typeID))
						{
							return info;
						}
					}
				}
				// custom
				else if(this.custom != null)
				{
					for(int i=0; i<this.settingsList.Count; i++)
					{
						if(this.settingsList[i].CustomPlay(out info, this.custom, typeID))
						{
							return info;
						}
					}
				}
			}
			return AnimInfo.None;
		}
		
		/// <summary>
		/// Stops playing the specified animation type.
		/// </summary>
		/// <param name='typeID'>
		/// The ID (index) of the animation type.
		/// </param>
		public void Stop(int typeID)
		{
			if(typeID >= 0 && typeID < ORK.AnimationTypes.Count)
			{
				// legacy
				if(this.animation != null)
				{
					for(int i=0; i<this.settingsList.Count; i++)
					{
						this.settingsList[i].LegacyStop(this.animation, typeID, this.owner);
					}
				}
				// mecanim
				else if(this.animator != null)
				{
					for(int i=0; i<this.settingsList.Count; i++)
					{
						this.settingsList[i].MecanimStop(this.animator, typeID);
					}
				}
				// custom
				else if(this.custom != null)
				{
					for(int i=0; i<this.settingsList.Count; i++)
					{
						this.settingsList[i].CustomStop(this.custom, typeID);
					}
				}
			}
		}
		
		/// <summary>
		/// Stops all animation types.
		/// </summary>
		public void StopAll()
		{
			// legacy
			if(this.animation != null)
			{
				for(int i=0; i<this.settingsList.Count; i++)
				{
					this.settingsList[i].LegacyStop(this.animation, -1, this.owner);
				}
			}
			// mecanim
			else if(this.animator != null)
			{
				for(int i=0; i<this.settingsList.Count; i++)
				{
					this.settingsList[i].MecanimStop(this.animator, -1);
				}
			}
			// custom
			else if(this.custom != null)
			{
				for(int i=0; i<this.settingsList.Count; i++)
				{
					this.settingsList[i].CustomStop(this.custom, -1);
				}
			}
			this.moveMode = MoveAnimationMode.None;
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		/// <summary>
		/// Update function called each frame.
		/// </summary>
		public void Tick()
		{
			if(ORK.Game.Running && 
				(this.animation != null || this.animator != null || this.custom != null) && 
				(!this.owner.Dead || !this.owner.InBattle))
			{
				if(this.animator != null)
				{
					// auto move speed
					if(this.mecanimHorizontalParameter != "")
					{
						this.animator.SetFloat(this.mecanimHorizontalParameter, this.owner.Component.HorizontalSpeed);
					}
					if(this.mecanimVerticalParameter != "")
					{
						this.animator.SetFloat(this.mecanimVerticalParameter, this.owner.Component.VerticalSpeed);
					}
					// auto rotation
					if(this.owner.GameObject != null)
					{
						if(this.mecanimXRotation != null)
						{
							this.mecanimXRotation.SetParameter(this.animator, 
								this.owner.GameObject.transform.eulerAngles.x);
						}
						if(this.mecanimYRotation != null)
						{
							this.mecanimYRotation.SetParameter(this.animator, 
								this.owner.GameObject.transform.eulerAngles.y);
						}
						if(this.mecanimZRotation != null)
						{
							this.mecanimZRotation.SetParameter(this.animator, 
								this.owner.GameObject.transform.eulerAngles.z);
						}
					}
					
					for(int i=0; i<this.settingsList.Count; i++)
					{
						this.settingsList[i].CheckMecanimStates(this.animator);
					}
				}
				
				if(this.autoMoveAnimation)
				{
					if(!this.owner.Component.InAir || 
						(this.owner.Component.HorizontalSpeed == 0 && this.owner.Component.VerticalSpeed == 0))
					{
						if(MoveAnimationMode.Jump.Equals(this.moveMode) || 
							MoveAnimationMode.Fall.Equals(this.moveMode))
						{
							this.Stop(ORK.AnimationTypes.jumpID);
							this.Stop(ORK.AnimationTypes.fallID);
							
							if(this.fallTime >= this.owner.Setting.amaMinFallTime)
							{
								this.Play(ORK.AnimationTypes.landID);
								this.moveMode = MoveAnimationMode.Land;
							}
							
							this.Play(ORK.AnimationTypes.idleID);
						}
						
						if(this.owner.Component.HorizontalSpeed > 0.2f)
						{
							MoveAnimationMode nextMode = this.moveMode;
							if(this.owner.Component.HorizontalSpeed > 
								this.owner.Setting.amaMinSprintSpeed + this.owner.Setting.amaSprintSpeedThreshold)
							{
								nextMode = MoveAnimationMode.Sprint;
							}
							else if(this.owner.Component.HorizontalSpeed > 
								this.owner.Setting.amaMinRunSpeed + this.owner.Setting.amaRunSpeedThreshold && 
								(!MoveAnimationMode.Sprint.Equals(this.moveMode) || 
									this.owner.Component.HorizontalSpeed < 
										this.owner.Setting.amaMinSprintSpeed - this.owner.Setting.amaSprintSpeedThreshold))
							{
								nextMode = MoveAnimationMode.Run;
							}
							else if((!MoveAnimationMode.Sprint.Equals(this.moveMode) && 
								!MoveAnimationMode.Run.Equals(this.moveMode)) || 
								this.owner.Component.HorizontalSpeed < 
									this.owner.Setting.amaMinRunSpeed - this.owner.Setting.amaRunSpeedThreshold)
							{
								nextMode = MoveAnimationMode.Walk;
							}
							
							if(!this.moveMode.Equals(nextMode))
							{
								this.moveMode = nextMode;
								if(MoveAnimationMode.Sprint.Equals(this.moveMode) && 
									(this.Play(ORK.AnimationTypes.sprintID) != AnimInfo.None ||
									this.Play(ORK.AnimationTypes.runID) != AnimInfo.None || 
									this.Play(ORK.AnimationTypes.walkID) != AnimInfo.None))
								{
									
								}
								else if(MoveAnimationMode.Run.Equals(this.moveMode) && 
									(this.Play(ORK.AnimationTypes.runID) != AnimInfo.None || 
									this.Play(ORK.AnimationTypes.walkID) != AnimInfo.None))
								{
									
								}
								else if(MoveAnimationMode.Walk.Equals(this.moveMode) && 
									(this.Play(ORK.AnimationTypes.walkID) != AnimInfo.None || 
									this.Play(ORK.AnimationTypes.runID) != AnimInfo.None))
								{
									
								}
							}
						}
						else if(!MoveAnimationMode.ActionCastIdle.Equals(this.moveMode) && 
							this.owner.Actions.IsCastingAbility)
						{
							this.moveMode = MoveAnimationMode.ActionCastIdle;
							this.Stop(ORK.AnimationTypes.sprintID);
							this.Stop(ORK.AnimationTypes.runID);
							this.Stop(ORK.AnimationTypes.walkID);
							this.Play(ORK.AnimationTypes.actionCastIdleID);
						}
						else if(!MoveAnimationMode.ActionWaitIdle.Equals(this.moveMode) && 
							this.owner.Actions.Fired && !this.owner.Actions.InAction)
						{
							this.moveMode = MoveAnimationMode.ActionWaitIdle;
							this.Stop(ORK.AnimationTypes.sprintID);
							this.Stop(ORK.AnimationTypes.runID);
							this.Stop(ORK.AnimationTypes.walkID);
							this.Play(ORK.AnimationTypes.actionWaitIdleID);
						}
						else if(!MoveAnimationMode.ActionChooseIdle.Equals(this.moveMode) && 
							this.owner.Actions.IsChoosing)
						{
							this.moveMode = MoveAnimationMode.ActionChooseIdle;
							this.Stop(ORK.AnimationTypes.sprintID);
							this.Stop(ORK.AnimationTypes.runID);
							this.Stop(ORK.AnimationTypes.walkID);
							this.Play(ORK.AnimationTypes.actionChooseIdleID);
						}
						else if(!MoveAnimationMode.Idle.Equals(this.moveMode) && 
							(!this.owner.Actions.Fired || this.owner.Actions.InAction))
						{
							this.moveMode = MoveAnimationMode.Idle;
							this.Stop(ORK.AnimationTypes.sprintID);
							this.Stop(ORK.AnimationTypes.runID);
							this.Stop(ORK.AnimationTypes.walkID);
							this.Play(ORK.AnimationTypes.idleID);
						}
					}
					else
					{
						// jumping
						if(this.owner.Component.VerticalSpeed > 0 && 
							!MoveAnimationMode.Jump.Equals(this.moveMode))
						{
							this.fallTime = 0;
							this.Play(ORK.AnimationTypes.jumpID);
							this.moveMode = MoveAnimationMode.Jump;
						}
						// falling
						else if(MoveAnimationMode.Fall.Equals(this.moveMode))
						{
							this.fallTime += Time.deltaTime;
						}
						else if(this.owner.Component.VerticalSpeed < 0)
						{
							this.fallTime = 0;
							this.Play(ORK.AnimationTypes.fallID);
							this.Stop(ORK.AnimationTypes.jumpID);
							this.moveMode = MoveAnimationMode.Fall;
						}
					}
				}
			}
		}
		
		/// <summary>
		/// Gets the combatant's animation components.
		/// </summary>
		public void UpdateGameObject()
		{
			this.animation = null;
			this.animator = null;
			this.custom = null;
			
			if(this.owner.GameObject != null)
			{
				// legacy
				if(AnimationSystem.Legacy.Equals(this.owner.Setting.animationSystem))
				{
					this.animation = this.owner.GameObject.GetComponent<Animation>();
					if(this.animation == null)
					{
						this.animation = this.owner.GameObject.transform.root.GetComponentInChildren<Animation>();
					}
				}
				// mecanim
				else if(AnimationSystem.Mecanim.Equals(this.owner.Setting.animationSystem))
				{
					this.animator = this.owner.GameObject.GetComponent<Animator>();
					if(this.animator == null)
					{
						this.animator = this.owner.GameObject.transform.root.GetComponentInChildren<Animator>();
					}
				}
				// custom
				else if(AnimationSystem.Custom.Equals(this.owner.Setting.animationSystem) && 
					this.owner.Setting.animationCustomName != "")
				{
					this.custom = ComponentHelper.Get(this.owner.GameObject, this.owner.Setting.animationCustomName);
				}
			}
			this.UpdateAnimations();
		}
		
		/// <summary>
		/// Updates the animations.
		/// </summary>
		public void UpdateAnimations()
		{
			this.moveMode = MoveAnimationMode.None;
			this.mecanimHorizontalParameter = "";
			this.mecanimVerticalParameter = "";
			this.mecanimXRotation = null;
			this.mecanimYRotation = null;
			this.mecanimZRotation = null;
			
			this.settingsList = new List<AnimationSetting>();
			this.owner.Status.GetAnimationSettings(ref this.settingsList);
			this.owner.Equipment.GetAnimationSettings(ref this.settingsList);
			if(this.owner.InBattle && this.owner.Setting.useBattleAnims)
			{
				this.settingsList.Add(ORK.Animations.Get(this.owner.Setting.animationBattleID));
			}
			this.settingsList.Add(ORK.Animations.Get(this.owner.Setting.animationID));
			
			// legacy
			if(this.animation != null)
			{
				for(int i=0; i<this.settingsList.Count; i++)
				{
					this.settingsList[i].LegacyInit(this.owner, this.animation);
				}
			}
			// mecanim
			else if(this.animator != null)
			{
				for(int i=0; i<this.settingsList.Count; i++)
				{
					this.settingsList[i].MecanimInit(this.owner, this.animator, 
						ref this.mecanimHorizontalParameter, ref this.mecanimVerticalParameter, 
						ref this.mecanimXRotation, ref this.mecanimYRotation, ref this.mecanimZRotation);
				}
			}
			// mecanim
			else if(this.custom != null)
			{
				for(int i=0; i<this.settingsList.Count; i++)
				{
					this.settingsList[i].CustomInit(this.custom);
				}
			}
		}
		
		
		/*
		============================================================================
		Legacy fading functions
		============================================================================
		*/
		/// <summary>
		/// Fades a legacy animation.
		/// </summary>
		/// <param name='name'>
		/// The name of the animation.
		/// </param>
		/// <param name='fadeLength'>
		/// The fade length in seconds.
		/// </param>
		public void LegacyFade(string name, float fadeLength)
		{
			if(this.animation != null && !this.stopping.Contains(name))
			{
				this.stopping.Add(name);
				this.owner.Component.StartCoroutine(this.FadeOut(name, fadeLength));
			}
		}
		
		/// <summary>
		/// Removes a legacy animation currently marked as stopping.
		/// </summary>
		/// <param name='name'>
		/// The name of the animation.
		/// </param>
		public void LegacyRemoveStop(string name)
		{
			this.stopping.Remove(name);
		}
		
		private IEnumerator FadeOut(string name, float fadeLength)
		{
			this.animation.Blend(name, 0, fadeLength);
			yield return new WaitForSeconds(fadeLength);
			if(this.stopping.Contains(name))
			{
				this.animation.Stop(name);
			}
		}
	}
}
