
using UnityEngine;
using System.Collections.Generic;
using ORKFramework.Events;

namespace ORKFramework
{
	public class QuestChoice : BaseData, IChoice
	{
		[ORKEditorHelp("Quest", "Select the quest that will be used.\n" +
			"If the quest is already added to the player's quest list, " +
			"the data of the real quest is used (i.e. with current tasks and progress).\n" +
			"If the quest isn't added, the data of a dummy quest is used " +
			"(i.e. only initial tasks and without progress)", "")]
		[ORKEditorInfo(ORKDataType.Quest)]
		public int questID = 0;
		
		[ORKEditorHelp("GUI Box", "The GUI box used to display the quest choice dialogue.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// speaker
		[ORKEditorHelp("Use Speaker", "A selected event actor will be used as speaker.\n" +
			"You can display the name and a portrait of the speaker. The speaker's game object can be used to play an audio clip.", "")]
		[ORKEditorInfo(separator=true, labelText="Speaker Settings")]
		public bool useSpeaker = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used as speaker.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useSpeaker", true)]
		public int actorID = 0;
		
		
		// at actor position
		[ORKEditorHelp("Display At Actor", "The GUI box will be displayed at the position of the actor.\n" +
			"If disabled or the actor has no game object, the GUI box position is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool atActorPosition = false;
		
		[ORKEditorHelp("Path to Child", "The GUI box is positioned at a child object of the actor.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("atActorPosition", true)]
		public string posChildName = "";
		
		[ORKEditorHelp("Offset", "Offset added to the object's position.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector2 posOff = Vector2.zero;
		
		
		// name portrait
		[ORKEditorHelp("Show Name", "Show the name of the speaker in the name box of the GUI box.\n" +
			"This will override the quest layout's title settings.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool speakerName = false;
		
		[ORKEditorHelp("Show Portrait", "Show a portrait of the speaker.\n" +
			"This will override the quest's portrait.", "")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool speakerPortrait = false;
		
		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be displayed.\n" +
			"If the speaker doesn't have the selected type, no portrait will be displayed.", "")]
		[ORKEditorLayout("speakerPortrait", true)]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		public int portraitType = 0;
		
		// own portrait position
		[ORKEditorHelp("Own Position", "Overrides the default, GUI box and combatant/actor portrait position settings.", "")]
		public bool ownPortraitPosition = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("ownPortraitPosition", true, endCheckGroup=true, autoInit=true, endGroups=3)]
		public PortraitPosition portraitPosition;
		
		
		// settings
		[ORKEditorHelp("Allow Cancel", "The choice can be chanceled using the cancel button.", "")]
		[ORKEditorInfo(separator=true, labelText="Settings")]
		public bool allowCancel = false;
		
		[ORKEditorHelp("Use Choice", "Use a choice to accept or decline the quest.\n" +
			"If disabled, the 'Ok' and 'Cancel' buttons of the GUI box will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useChoice = false;
		
		[ORKEditorHelp("Add Cancel Choice", "A cancel choice is added to the teleport list.", "")]
		[ORKEditorLayout(new string[] {"useChoice", "allowCancel"}, 
			new System.Object[] {true, true}, setDefault=true, defaultValue=false)]
		public bool addCancel = false;
		
		[ORKEditorHelp("Cancel First Element", "The cancel choice is the first element in the list.", "")]
		[ORKEditorLayout("addCancel", true, endCheckGroup=true)]
		public bool cancelFirst = false;
		
		[ORKEditorLayout(new string[] {"allowCancel", "addCancel"}, 
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true, 
			setDefault=true, defaultValue=-1)]
		[ORKEditorInfo(hide=true)]
		public int cancelNext = -1;
		
		[ORKEditorInfo(separator=true, labelText="Default Selection")]
		public EventInteger defaultSelection = new EventInteger();
		
		// accept choice
		[ORKEditorInfo(labelText="Accept Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(autoInit=true, autoLangSize=true)]
		public LanguageInfo[] acceptButton;
		
		// layout
		[ORKEditorInfo("Content Layout", "Define the layout of the buttons.", "", 
			endFoldout=true, separatorForce=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// audio options
		[ORKEditorHelp("Play Audio", "Play an audio clip when displaying the dialogue.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Options")]
		public bool useAudio = false;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=3)]
		[ORKEditorLayout("useAudio", true)]
		public int clipID = 0;
		
		[ORKEditorHelp("Stop On Close", "Closing the dialogue will stop the playback.", "")]
		public bool stopAudio = true;
		
		[ORKEditorHelp("On Speaker", "The audio clip will be played on the object of the speaker.\n" +
			"If disabled, the audio clip will be played at the ORK object " +
			"(e.g. like the cursor/accept sounds - use non 3D audio clips if you don't hear anything).", "")]
		[ORKEditorLayout("useSpeaker", true)]
		public bool onSpeaker = false;
		
		[ORKEditorHelp("On Child", "A child object of the speaker is used for to play the audio clip (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[ORKEditorLayout("onSpeaker", true, endCheckGroup=true, endGroups=2)]
		public string childName = "";
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayAudioSettings audio;
		
		
		// quest layout
		[ORKEditorHelp("Own Layout", "This quest choice overrides the default quest layout (found in the game settings) and " +
			"the quest's own layout (if used).\n" +
			"The quest layout is used in menus and dialogues to display quest information (e.g. rewards, tasks).", "")]
		[ORKEditorInfo("Quest Layout", "A quest can override the default quest layout (found in the game settings) or " +
			"the quest's own layout (if used).", "")]
		public bool ownLayout = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("ownLayout", true, endCheckGroup=true, autoInit=true)]
		public QuestLayout layout;
		
		
		// ingame
		private GUIBox box;
		
		private int next = -1;
		
		private bool canceled = false;
		
		private ChoiceContent[] choices;
		
		
		// audio
		private GameObject playedAt;
		
		private GameObject shownAt;
		
		private bool checkActorObject = false;
		
		
		// event
		private BaseEvent baseEvent;
		
		public QuestChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.checkActorObject && this.shownAt == null)
			{
				List<GameObject> list = this.baseEvent.GetActorObject(this.actorID);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						this.box.BaseOffset = this.posOff;
						this.shownAt = TransformHelper.GetChildObject(this.posChildName, list[i]);
						this.box.AtObject = this.shownAt;
						break;
					}
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return this.allowCancel;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(BaseEvent baseEvent, int next)
		{
			// object setup
			this.playedAt = null;
			this.shownAt = null;
			this.checkActorObject = false;
			
			// event setup
			this.baseEvent = baseEvent;
			this.next = next;
			this.canceled = false;
			
			// show dialogue
			this.Show();
		}
		
		public void Show()
		{
			if(this.useAudio)
			{
				AudioClip clip = baseEvent.GetAudioClip(this.clipID);
				if(clip != null)
				{
					if(this.useSpeaker && this.onSpeaker)
					{
						List<GameObject> list = this.baseEvent.GetActorObject(this.actorID);
						if(list.Count > 0)
						{
							this.playedAt = list[0];
						}
					}
					else
					{
						this.playedAt = ORKCore.Instance.GameObject;
					}
					if(this.playedAt != null)
					{
						this.audio.PlayAudio(this.playedAt, clip);
					}
				}
			}
			
			this.CreateChoices();
			
			Quest quest = ORK.Game.Quests.HasQuest(this.questID) ? 
				ORK.Game.Quests.GetQuest(this.questID) : 
				new Quest(this.questID, false, true, false, false);
			
			string tmpTitle = "";
			string tmpText = "";
			
			if(this.ownLayout && this.layout != null)
			{
				this.layout.GetContent(ORK.Game.ActiveGroup.Leader, quest, ref tmpTitle, ref tmpText);
			}
			else if(quest.Setting.ownLayout && quest.Setting.layout != null)
			{
				quest.Setting.layout.GetContent(ORK.Game.ActiveGroup.Leader, quest, ref tmpTitle, ref tmpText);
			}
			else
			{
				ORK.GameSettings.questLayout.GetContent(ORK.Game.ActiveGroup.Leader, quest, ref tmpTitle, ref tmpText);
			}
			
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.Content = new DialogueContent(tmpText, 
				(this.useSpeaker && this.speakerName) ? this.baseEvent.GetActorName(this.actorID) : tmpTitle, 
				this.choices, this, this.defaultSelection.GetValue(this.baseEvent), 
				(this.useSpeaker && this.speakerPortrait) ? this.baseEvent.GetActorPortrait(this.actorID, this.portraitType) : 
					(quest.Setting.usePortrait ? quest.Setting.portrait : null));
			
			if(this.useSpeaker)
			{
				// portrait
				if(this.speakerPortrait && this.ownPortraitPosition)
				{
					((DialogueContent)this.box.Content).setPortraitPosition = this.portraitPosition;
				}
				// at actor position
				if(this.atActorPosition)
				{
					List<GameObject> list = this.baseEvent.GetActorObject(this.actorID);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							this.box.BaseOffset = this.posOff;
							this.shownAt = TransformHelper.GetChildObject(this.posChildName, list[i]);
							this.box.AtObject = this.shownAt;
							this.checkActorObject = true;
							break;
						}
					}
				}
			}
			this.box.InitIn();
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			this.box = null;
			BaseEvent tmpEvent = this.baseEvent;
			this.baseEvent = null;
			
			if(this.canceled)
			{
				tmpEvent.StepFinished(this.cancelNext);
			}
			else
			{
				tmpEvent.StepFinished(this.next);
			}
			
			// stop audio
			if(this.stopAudio && this.playedAt != null)
			{
				AudioSource audio = this.playedAt.GetComponent<AudioSource>();
				if(audio != null)
				{
					audio.Stop();
				}
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			this.choices = null;
			
			if(this.useChoice)
			{
				List<ChoiceContent> cc = new List<ChoiceContent>();
				
				cc.Add(this.contentLayout.GetChoiceContent(this.acceptButton));
				
				if(this.addCancel)
				{
					if(this.cancelFirst)
					{
						cc.Insert(0, this.contentLayout.GetChoiceContent(ORK.MenuSettings.cancelButton));
					}
					else
					{
						cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.cancelButton));
					}
				}
				
				this.choices = cc.ToArray();
			}
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.addCancel && 
				((this.cancelFirst && index == 0) || 
				(!this.cancelFirst && index == this.choices.Length - 1)))
			{
				this.canceled = true;
			}
			else
			{
				this.canceled = false;
			}
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			if(this.allowCancel)
			{
				origin.Audio.PlayCancel();
				this.canceled = true;
				this.box.InitOut();
			}
		}
	}
}
