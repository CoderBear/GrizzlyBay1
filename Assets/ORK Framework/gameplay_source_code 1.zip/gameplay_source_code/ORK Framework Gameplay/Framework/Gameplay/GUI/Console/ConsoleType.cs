
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleType : BaseLanguageData, IContentSimple
	{
		// text wrapping
		[ORKEditorHelp("Before Line Text", "Text added before each console line.\n" +
			"This text will be added before the 'Before Line Text' of the console settings.", "")]
		[ORKEditorInfo("Before Line Text", "Text added before each console line.\n" +
			"This text will be added before the 'Before Line Text' of the console settings.", "",
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] beforeLineText = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		[ORKEditorHelp("After Line Text", "Text added after each console line.\n" +
			"This text will be added after the 'After Line Text' of the console settings.", "")]
		[ORKEditorInfo("After Line Text", "Text added after each console line.\n" +
			"This text will be added after the 'After Line Text' of the console settings.", "",
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] afterLineText = ArrayHelper.CreateArray(ORK.Languages.Count, "");

		public ConsoleType()
		{
			
		}
		
		public ConsoleType(string name) : base(name)
		{
			
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get{ return this.realID;}
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}
		
		public string GetIconTextCode()
		{
			return TextCode.ConsoleTypeIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}
	}
}
