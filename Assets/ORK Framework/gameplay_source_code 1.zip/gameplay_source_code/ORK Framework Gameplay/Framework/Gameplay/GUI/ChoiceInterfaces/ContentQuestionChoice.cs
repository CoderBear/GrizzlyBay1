
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ContentQuestionChoice : BaseData, IChoice
	{
		[ORKEditorHelp("GUI Box", "The GUI box used to display the question.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = name, %d = description, %i = icon", 
			"%tn = type name, %td = type description, %ti = type icon", 
			"%l = level up costs, % = info (e.g. quantity, use costs)", 
			"%lvl = level (ability, equipment)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// message
		[ORKEditorHelp("Question Text", "The text displayed in the question.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Question Text", 
			label=new string[] {
				"%n = name, %d = description, %i = icon", 
				"%tn = type name, %td = type description, %ti = type icon", 
				"%l = level up costs, % = info (e.g. quantity, use costs)", 
				"%lvl = level (ability, equipment)"
		})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// question buttons
		[ORKEditorHelp("Use Choice", "Use a choice to accept or cancel the question, " +
			"the 'Yes' and 'No' options of the choice will be defined here.\n" +
			"If disabled, the 'Ok' and 'Cancel' buttons of the GUI box will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useChoice = false;
		
		// yes button
		[ORKEditorInfo(separator=true, labelText="Yes Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout("useChoice", true, autoInit=true, autoLangSize=true, 
			constTypes=new System.Type[] {typeof(string)}, 
			constValues=new System.Object[] {"Yes"})]
		public LanguageContent[] yesButton;
		
		// no button
		[ORKEditorInfo(separator=true, labelText="No Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, autoLangSize=true, 
			constTypes=new System.Type[] {typeof(string)}, 
			constValues=new System.Object[] {"No"})]
		public LanguageContent[] noButton;
		
		
		// ingame
		private GUIBox box;
		
		private int current = -1;
		
		private ChoiceContent[] choice;
		
		
		// content
		private IContentSimple content;
		
		private QuestionClosed parent;
		
		private Combatant combatant;
		
		
		// text
		private string tmpTitle = "";
		
		private string tmpText = "";
		
		public ContentQuestionChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return true;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		private void CreateTexts()
		{
			if(this.content is IShortcut)
			{
				IShortcut tmp = this.content as IShortcut;
				IContentSimple typeContent = tmp.GetTypeContent();
				
				string level = "";
				if(this.content is AbilityShortcut)
				{
					level = ((AbilityShortcut)this.content).Level.ToString();
				}
				else if(this.content is EquipShortcut)
				{
					level = ((EquipShortcut)this.content).Level.ToString();
				}
				else if(this.content is AbilityLeafShortcut)
				{
					level = ((AbilityLeafShortcut)this.content).Shortcut.Level.ToString();
				}
				
				this.CreateTexts(tmp.GetName(), tmp.GetDescription(), tmp.GetIconTextCode(), 
					typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
					tmp.GetLevelUpCostString(this.combatant), tmp.GetInfo(this.combatant), level);
			}
			else if(this.content is IContent)
			{
				IContent tmp = this.content as IContent;
				IContentSimple typeContent = tmp.GetTypeContent();
				
				this.CreateTexts(tmp.GetName(), tmp.GetDescription(), tmp.GetIconTextCode(), 
					typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
					"", tmp.GetInfo(this.combatant), "");
			}
			else
			{
				this.CreateTexts(this.content.GetName(), this.content.GetDescription(), this.content.GetIconTextCode(), 
					"", "", "", 
					"", "", "");
			}
		}
		
		private void CreateTexts(string name, string desc, string icon, 
			string typeName, string typeDesc, string typeIcon, 
			string lvlInfo, string info, string lvl)
		{
			// title
			if(this.useTitle)
			{
				if(this.title[ORK.Game.Language].Contains("%"))
				{
					this.tmpTitle = this.title[ORK.Game.Language].
						Replace("%n", name).
						Replace("%d", desc).
						Replace("%i", icon).
						Replace("%tn", typeName).
						Replace("%td", typeDesc).
						Replace("%ti", typeIcon).
						Replace("%lvl", lvl).
						Replace("%l", lvlInfo).
						Replace("%", info);
				}
				else
				{
					this.tmpTitle = this.title[ORK.Game.Language];
				}
			}
			else
			{
				this.tmpTitle = "";
			}
			// message
			if(this.message[ORK.Game.Language].Contains("%"))
			{
				this.tmpText = this.message[ORK.Game.Language].
					Replace("%n", name).
					Replace("%d", desc).
					Replace("%i", icon).
					Replace("%tn", typeName).
					Replace("%td", typeDesc).
					Replace("%ti", typeIcon).
					Replace("%lvl", lvl).
					Replace("%l", lvlInfo).
					Replace("%", info);
			}
			else
			{
				this.tmpText = this.message[ORK.Game.Language];
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(IContentSimple content, QuestionClosed parent, Combatant combatant)
		{
			this.content = content;
			this.parent = parent;
			this.combatant = combatant;
			this.Show();
		}
		
		public void Show()
		{
			if(this.useChoice)
			{
				this.choice = new ChoiceContent[2];
				this.choice[0] = this.yesButton[ORK.Game.Language].GetChoiceContent();
				this.choice[1] = this.noButton[ORK.Game.Language].GetChoiceContent();
			}
			else
			{
				this.choice = null;
			}
			
			this.CreateTexts();
			
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.inPause = true;
			this.box.Content = new DialogueContent(this.tmpText, this.tmpTitle, this.choice, this);
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			ORK.GUI.FocusBlocked = false;
			this.box = null;
			this.parent(this.current == 0);
			this.parent = null;
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = index;
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.current = -1;
			this.box.InitOut();
		}
	}
}
