
using UnityEngine;
using System.Collections.Generic;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Menu;

namespace ORKFramework
{
	public class PhaseCombatantChoice : BaseData, IChoice
	{
		[ORKEditorHelp("GUI Box", "The GUI box used to display the combatant coice.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Only Available", "Only combatants that can choose an action are displayed.\n" +
			"If disabled, all combatants are displayed, the buttons of those who can't be choose an action are inactive.", "")]
		public bool onlyAvailable = false;
		
		[ORKEditorHelp("Auto Select One", "If only one combatant is available, " +
			"automatically select the only combatant in the list.\n" +
			"If disabled, the combatant choice will be displayed for a single combatant as well.", "")]
		public bool autoSelectOne = false;
		
		
		// content
		[ORKEditorInfo("Content Settings", "Set the content of this combatant choice.\n" +
			"%n = faction name\n" +
			"%d = faction description", "", endFoldout=true, separatorForce=true)]
		public ChoiceMessage message = new ChoiceMessage();
		
		
		// end phase
		[ORKEditorHelp("Add End Phase", "An end phase option is displayed.", "")]
		[ORKEditorInfo(separator=true, labelText="End Phase Button")]
		public bool addEndPhase = false;
		
		[ORKEditorHelp("First Element", "The end phase option will be the first element in the list.\n" +
			"If disabled, the end phase option will be the last element in the list.", "")]
		[ORKEditorLayout("addEndPhase", true)]
		public bool endPhaseFirst = false;
				
		// exit button
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, autoLangSize=true, 
			constTypes=new System.Type[] {typeof(string)}, constValues=new System.Object[] {"End Phase"})]
		public LanguageInfo[] endPhaseButton;
		
		
		// own target choice layout
		[ORKEditorHelp("Own Layout", "Override the default combatant choice layout (Menu Settings).", "")]
		[ORKEditorInfo(separator=true, labelText="Combatant Choice Layout")]
		public bool ownCombatantChoice = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("ownCombatantChoice", true, endCheckGroup=true, autoInit=true)]
		public CombatantChoiceLayout combatantChoice;
		
		
		// ingame
		private GUIBox box;
		
		private int current = -1;
		
		private string tmpTitle = "";
		
		private int factionID = 0;
		
		
		// choice
		private List<Combatant> combatants;
		
		private ChoiceContent[] choice;
		
		private Combatant[] choiceCombatants;
		
		private List<Combatant> waitList;
		
		public PhaseCombatantChoice()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public void Clear()
		{
			this.choice = null;
			this.choiceCombatants = null;
			this.tmpTitle = "";
			this.combatants = null;
			this.waitList = null;
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		public string Message
		{
			get
			{
				return this.message.GetMessage(out this.tmpTitle, 
					ORK.Factions.GetName(this.factionID), 
					ORK.Factions.GetDescription(this.factionID));
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(List<Combatant> combatants)
		{
			if(this.box != null && this.box.IsClosing)
			{
				this.waitList = combatants;
			}
			else
			{
				this.Clear();
				if(this.autoSelectOne && combatants.Count == 1)
				{
					ORK.BattleSystem.phase.CombatantSelected(combatants[0]);
				}
				else
				{
					this.factionID = combatants[0].Group.FactionID;
					this.combatants = combatants;
					this.Show();
				}
			}
		}
		
		public void Show()
		{
			this.CreateChoices();
			
			if(this.box == null || this.box.IsClosing || this.box.IsClosed)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.InitIn();
			}
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent(this.Message, this.tmpTitle, this.choice, this, 0, null, 
					this.ownCombatantChoice ? 
						this.combatantChoice.GetStatusElements() : 
						ORK.MenuSettings.combatantChoice.GetStatusElements());
			}
			else
			{
				((DialogueContent)this.box.Content).Update(this.Message, this.tmpTitle, this.choice, 0, null, 
					this.ownCombatantChoice ? 
						this.combatantChoice.GetStatusElements() : 
						ORK.MenuSettings.combatantChoice.GetStatusElements());
			}
			this.SelectionChanged(0, this.box);
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Close()
		{
			if(this.box != null)
			{
				// turn off blinking
				if(this.choiceCombatants != null)
				{
					for(int i=0; i<this.choiceCombatants.Length; i++)
					{
						TargetHelper.Blink(this.choiceCombatants[i], false);
					}
				}
				
				this.current = -1;
				this.box.InitOut();
			}
		}
		
		public void Closed(GUIBox origin)
		{
			ORK.GUI.FocusBlocked = false;
			
			if(this.current >= 0 && this.current < this.choiceCombatants.Length)
			{
				ORK.BattleSystem.phase.CombatantSelected(this.choiceCombatants[this.current]);
			}
			this.combatants = null;
			this.choice = null;
			this.choiceCombatants = null;
			this.box = null;
			if(this.waitList != null)
			{
				this.Show(this.waitList);
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			this.choice = null;
			this.choiceCombatants = null;
			
			if(this.combatants != null && this.combatants.Count > 0)
			{
				List<ChoiceContent> cc = new List<ChoiceContent>();
				List<Combatant> com = new List<Combatant>();
				
				if(this.addEndPhase && this.endPhaseFirst)
				{
					cc.Add(new ChoiceContent(this.endPhaseButton[ORK.Game.Language].GetContent()));
					com.Add(null);
				}
				
				for(int i=0; i<this.combatants.Count; i++)
				{
					if(this.combatants[i] != null && 
						(!this.onlyAvailable || this.combatants[i].Actions.CanChoose))
					{
						ChoiceContent content = this.ownCombatantChoice ? 
							this.combatantChoice.GetChoiceContent(this.combatants[i]) : 
							ORK.MenuSettings.combatantChoice.GetChoiceContent(this.combatants[i]);
						if(!this.onlyAvailable)
						{
							content.Active = this.combatants[i].Actions.CanChoose;
						}
						cc.Add(content);
						com.Add(this.combatants[i]);
					}
				}
				
				if(this.addEndPhase && !this.endPhaseFirst)
				{
					cc.Add(new ChoiceContent(this.endPhaseButton[ORK.Game.Language].GetContent()));
					com.Add(null);
				}
				
				this.choice = cc.ToArray();
				this.choiceCombatants = com.ToArray();
			}
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.current >= 0 && this.current < this.choiceCombatants.Length && 
				this.choiceCombatants[this.current] != null)
			{
				TargetHelper.Blink(this.choiceCombatants[this.current], false);
			}
			this.current = index;
			if(this.current >= 0 && this.current < this.choiceCombatants.Length && 
				this.choiceCombatants[this.current] != null)
			{
				TargetHelper.Blink(this.choiceCombatants[this.current], false);
			}
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			if(this.current >= 0 && this.current < this.choiceCombatants.Length && 
				this.choiceCombatants[this.current] != null)
			{
				TargetHelper.Blink(this.choiceCombatants[this.current], false);
			}
			this.current = index;
			if(this.current >= 0 && this.current < this.choiceCombatants.Length && 
				this.choiceCombatants[this.current] != null)
			{
				TargetHelper.Blink(this.choiceCombatants[this.current], true);
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			
		}
	}
}
