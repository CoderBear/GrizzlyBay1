
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Menu;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiaryChoice : BaseData, IChoice
	{
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, nothing will be displayed and the event continues.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		
		// dialogue
		[ORKEditorHelp("GUI Box", "The GUI box used to display the dialogue.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true, labelText="Dialogue Settings")]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Show OK Button", "Show the 'Ok' button of the GUI box.\n" +
			"When using 'Accept Next Page', this will toggle to the next combatant page.", "")]
		public bool showOkButton = false;
		
		[ORKEditorHelp("Show Cancel Button", "Show the 'Cancel' button of the GUI box.\n" +
			"This will close the bestiary dialogue.", "")]
		public bool showCancelButton = false;
		
		[ORKEditorHelp("Show Portrait", "Display a portrait of the entry's combatant (if available).", "")]
		[ORKEditorInfo(separator=true)]
		public bool showPortrait = false;
		
		[ORKEditorHelp("Portrait Type", "Select the portrait type that will be used.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		[ORKEditorLayout("showPortrait", true, endCheckGroup=true)]
		public int portraitType = 0;
		
		[ORKEditorInfo(separator=true)]
		public BestiaryInformationDisplay entryInfo = new BestiaryInformationDisplay();
		
		
		
		// ingame
		private GUIBox box;
		
		private int current = 0;
		
		private int next = -1;
		
		private Combatant combatant;
		
		
		// event
		private BaseEvent baseEvent;
		
		public BestiaryChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.box == origin)
			{
				if(this.entryInfo.usePageKeys && this.entryInfo.page.Length > 1)
				{
					if(ORK.InputKeys.Get(this.entryInfo.nextPageKey).GetButton())
					{
						this.box.Audio.PlayAccept();
						this.ChangeEntryPage(1);
						return true;
					}
					else if(ORK.InputKeys.Get(this.entryInfo.prevPageKey).GetButton())
					{
						this.box.Audio.PlayAccept();
						this.ChangeEntryPage(-1);
						return true;
					}
				}
			}
			return false;
		}
		
		private void ChangeEntryPage(int change)
		{
			this.current += change;
			if(this.current < 0)
			{
				this.current = this.entryInfo.page.Length - 1;
			}
			else if(this.current >= this.entryInfo.page.Length)
			{
				this.current = 0;
			}
			this.Show();
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return this.showOkButton;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return this.showCancelButton;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(BaseEvent baseEvent, int next)
		{
			this.combatant = null;
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						this.combatant = list[i];
						break;
					}
				}
			}
			else
			{
				BestiaryEntry tmpEntry = this.entry.Get();
				if(tmpEntry != null)
				{
					this.combatant = tmpEntry.GetCombatant();
				}
			}
			
			if(this.combatant != null)
			{
				this.combatant.FindBestiaryEntry();
			}
			
			if(this.combatant != null && this.combatant.Bestiary != null)
			{
				this.baseEvent = baseEvent;
				this.next = next;
				this.current = 0;
				
				this.Show();
			}
			else
			{
				baseEvent.StepFinished(next);
			}
		}
		
		public void Show()
		{
			if(this.box == null || this.box.IsClosing || this.box.IsClosed)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.InitIn();
			}
			
			if(this.box.Content == null)
			{
				this.box.Content = this.entryInfo.GetPage(this, this.combatant, 
					this.showPortrait ? this.portraitType : -1, this.current, 
					this.showOkButton || this.showCancelButton);
			}
			else
			{
				this.entryInfo.UpdatePage(this.box.Content as BestiaryHUDContent, 
					this, this.combatant, 
					this.showPortrait ? this.portraitType : -1, this.current);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			BaseEvent tmpEvent = this.baseEvent;
			this.baseEvent = null;
			this.combatant = null;
			this.box = null;
			
			tmpEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.box == origin)
			{
				this.ChangeEntryPage(1);
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.box.InitOut();
		}
	}
}
