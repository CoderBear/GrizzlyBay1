
using UnityEngine;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework
{
	public class TargetNamesDisplay : BaseData
	{
		[ORKEditorHelp("Only First", "Display only the first combatant's name.\n" +
			"If disabled, all combatant names will be displayed.", "")]
		public bool onlyFirst = false;
		
		[ORKEditorHelp("First Combatant Text", "The text used to display only the first combatant.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = first combatant name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("onlyFirst", true)]
		public string[] firstTargetText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n and friends");
		
		
		// all names
		[ORKEditorHelp("Line Separation", "Each combatant name will be in it's own line.\n" +
			"If disabled, a separation text will be used.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool lineSeparation = false;
		
		[ORKEditorHelp("Separation", "The text used to separate combatant names.", "")]
		[ORKEditorLayout("lineSeparation", false, endCheckGroup=true, endGroups=2)]
		public string separation = ", ";
		
		public TargetNamesDisplay()
		{
			
		}
		
		public string GetNames(List<Combatant> combatants)
		{
			if(combatants == null || combatants.Count == 0)
			{
				return "";
			}
			else if(combatants.Count > 1)
			{
				if(this.onlyFirst)
				{
					return this.firstTargetText[ORK.Game.Language].Replace("%n", combatants[0].GetName());
				}
				else
				{
					StringBuilder builder = new StringBuilder();
					bool first = true;
					for(int i=0; i<combatants.Count; i++)
					{
						if(combatants[i] != null)
						{
							if(first)
							{
								builder.Append(combatants[i].GetName());
								first = false;
							}
							else
							{
								builder.Append(this.lineSeparation ? "\n" : this.separation).Append(combatants[i].GetName());
							}
						}
					}
					return builder.ToString();
				}
			}
			else if(combatants.Count > 0 && combatants[0] != null)
			{
				return combatants[0].GetName();
			}
			return "";
		}
	}
}
