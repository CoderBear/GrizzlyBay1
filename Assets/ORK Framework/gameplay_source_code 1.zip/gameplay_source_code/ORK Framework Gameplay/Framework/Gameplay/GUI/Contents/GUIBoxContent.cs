
using UnityEngine;
using UnityEngine.UI;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate void ButtonClick(int index);
	
	public abstract class GUIBoxContent
	{
		public GUIBox box;
		
		public IChoice controlInterface;
		
		
		// content
		public bool newContent = true;
		
		protected int selection = 0;
		
		
		// name
		protected string name = "";
		
		public bool newName = false;
		
		protected MultiContent nameContent;
		
		
		// ok/cancel buttons
		protected GUIBoxButtons okCancelSettings;
		
		protected ChoiceContent ok;
		
		protected ChoiceContent cancel;
		
		
		// scroll
		public Vector2 scroll = Vector2.zero;
		
		protected Rect contentBounds;
		
		protected Rect scrollRect;
		
		
		// choice icon
		protected bool iconFadingBack = false;
		
		protected Vector2 iconFadePos = Vector2.zero;
		
		protected float iconTime = 0;
		
		
		// new UI
		protected GameObject contentObject;
		
		protected GameObject scrollObject;
		
		protected GameObject scrollbarObject;
		
		protected GameObject nameObject;
		
		protected GameObject okObject;
		
		protected GameObject cancelObject;
		
		protected GameObject tabsContent;
		
		protected RectTransform tabsRect;
		
		protected GameObject portraitObject;
		
		protected RectTransform scrollRectTransform;
		
		protected RectTransform choiceIconObject;
		
		public List<RectTransform> labelObject;
		
		
		/*
		============================================================================
		Functions
		============================================================================
		*/
		public virtual void Clear()
		{
			if(this.contentObject != null)
			{
				GameObject.Destroy(this.contentObject);
			}
			if(this.scrollObject != null)
			{
				GameObject.Destroy(this.scrollObject);
			}
			if(this.scrollRectTransform != null)
			{
				GameObject.Destroy(this.scrollRectTransform);
			}
			if(this.scrollbarObject != null)
			{
				GameObject.Destroy(this.scrollbarObject);
			}
			if(this.nameObject != null)
			{
				GameObject.Destroy(this.nameObject);
			}
			if(this.okObject != null)
			{
				GameObject.Destroy(this.okObject);
			}
			if(this.cancelObject != null)
			{
				GameObject.Destroy(this.cancelObject);
			}
			if(this.tabsContent != null)
			{
				GameObject.Destroy(this.tabsContent);
			}
			if(this.portraitObject != null)
			{
				GameObject.Destroy(this.portraitObject);
			}
			if(this.choiceIconObject != null)
			{
				GameObject.Destroy(this.choiceIconObject.gameObject);
			}
		}
		
		public virtual void Tick()
		{
			if(this.scrollRectTransform != null)
			{
				this.scroll = this.scrollRectTransform.anchoredPosition;
			}
		}
		
		public abstract void Closed();
		
		public abstract void Init(GUIBox box);
		
		public abstract void ShowBefore();
		
		public abstract void ShowAfter();
		
		public abstract void ShowWindow();
		
		public virtual void SetTabs(ChoiceContent[] tabs)
		{
			
		}
		
		
		/*
		============================================================================
		New UI functions
		============================================================================
		*/
		public virtual void CreateNewUI()
		{
			
		}
		
		protected GameObject CreatePanel()
		{
			GameObject gameObject = null;
			// create content panel
			if(this.contentObject != null)
			{
				GameObject.Destroy(this.contentObject);
			}
			if(this.scrollbarObject != null)
			{
				GameObject.Destroy(this.scrollbarObject);
			}
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment) && 
				this.scrollRect.height > this.contentBounds.height)
			{
				GameObject tmp = TransformHelper.GetChildObject(this.box.Skins.contentBoxChild, this.box.gameObject);
				
				this.contentObject = UIHelper.CreateContentPanel(
					"Content Scroll", this.box.Skins.contentMask, 
					new Rect(this.contentBounds.x, this.contentBounds.y, 
						this.scrollRect.width, this.contentBounds.height), tmp);
				
				ScrollRect scroll = UIHelper.AddScrollRect(this.contentObject);
				this.scrollbarObject = UIHelper.AddScrollBar(scroll, 
					this.box.Settings.scrollPadding, this.box.Skins.scrollbarPrefab, tmp);
				
				gameObject = UIHelper.CreateBaseObject(
					"Content", 
					new Rect(0, 0, this.scrollRect.width, this.scrollRect.height), 
					this.contentObject);
				this.scrollRectTransform = gameObject.GetComponent<RectTransform>();
				UIHelper.SetScrollContent(scroll, this.scrollRectTransform);
				this.scrollRectTransform.anchoredPosition = this.scroll;
			}
			else
			{
				this.contentObject = UIHelper.CreateContentPanel(
					"Content", this.box.Skins.contentMask, this.contentBounds, 
					TransformHelper.GetChildObject(this.box.Skins.contentBoxChild, this.box.gameObject));
				gameObject = this.contentObject;
			}
			
			this.contentObject.transform.SetAsFirstSibling();
			this.box.uiComponent.ContentUpdated = true;
			
			return gameObject;
		}
		
		protected GameObject UpdatePanel()
		{
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				if(this.scrollObject == null)
				{
					GameObject tmp = TransformHelper.GetChildObject(this.box.Skins.contentBoxChild, this.box.gameObject);
					
					this.scrollObject = UIHelper.CreateContentPanel(
						"Content Scroll", this.box.Skins.contentMask, 
						new Rect(this.contentBounds.x, this.contentBounds.y, 
							this.scrollRect.width, this.contentBounds.height), tmp);
					
					ScrollRect scroll = UIHelper.AddScrollRect(this.scrollObject);
					this.scrollbarObject = UIHelper.AddScrollBar(scroll, 
						this.box.Settings.scrollPadding, this.box.Skins.scrollbarPrefab, tmp);

					if(this.contentObject == null)
					{
						this.contentObject = UIHelper.CreateBaseObject(
							"Content", 
							new Rect(0, 0, this.scrollRect.width, this.scrollRect.height), 
							this.scrollObject);
					}
					else
					{
						this.contentObject.transform.SetParent(this.scrollObject.transform, false);
						UIHelper.UpdateBounds(this.contentObject.GetComponent<RectTransform>(), 
							new Rect(0, 0, this.scrollRect.width, this.scrollRect.height));
					}
					this.scrollRectTransform = this.contentObject.GetComponent<RectTransform>();
					UIHelper.SetScrollContent(scroll, this.scrollRectTransform);
					this.scrollRectTransform.anchoredPosition = this.scroll;
				}
				else
				{
					UIHelper.UpdateBounds(this.scrollObject.GetComponent<RectTransform>(),
						new Rect(this.contentBounds.x, this.contentBounds.y,
							this.scrollRect.width, this.contentBounds.height));

					if(this.contentObject == null)
					{
						this.contentObject = UIHelper.CreateBaseObject(
							"Content",
							new Rect(0, 0, this.scrollRect.width, this.scrollRect.height),
							this.scrollObject);
					}
					else
					{
						this.contentObject.transform.SetParent(this.scrollObject.transform, false);
						UIHelper.UpdateBounds(this.contentObject.GetComponent<RectTransform>(),
							new Rect(0, 0, this.scrollRect.width, this.scrollRect.height));
					}

					this.scrollRectTransform = this.contentObject.GetComponent<RectTransform>();
					UIHelper.SetScrollContent(this.scrollObject.GetComponent<ScrollRect>(), this.scrollRectTransform);
					this.scrollRectTransform.anchoredPosition = this.scroll;
				}
			}
			else
			{
				if(this.contentObject == null)
				{
					this.contentObject = UIHelper.CreateContentPanel(
						"Content", this.box.Skins.contentMask, this.contentBounds, 
						TransformHelper.GetChildObject(this.box.Skins.contentBoxChild, this.box.gameObject));
				}
				else
				{
					if(this.scrollObject != null)
					{
						this.contentObject.transform.SetParent(TransformHelper.GetChildObject(
							this.box.Skins.contentBoxChild, this.box.gameObject).transform, false);
					}
					UIHelper.UpdateBounds(this.contentObject.GetComponent<RectTransform>(), this.contentBounds);
				}
				
				this.scrollRectTransform = null;
				if(this.scrollObject != null)
				{
					GameObject.Destroy(this.scrollObject);
				}
				if(this.scrollbarObject != null)
				{
					GameObject.Destroy(this.scrollbarObject);
				}
			}
			
			this.contentObject.transform.SetAsFirstSibling();
			this.box.uiComponent.ContentUpdated = true;
			
			return this.contentObject;
		}
		
		public void CreateTabsObjects(Rect tabsContentBounds, Rect tabsBounds, ChoiceContent[] tabs, 
			bool tabsScrollButtons, ChoiceContent leftArrow, ChoiceContent rightArrow, 
			int scrollOffset, List<RectTransform> list, ref int index, ButtonClick callback)
		{
			if(tabs != null && tabs.Length > 0)
			{
				if(this.tabsContent != null)
				{
					GameObject.Destroy(this.tabsContent);
				}
				this.tabsContent = UIHelper.CreateContentPanel("Tab Content", 
					this.box.Skins.tabMask, tabsContentBounds, this.box.gameObject);
				
				// tabs
				GameObject tabsObject = UIHelper.CreateBaseObject(
					"Tabs", tabsBounds, this.tabsContent);
				this.tabsRect = tabsObject.GetComponent<RectTransform>();
				for(int i=0; i<tabs.Length; i++)
				{
					tabs[i].CreateObject("Tab", this.box, i, 
						this.box.Skins.tabPrefab != null ? 
							this.box.Skins.tabPrefab : this.box.Skins.buttonPrefab, 
						this.box.Skins.tabPrefab != null ? 
							this.box.Skins.tabFadeMode : this.box.Skins.buttonFadeMode, 
						tabsObject, list, ref index, callback);
				}
				
				if(tabsScrollButtons)
				{
					// left arrow
					if(leftArrow != null)
					{
						leftArrow.Active = scrollOffset > 0;
						leftArrow.CreateObject("Tab Left", this.box, -1, 
							this.box.Skins.tabPrefab != null ? 
								this.box.Skins.tabPrefab : this.box.Skins.buttonPrefab, 
							this.box.Skins.tabPrefab != null ? 
								this.box.Skins.tabFadeMode : this.box.Skins.buttonFadeMode, 
							this.box.gameObject, list, ref index, callback);
					}
					
					// right arrow
					if(rightArrow != null)
					{
						rightArrow.Active = scrollOffset < tabs.Length - 1;
						rightArrow.CreateObject("Tab Right", this.box, -2, 
							this.box.Skins.tabPrefab != null ? 
								this.box.Skins.tabPrefab : this.box.Skins.buttonPrefab, 
							this.box.Skins.tabPrefab != null ? 
								this.box.Skins.tabFadeMode : this.box.Skins.buttonFadeMode, 
							this.box.gameObject, list, ref index, callback);
					}
				}
			}
		}
		
		public void CreatePortraitObject(Portrait portrait, PortraitPosition portraitPosition)
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				if(this.portraitObject != null)
				{
					GameObject.Destroy(this.portraitObject);
				}
				if(portrait != null && portrait.image != null && 
					portraitPosition != null)
				{
					Rect tmpBounds = this.box.bounds;
					tmpBounds.x += this.box.BaseOffset.x;
					tmpBounds.y += this.box.BaseOffset.y;
					GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, 
						-tmpBounds.height, this.box.Settings.boxAnchor);
					
					// behind box
					if(PortraitBoxPosition.Behind.Equals(portraitPosition.boxPosition))
					{
						this.portraitObject = portraitPosition.CreateObject(portrait, tmpBounds, 
							this.box.uiComponent.gameObject);
						this.portraitObject.transform.SetAsFirstSibling();
					}
					// within
					else if(PortraitBoxPosition.Within.Equals(portraitPosition.boxPosition))
					{
						this.portraitObject = UIHelper.CreateContentPanel("Portrait", null, 
							new Rect(0, 0, tmpBounds.width, tmpBounds.height), this.box.gameObject);
						portraitPosition.CreateObject(portrait, tmpBounds, 
							this.portraitObject);
						this.portraitObject.transform.SetAsFirstSibling();
					}
					// in front of box
					else if(PortraitBoxPosition.InFront.Equals(portraitPosition.boxPosition))
					{
						this.portraitObject = portraitPosition.CreateObject(portrait, tmpBounds, 
							this.box.uiComponent.gameObject);
						this.portraitObject.transform.SetAsLastSibling();
					}
				}
			}
		}
		
		protected GameObject CreateImage(DisplayImage image, bool relative, TextAnchor relativeTo, int siblingOffset)
		{
			Rect tmpBounds = this.box.bounds;
			tmpBounds.x += this.box.BaseOffset.x;
			tmpBounds.y += this.box.BaseOffset.y;
			GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, 
				-tmpBounds.height, this.box.Settings.boxAnchor);
			
			Vector2 tmp = relative ? 
				GUIHelper.GetRectAnchor(tmpBounds, relativeTo) : 
				Vector2.zero;
			tmp.x -= tmpBounds.x;
			tmp.y -= tmpBounds.y;
			
			ImageLabel imgLabel = image.Create(tmp.x, tmp.y);
			if(imgLabel != null)
			{
				List<RectTransform> list = new List<RectTransform>();
				int tmpIndex = 0;
				imgLabel.CreateObject(this.box.uiComponent.gameObject, list, ref tmpIndex);
				if(list.Count > 0)
				{
					list[0].transform.SetSiblingIndex(
						this.box.gameObject.transform.GetSiblingIndex() + siblingOffset);
					return list[0].gameObject;
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		OK/cancel functions
		============================================================================
		*/
		public virtual void OkPressed()
		{
			
		}
		
		public virtual void CancelPressed()
		{
			
		}
		
		public void OkCancelPressed(int index)
		{
			if(index == 0)
			{
				if(this.ok.Active)
				{
					this.OkPressed();
				}
				else
				{
					this.box.Audio.PlayFail();
				}
			}
			else if(index == 1)
			{
				if(this.cancel.Active)
				{
					this.CancelPressed();
				}
				else
				{
					this.box.Audio.PlayFail();
				}
			}
		}
		
		protected void CalculateButtons()
		{
			if(this.controlInterface != null && this.box != null)
			{
				this.okCancelSettings = this.box.Settings.ownButtons ? this.box.Settings.buttons : ORK.MenuSettings.okCancel;
				
				if(this.okCancelSettings.useOk && this.controlInterface.ShowOKButton(this.box))
				{
					this.ok = this.okCancelSettings.ok.GetButton(this.box.bounds);
				}
				if(this.okCancelSettings.useCancel && this.controlInterface.ShowCancelButton(this.box))
				{
					this.cancel = this.okCancelSettings.cancel.GetButton(this.box.bounds);
				}
				
				this.CreateNewUIButtons();
			}
		}
		
		protected void CreateNewUIButtons()
		{
			if(ORK.GUI.IsNewUI)
			{
				int tmpIndex = 0;
				// ok button
				if(this.okObject != null)
				{
					GameObject.Destroy(this.okObject);
				}
				if(this.ok != null)
				{
					this.ok.Active = this.controlInterface.IsOKButtonActive(this.box);
					
					this.okObject = this.ok.CreateObject("Ok", this.box, 0, 
						this.box.Skins.okPrefab != null ? 
							this.box.Skins.okPrefab : this.box.Skins.buttonPrefab, 
						this.box.Skins.okPrefab != null ? 
							this.box.Skins.okFadeMode : this.box.Skins.buttonFadeMode, 
						this.box.gameObject, null, ref tmpIndex, this.OkCancelPressed);
				}
				// cancel button
				if(this.cancelObject != null)
				{
					GameObject.Destroy(this.cancelObject);
				}
				if(this.cancel != null)
				{
					this.cancel.Active = this.controlInterface.IsCancelButtonActive(this.box);
					
					this.cancelObject = this.cancel.CreateObject("Cancel", this.box, 1, 
						this.box.Skins.cancelPrefab != null ? 
							this.box.Skins.cancelPrefab : this.box.Skins.buttonPrefab, 
						this.box.Skins.cancelPrefab != null ? 
							this.box.Skins.cancelFadeMode : this.box.Skins.buttonFadeMode, 
						this.box.gameObject, null, ref tmpIndex, this.OkCancelPressed);
				}
			}
		}
		
		public void ShowButtons()
		{
			if(this.controlInterface != null && this.box != null)
			{
				if(this.box.Skins.okSkin && 
					((this.ok != null && this.ok.isButton) || 
					(this.cancel != null && this.cancel.isButton)))
				{
					GUI.skin = this.box.Skins.okSkin;
				}
				
				// ok button
				if(this.ok != null)
				{
					this.ok.Active = this.controlInterface.IsOKButtonActive(this.box);
					
					if(!this.ok.Active && GUI.color.a > this.okCancelSettings.inactiveAlpha)
					{
						Color c = GUI.color;
						c.a = this.okCancelSettings.inactiveAlpha;
						GUI.color = c;
					}
					
					this.ok.buttonBounds.x += this.box.windowRect.x;
					this.ok.buttonBounds.y += this.box.windowRect.y;
					
					if(this.ok.isButton)
					{
						if(this.box.Button(this.ok.buttonBounds, 
								this.okCancelSettings.ok.settings.showButton, -1, false) && 
							(this.box.inPause || !ORK.Game.Paused))
						{
							if(this.ok.Active)
							{
								this.OkPressed();
							}
							else
							{
								this.box.Audio.PlayFail();
							}
						}
					}
					
					GUI.BeginGroup(this.ok.buttonBounds);
					
					GUIStyle textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					// content
					if(this.ok.contentLabel != null && this.ok.contentLabel.label.Count > 0)
					{
						for(int j=0; j<this.ok.contentLabel.label.Count; j++)
						{
							this.ok.contentLabel.label[j].Show(textStyle);
						}
					}
					GUI.EndGroup();
					
					this.ok.buttonBounds.x -= this.box.windowRect.x;
					this.ok.buttonBounds.y -= this.box.windowRect.y;
					
					// reset alpha
					GUI.color = this.box.color;
				}
				// cancel button
				if(this.cancel != null)
				{
					this.cancel.Active = this.controlInterface.IsCancelButtonActive(this.box);
					
					if(!this.cancel.Active && GUI.color.a > this.okCancelSettings.inactiveAlpha)
					{
						Color c = GUI.color;
						c.a = this.okCancelSettings.inactiveAlpha;
						GUI.color = c;
					}
					
					this.cancel.buttonBounds.x += this.box.windowRect.x;
					this.cancel.buttonBounds.y += this.box.windowRect.y;
					
					if(this.cancel.isButton)
					{
						if(this.box.Button(this.cancel.buttonBounds, 
								this.okCancelSettings.cancel.settings.showButton, -1, false) && 
							(this.box.inPause || !ORK.Game.Paused))
						{
							if(this.cancel.Active)
							{
								this.CancelPressed();
							}
							else
							{
								this.box.Audio.PlayFail();
							}
						}
					}
					
					GUI.BeginGroup(this.cancel.buttonBounds);
					
					GUIStyle textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					// content
					if(this.cancel.contentLabel != null && this.cancel.contentLabel.label.Count > 0)
					{
						for(int j=0; j<this.cancel.contentLabel.label.Count; j++)
						{
							this.cancel.contentLabel.label[j].Show(textStyle);
						}
					}
					GUI.EndGroup();
					
					this.cancel.buttonBounds.x -= this.box.windowRect.x;
					this.cancel.buttonBounds.y -= this.box.windowRect.y;
					
					// reset alpha
					GUI.color = this.box.color;
				}
				
				if(this.box.Skins.skin)
				{
					GUI.skin = this.box.Skins.skin;
				}
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		protected void DrawChoiceIcon(Rect choiceRect)
		{
			if(this.box != null)
			{
				this.box.ChoiceIcon.Show(choiceRect, this.iconFadePos);
			}
		}
		
		public virtual int Selection
		{
			get{ return this.selection;}
			set{ this.selection = value;}
		}
		
		public virtual void ShowSelectionIcon()
		{
			
		}
		
		
		/*
		============================================================================
		Focus functions
		============================================================================
		*/
		public virtual void FocusGained()
		{
			if(this.controlInterface != null && this.box != null)
			{
				this.controlInterface.FocusGained(this.box);
			}
		}
		
		public virtual void FocusLost()
		{
			if(this.controlInterface != null && this.box != null)
			{
				this.controlInterface.FocusLost(this.box);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public void SetName(string newName)
		{
			if(this.name != newName)
			{
				this.name = newName;
				this.newName = true;
			}
		}
		
		public void ShowName()
		{
			if(this.box != null && this.name != "")
			{
				if(this.box.Skins.nameSkin)
				{
					GUI.skin = this.box.Skins.nameSkin;
				}
				
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				
				// calculate new name
				if(this.newName)
				{
					this.CalculateName();
				}
				
				GUIHelper.GetRectAnchor(ref this.box.nameBounds, -this.box.nameBounds.width, -this.box.nameBounds.height, this.box.Settings.nameAnchor);
				
				if(this.box.Settings.showNameBox)
				{
					GUI.Box(this.box.nameBounds, "");
				}
				
				GUI.BeginGroup(this.box.nameBounds);
				
				for(int i=0; i<this.nameContent.label.Count; i++)
				{
					this.nameContent.label[i].Show(textStyle);
				}
				
				GUI.EndGroup();
				
				
				if(this.box.Skins.skin)
				{
					GUI.skin = this.box.Skins.skin;
				}
			}
		}
		
		public void CalculateName()
		{
			if(this.box != null && this.name != "")
			{
				Vector2 size = Vector2.zero;

				if(ORK.GUI.IsNewUI)
				{
					size = UIHelper.CalculateTextSize(this.name, this.box.Settings.nameTextFormat);
				}
				else
				{
					GUIStyle textStyle = new GUIStyle("label");
					textStyle.wordWrap = false;

					// set text style
					if(this.box.Settings.nameTextFormat.font != null)
					{
						textStyle.font = this.box.Settings.nameTextFormat.font;
					}
					else if(ORK.GUI.IsNewUI)
					{
						textStyle.font = ORK.MenuSettings.newUI.defaultFont;
					}
					textStyle.fontSize = this.box.Settings.nameTextFormat.fontSize;
					textStyle.fontStyle = this.box.Settings.nameTextFormat.fontStyle;

					size = textStyle.CalcSize(new GUIContent(this.name));
				}

				this.box.nameBounds = this.box.Settings.nameBounds;
				if(this.box.Settings.nameRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.bounds, this.box.Settings.nameRelativeTo);
					this.box.nameBounds.x += tmp.x;
					this.box.nameBounds.y += tmp.y;
				}

				Rect bounds = new Rect(this.box.Settings.namePadding.x, this.box.Settings.namePadding.y,
				this.box.Settings.nameAdjWidth ? size.x : this.box.Settings.nameBounds.width,
				this.box.Settings.nameAdjHeight ? size.y : this.box.Settings.nameBounds.height);

				this.box.nameOffset.x = this.box.nameBounds.x - this.box.bounds.x;
				this.box.nameOffset.y = this.box.nameBounds.y - this.box.bounds.y;

				this.nameContent = new MultiContent(this.name, null, null, bounds,
					this.box.Settings.nameLineSpacing, this.box.Settings.alignmentName, this.box.Settings.vAlignmentName,
					BoxHeightAdjustment.Auto, false, this.box.Settings.nameTextFormat);

				if(!this.box.forceSize)
				{
					if(this.box.Settings.nameAdjWidth)
					{
						this.box.nameBounds.width = bounds.width + this.box.Settings.namePadding.x + this.box.Settings.namePadding.z;
					}
					if(this.box.Settings.nameAdjHeight)
					{
						this.box.nameBounds.height = bounds.height + this.box.Settings.namePadding.y + this.box.Settings.namePadding.w;
					}
				}

				this.newName = false;

				// new UI
				if(ORK.GUI.IsNewUI)
				{
					Rect tmpBounds = new Rect(this.box.nameOffset.x, this.box.nameOffset.y,
					this.box.nameBounds.width, this.box.nameBounds.height);
					GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.box.Settings.nameAnchor);

					if(this.nameObject != null)
					{
						GameObject.Destroy(this.nameObject);
					}
					if(this.box.Settings.showNameBox &&
						this.box.Skins.nameBoxPrefab != null)
					{
						this.nameObject = UIHelper.InstantiateObject(
							this.box.Skins.nameBoxPrefab, "Name Box", tmpBounds, this.box.gameObject);
					}
					else
					{
						this.nameObject = UIHelper.CreateBaseObject(
							"Name Box", tmpBounds, this.box.gameObject);
					}

					GameObject tmp = TransformHelper.GetChildObject(this.box.Skins.nameBoxChild, this.nameObject);
					int tmpIndex = 0;
					for(int i = 0; i < this.nameContent.label.Count; i++)
					{
						this.nameContent.label[i].CreateObject(tmp, null, ref tmpIndex);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public virtual bool InBox(Vector2 position)
		{
			if(ORK.GUI.IsNewUI)
			{
				if(ORK.GUI.IsMouseOverObject(this.box.gameObject))
				{
					return true;
				}
				else
				{
					return (this.ok != null && this.ok.InButton(position, 0)) || 
						(this.cancel != null && this.cancel.InButton(position, 0));
				}
			}
			else
			{
				if(GUIHelper.InGUIRect(position, this.box.windowRect))
				{
					return true;
				}
				else
				{
					position.x -= this.box.windowRect.x;
					position.y -= this.box.windowRect.y;
					return (this.ok != null && this.ok.InButton(position, 0)) || 
						(this.cancel != null && this.cancel.InButton(position, 0));
				}
			}
		}
		
		public bool CheckDragWindow(Vector2 position)
		{
			if(this.box != null && this.box.Settings.dragable && 
				this.box.Focused && this.InBox(position))
			{
				position.x -= this.box.windowRect.x;
				position.y -= this.box.windowRect.y;
				return GUIHelper.InGUIRect(position, this.box.Settings.dragBounds);
			}
			return false;
		}
		
		public virtual ChoiceContent GetDragOnPosition(Vector2 position)
		{
			return null;
		}
		
		public virtual bool CheckDrop(DragInfo drag, Vector2 position)
		{
			return this.box != null && this.controlInterface != null && 
				this.InBox(position);
		}
		
		public virtual IContent GetTooltip(Vector2 position)
		{
			return null;
		}
		
		public virtual void MouseOverSelection(Vector2 position)
		{
			
		}
		
		public virtual bool CheckClick(Vector2 position)
		{
			return this.box != null && 
				this.InBox(position);
		}
	}
}
