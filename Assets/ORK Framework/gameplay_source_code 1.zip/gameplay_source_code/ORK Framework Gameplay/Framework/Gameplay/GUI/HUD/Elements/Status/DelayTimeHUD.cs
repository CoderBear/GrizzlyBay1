
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DelayTimeHUD : BaseData
	{
		[ORKEditorHelp("Reverse Value", "The delay time will be displayed reversed, " +
			"i.e. the time will count up instead of down.", "")]
		public bool reverseValue = false;
		
		// value bar
		[ORKEditorHelp("Use Bar", "The delay time will be displayed as a bar instead of text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useBar = false;
		
		[ORKEditorHelp("Bar Bounds", "The position and size of the bar.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		[ORKEditorLayout("useBar", true)]
		public Rect barBounds = new Rect(0, 0, 100, 10);
		
		[ORKEditorLayout(autoInit=true)]
		public ValueBar bar;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {"% = current value, %m = maximum value"})]
		[ORKEditorLayout(elseCheckGroup=true, autoInit=true)]
		public StatusTextHUD text;
		
		[ORKEditorHelp("Time Format", "Define the format that will be used for the time.\n" +
			"E.g.: 0.0 will display one decimal.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public string timeFormat = "0.0";
		
		public DelayTimeHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			float value = this.reverseValue ? 
				combatant.DelayTimeMax - combatant.DelayTime : 
				combatant.DelayTime;
			
			if(this.useBar)
			{
				this.bar.Create(ref label, 
					new Rect(this.barBounds.x + bounds.x, this.barBounds.y + bounds.y, this.barBounds.width, this.barBounds.height), 
					value, value, 0, combatant.DelayTimeMax);
			}
			else
			{
				label.AddRange(new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%m", combatant.DelayTimeMax.ToString(this.timeFormat)).
						Replace("%", value.ToString(this.timeFormat))), 
					null, null, bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
					this.text.textFormat).label);
			}
		}
	}
}
