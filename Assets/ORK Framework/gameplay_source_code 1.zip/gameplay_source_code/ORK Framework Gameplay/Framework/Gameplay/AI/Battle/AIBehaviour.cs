
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIBehaviour : BaseData
	{
		[ORKEditorHelp("Battle AI", "Select the battle AI that will be used.\n" +
			"If no action is found in this battle AI, the next battle AI will be used.\n" +
			"If no battle AI finds an action, the base attack will be used.", "")]
		[ORKEditorInfo(ORKDataType.BattleAI)]
		public int battleAI = 0;
		
		public AIBehaviour()
		{
			
		}
		
		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public BaseAction GetAction(Combatant user, List<Combatant> allies, List<Combatant> enemies)
		{
			if(this.battleAI >= 0 && this.battleAI < ORK.BattleAIs.Count)
			{
				return ORK.BattleAIs.Get(this.battleAI).GetAction(user, allies, enemies);
			}
			return null;
		}
	}
}
