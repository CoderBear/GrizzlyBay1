
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetRaycast : BaseData
	{
		// raycast settings
		[ORKEditorHelp("Use Target Raycast", "Use a raycast to set the target (position) for an ability or item.\n" +
			"Use this setting for 'area of effect'-spells, etc.", "")]
		public bool active = false;

		[ORKEditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		[ORKEditorLayout("active", true)]
		public float distance = 100.0f;

		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;

		[ORKEditorHelp("Ignore User", "The game object of the user of this ability/item will be ignored by the raycast.", "")]
		public bool ignoreUser = false;

		[ORKEditorHelp("Ray Origin", "The origin position of the raycast.\n" +
			"- User: The user of the ability/item is the origin.\n" +
			"- Screen: The screen is the origin. If you use mouse/touch control, " +
			"the point you clicked/touched the screen is the origin, else the center of the screen.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TargetRayOrigin rayOrigin = TargetRayOrigin.User;

		[ORKEditorHelp("Path to Child", "You can define a child object of the user to be the origin.\n" +
			"Leave empty if you only want the user to be the origin.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("rayOrigin", TargetRayOrigin.User, endCheckGroup=true)]
		public string pathToChild = "";

		[ORKEditorHelp("Offset", "The offset will be added to the origin position of the raycast.", "")]
		public Vector3 offset = Vector3.zero;

		[ORKEditorHelp("Direction", "The direction in local space the raycast will be sent to.\n" +
			"E.g. X=0, Y=0, Z=1 will send the raycast forward.\n" +
			"This setting is only used when no mouse/touch control is enabled.", "")]
		[ORKEditorLayout(checkCallback="check:raydirection")]
		public Vector3 rayDirection = Vector3.forward;


		// cursor settings
		[ORKEditorHelp("Cursor Texture", "Select the texture that will be used as mouse cursor.", "")]
		[ORKEditorInfo(separator=true, labelText="Cursor Settings")]
		public Texture2D cursorTexture;

		[ORKEditorHelp("Cursor Hotspot", "The offset from the top left of the texture to use as the target point.\n" +
				"Must be within the bounds of the cursor.", "")]
		[ORKEditorLayout("cursorTexture", null, elseCheckGroup=true)]
		public Vector2 cursorHotSpot = Vector2.zero;

		[ORKEditorHelp("Cursor Mode", "Select the mode of the cursor:\n" +
			"- Auto: Use hardware cursors on supported platforms.\n" +
			"- Force Software: Force the use of software cursors.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public CursorMode cursorMode = CursorMode.Auto;


		// AI settings
		[ORKEditorHelp("Auto Target", "AI/Auto targeting will automatically target " +
			"a nearby combatant according to the target type.\n" +
			"If disabled (or no combatant available), the screen center will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="AI/Auto Target Settings")]
		public bool autoTarget = true;

		[ORKEditorHelp("Path to Child", "If this ability/item is used by an AI controlled combatant, the raycast will " +
			"target a nearby combatant according to the target type.\n" +
			"You can define a child object of the target to be the raycast target.\n" +
			"Leave empty if you only want the target to be the raycast target.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("autoTarget", true)]
		public string pathToTarget = "";

		[ORKEditorHelp("Target Offset", "Offset added to the AI target position (nearby combatant).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector3 targetOffset = Vector3.zero;

		[ORKEditorHelp("Use Mouse Position", "Use the current mouse position instead of the screen center for targeting.", "")]
		public bool useMousePosition = false;

		[ORKEditorHelp("Only Player (Mouse)", "Use the mouse position only when the player is the user.", "")]
		[ORKEditorLayout("useMousePosition", true, endCheckGroup=true)]
		public bool mouseOnlyPlayer = true;

		[ORKEditorHelp("Screen Offset", "Offset added to the screen center or mouse position.", "")]
		public Vector3 screenOffset = Vector3.zero;


		// mouse/touch control
		[ORKEditorLayout(endCheckGroup=true)]
		public MouseTouchControl mouseTouch = new MouseTouchControl();

		public TargetRaycast()
		{

		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public void SetCursor()
		{
			if(this.cursorTexture != null)
			{
				Cursor.SetCursor(this.cursorTexture, this.cursorHotSpot, this.cursorMode);
			}
		}

		public void ResetCursor()
		{
			if(this.cursorTexture != null)
			{
				Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
			}
		}


		/*
		============================================================================
		Raycast functions
		============================================================================
		*/
		public bool NeedInteraction()
		{
			return this.active && this.mouseTouch.Active();
		}

		public void Tick(ActiveBattleMenu menu, GameObject user)
		{
			Vector3 point = Vector3.zero;
			if(this.mouseTouch.Interacted(ref point))
			{
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					point = this.ScreenRayPoint(point);
				}
				menu.SetRayPoint(this.GetRayPoint(user, point));
			}
		}

		public Vector3 ScreenRayPoint(Vector3 point)
		{
			Ray ray = Camera.main.ScreenPointToRay(point);
			RaycastOutput hit;
			if(RaycastHelper.Raycast(ray.origin, ray.direction, out hit, this.distance, this.layerMask))
			{
				point = hit.point;
			}
			else
			{
				point = ray.GetPoint(this.distance);
			}
			return point;
		}

		public Vector3 GetRayPoint(GameObject user, Vector3 target)
		{
			Vector3 point = Vector3.zero;
			if(this.active && user != null)
			{
				Ray ray;
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					if(this.pathToChild != "")
					{
						Transform tr = user.transform.Find(this.pathToChild);
						if(tr != null)
							user = tr.gameObject;
					}
					Vector3 origin = user.transform.position + offset;
					Vector3 dir = Vector3.zero;
					if(this.mouseTouch.Active())
					{
						dir = VectorHelper.GetDirection(origin, target);
					}
					else
					{
						dir = user.transform.TransformDirection(this.rayDirection);
					}
					ray = new Ray(origin, dir);
				}
				else
				{
					ray = Camera.main.ScreenPointToRay(target + this.offset);
				}

				List<RaycastOutput> hit = RaycastHelper.RaycastAll(ray.origin, ray.direction, this.distance, this.layerMask);
				if(hit.Count > 0)
				{
					for(int i = 0; i < hit.Count; i++)
					{
						if(!this.ignoreUser || user.transform.root != hit[i].transform.root)
						{
							point = hit[i].point;
							break;
						}
					}
				}
				else
				{
					point = ray.GetPoint(this.distance);
				}
			}
			return point;
		}

		public Vector3 GetAIPoint(Combatant user, GameObject target)
		{
			Vector3 pos = Vector3.zero;

			if(this.autoTarget && target != null)
			{
				if(this.pathToTarget != "" && target != null)
				{
					Transform t = target.transform.Find(this.pathToChild);
					if(t != null)
					{
						target = t.gameObject;
					}
				}
				pos = target.transform.position + this.targetOffset;
				if(TargetRayOrigin.Screen.Equals(this.rayOrigin) && Camera.main != null)
				{
					pos = Camera.main.WorldToScreenPoint(pos);
				}
			}
			else
			{
				if(this.useMousePosition &&
					(!this.mouseOnlyPlayer || ORK.Game.ActiveGroup.Leader == user))
				{
					pos = this.screenOffset + (Vector3)ORK.Control.MousePosition;
				}
				else
				{
					pos = ORK.GameSettings.GetScreenCenter() + this.screenOffset;
				}
				pos = ORK.Core.GUIMatrix.MultiplyPoint3x4(pos);
				pos.y = Screen.height - pos.y;

				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					pos = this.ScreenRayPoint(pos);
				}
			}

			return this.GetRayPoint(user.GameObject, pos);
		}
	}
}
