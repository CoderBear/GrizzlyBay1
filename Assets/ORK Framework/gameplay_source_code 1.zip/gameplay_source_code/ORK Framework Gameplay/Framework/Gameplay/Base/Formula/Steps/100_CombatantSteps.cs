
using UnityEngine;
using ORKFramework;
using ORKFramework.Formulas;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Status Value", "A combatant's current or maximum status value is used.", "")]
	[ORKNodeInfo("Combatant Steps")]
	public class StatusValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Status Value", "Select the status value that will be used as value.\n" +
			"You can use the current value or maximum value of the status value.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true)]
		public int id = 0;
		
		[ORKEditorHelp("Value Origin", "Select which value will be used:\n" +
			"- Base: The base value, without any bonuses.\n" +
			"- Current: The actual/real value (including bonuses).\n" +
			"- Maximum: The maximum value the status value can reach.", "")]
		public StatusValueOrigin svOrigin = StatusValueOrigin.Current;
		
		public StatusValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				float value = 0;
				if(StatusValueOrigin.Base.Equals(this.svOrigin))
				{
					value = c.Status[this.id].GetBaseValue();
				}
				else if(StatusValueOrigin.Current.Equals(this.svOrigin))
				{
					value = c.Status[this.id].GetValue();
				}
				else if(StatusValueOrigin.Maximum.Equals(this.svOrigin))
				{
					value = c.Status[this.id].GetMaxValue();
				}
				ValueHelper.UseOperator(ref result, value, this.formulaOperator);
			}
			return this.next;
		}
		
		public override int CalculatePreview(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				float value = 0;
				if(StatusValueOrigin.Base.Equals(this.svOrigin))
				{
					value = c.Status[this.id].GetBaseValue();
				}
				else if(StatusValueOrigin.Current.Equals(this.svOrigin))
				{
					value = c.Status[this.id].GetPreviewValue(false);
				}
				else if(StatusValueOrigin.Maximum.Equals(this.svOrigin))
				{
					value = c.Status[this.id].GetPreviewMaxValue();
				}
				ValueHelper.UseOperator(ref result, value, this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " + 
				this.svOrigin + " " + ORK.StatusValues.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Attack Attribute", "A combatant's current attack attribute value is used.", "")]
	[ORKNodeInfo("Combatant Steps")]
	public class AttackAttributeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Attack Attribute", "Select the attack attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, separator=true)]
		public int id = 0;
		
		[ORKEditorHelp("Attribute", "Select the attribute that will be used as value.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, idFieldName="id")]
		public int id2 = 0;
		
		public AttackAttributeStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				ValueHelper.UseOperator(ref result, 
					c.Status.GetAttackAttribute(this.id).GetValue(this.id2), 
					this.formulaOperator);
			}
			return this.next;
		}
		
		public override int CalculatePreview(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				ValueHelper.UseOperator(ref result, 
					c.Status.GetAttackAttribute(this.id).GetPreviewValue(this.id2), 
					this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				ORK.AttackAttributes.GetName(this.id) + " " +
				ORK.AttackAttributes.GetName(this.id, this.id2);
		}
	}
	
	[ORKEditorHelp("Defence Attribute", "A combatant's current defence attribute value is used.", "")]
	[ORKNodeInfo("Combatant Steps")]
	public class DefenceAttributeStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Defence Attribute", "Select the defence attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, separator=true)]
		public int id = 0;
		
		[ORKEditorHelp("Attribute", "Select the attribute that will be used as value.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="id")]
		public int id2 = 0;
		
		public DefenceAttributeStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				ValueHelper.UseOperator(ref result, 
					c.Status.GetDefenceAttribute(this.id).GetValue(this.id2), 
					this.formulaOperator);
			}
			return this.next;
		}
		
		public override int CalculatePreview(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				ValueHelper.UseOperator(ref result, 
					c.Status.GetDefenceAttribute(this.id).GetPreviewValue(this.id2), 
					this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + " " +
				ORK.DefenceAttributes.GetName(this.id) + " " +
				ORK.DefenceAttributes.GetName(this.id, this.id2);
		}
	}
	
	[ORKEditorHelp("Level", "A combatant's current or maximum level (or class level) is used.", "")]
	[ORKNodeInfo("Combatant Steps")]
	public class LevelStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Class Level", "The class level of the combatant is used.\n" +
			"If disabled, the base level is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useClass = false;
		
		[ORKEditorHelp("Use Maximum", "The maximum level is used.\n" +
			"If disabled, the current level is used.", "")]
		public bool useMax = false;
		
		[ORKEditorHelp("Use Average", "Use the average level of the combatant's group.", "")]
		public bool useAverage = false;
		
		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;
		
		public LevelStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				float value = 0;
				if(this.useClass)
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxClassLevel : c.Group.AverageBattleClassLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxClassLevel : c.Group.AverageClassLevel;
						}
					}
					else
					{
						value = this.useMax ? c.MaxClassLevel : c.ClassLevel;
					}
				}
				else
				{
					if(this.useAverage)
					{
						if(this.onlyBattle)
						{
							value = this.useMax ? c.Group.AverageBattleMaxLevel : c.Group.AverageBattleLevel;
						}
						else
						{
							value = this.useMax ? c.Group.AverageMaxLevel : c.Group.AverageLevel;
						}
					}
					else
					{
						value = this.useMax ? c.MaxLevel : c.Level;
					}
				}
				ValueHelper.UseOperator(ref result, value, this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + 
				(this.useAverage ? " Avg. " : " ") + (this.useMax ? "Max " : "") + 
				(this.useClass ? "Class Level" : "Level");
		}
	}
	
	[ORKEditorHelp("Turn", "A combatant's current turn number is used.", "")]
	[ORKNodeInfo("Combatant Steps")]
	public class TurnStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;
		
		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;
		
		public TurnStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				float value = 0;
				if(this.useAverage)
				{
					if(this.onlyBattle)
					{
						value = c.Group.AverageBattleTurn;
					}
					else
					{
						value = c.Group.AverageTurn;
					}
				}
				else
				{
					value = c.Turn;
				}
				ValueHelper.UseOperator(ref result, value, this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + 
				(this.useAverage ? " Avg. Turn" : " Turn");
		}
	}
	
	[ORKEditorHelp("Check Turn", "Checks a combatant's turn.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps", "Combatant Steps")]
	public class CheckTurnStep : BaseFormulaCheckStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Use Average", "Use the average turn number of the combatant's group.", "")]
		public bool useAverage = false;
		
		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;
		
		
		[ORKEditorHelp("Check Type", "Checks if the turn is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn is between two defind values, including the values.\n" +
			"Range exclusive checks if the turn is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Turn Value")]
		public FormulaFloat turn = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Turn Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FormulaFloat turn2;
		
		public CheckTurnStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			bool check = false;
			
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				check = ValueHelper.CheckVariableValue(
					this.useAverage ? 
						(this.onlyBattle ? c.Group.AverageBattleTurn : c.Group.AverageTurn) : 
						c.Turn, 
					this.turn.GetValue(user, target), 
					this.turn2 != null ? this.turn2.GetValue(user, target) : 0, 
					this.check);
			}
			
			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() + 
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}
	
	[ORKEditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi-Turns'." +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps", "Combatant Steps")]
	public class CheckTurnValueStep : BaseFormulaCheckStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;
		
		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;
		
		
		[ORKEditorHelp("Check Type", "Checks if the turn value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn value is between two defind values, including the values.\n" +
			"Range exclusive checks if the turn value is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public FormulaFloat turn = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FormulaFloat turn2;
		
		public CheckTurnValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			bool check = false;
			
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				check = ValueHelper.CheckVariableValue(
					this.useAverage ? 
						(this.onlyBattle ? c.Group.AverageBattleTurnValue : c.Group.AverageTurnValue) : 
						c.TurnValue, 
					this.turn.GetValue(user, target), 
					this.turn2 != null ? this.turn2.GetValue(user, target) : 0, 
					this.check);
			}
			
			if(check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() + 
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}
	
	[ORKEditorHelp("Inventory Space", "A combatant's used (occupied) or maximum inventory space is used.", "")]
	[ORKNodeInfo("Combatant Steps")]
	public class InventorySpaceStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorHelp("Use Maximum", "The maximum inventory space is used.\n" +
			"If disabled, the currently used (occupied) inventory space is used.", "")]
		public bool useMax = false;
		
		public InventorySpaceStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				float value = 0;
				if(this.useMax)
				{
					value = c.Inventory.TotalSpace;
				}
				else
				{
					value = c.Inventory.Space;
				}
				ValueHelper.UseOperator(ref result, value, this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + " " + this.origin.GetInfoText() + (this.useMax ? " Max" : "");
		}
	}
	
	[ORKEditorHelp("Check Status", "Checks a combatant on certain status requirements, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps", "Combatant Steps")]
	public class CheckStatusStep : BaseFormulaCheckStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		
		// requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;
		
		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "", 
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[] {new StatusRequirement()};
		
		public CheckStatusStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			bool check = true;
			bool any = false;
			
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				any = true;
				if(!StatusRequirement.Check(c, this.req, this.needed))
				{
					check = false;
				}
			}
			
			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		public override int CalculatePreview(ref float result, Combatant user, Combatant target)
		{
			bool check = true;
			bool any = false;
			
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				any = true;
				if(!StatusRequirement.CheckPreview(c, this.req, this.needed))
				{
					check = false;
				}
			}
			
			if(any && check)
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Status Fork", "Checks a combatant for certain status requirements.\n" +
		"If a requirement is valid, it's next step will be executed.\n" +
		"If no requirement is valid, 'Failed' will be executed.", "")]
	[ORKNodeInfo("Check Steps", "Combatant Steps")]
	public class StatusForkStep : BaseFormulaStep
	{
		// status value
		[ORKEditorInfo(separator=true)]
		public FormulaStatusOrigin origin = new FormulaStatusOrigin();
		
		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "", 
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirementNextNode[] req = new StatusRequirementNextNode[] {new StatusRequirementNextNode()};
		
		public StatusForkStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				for(int i=0; i<this.req.Length; i++)
				{
					if(this.req[i].CheckRequirement(c))
					{
						return this.req[i].next;
					}
				}
			}
			return this.next;
		}
		
		public override int CalculatePreview(ref float result, Combatant user, Combatant target)
		{
			Combatant c = this.origin.GetCombatant(user, target);
			if(c != null)
			{
				for(int i=0; i<this.req.Length; i++)
				{
					if(this.req[i].CheckRequirementPreview(c))
					{
						return this.req[i].next;
					}
				}
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.GetInfoText();
		}
		
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Requirement " + (index - 1) + ": " + this.req[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.req.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.req[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.req[index - 1].next = next;
			}
		}
	}
}
