
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class Range : BaseData
	{
		[ORKEditorHelp("Range", "The range in world units.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float range = 5;
		
		[ORKEditorHelp("Threshold", "The threshold is used for a smoother range check.\n" +
			"In range is 'range - threshold', out of range is 'range + threshold'.\n" +
			"Use a negative value to invert the threshold.", "")]
		public float threshold = 0;
		
		[ORKEditorHelp("Ignore Y Distance", "The distance along the Y-axis will be ignored, i.e. the height difference is ignored.", "")]
		public bool ignoreYDistance = true;
		
		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will be ignored.", "")]
		public bool ignoreRadius = false;
		
		public Range()
		{
			
		}
		
		public Range(float range)
		{
			this.range = range;
		}
		
		public Range(float range, bool ignoreYDistance, bool ignoreRadius, float threshold)
		{
			this.range = range;
			this.threshold = threshold;
			this.ignoreYDistance = ignoreYDistance;
			this.ignoreRadius = ignoreRadius;
		}
		
		
		/*
		============================================================================
		Static ranges
		============================================================================
		*/
		public static Range Infinity = new Range(Mathf.Infinity);
		
		public static Range Battle
		{
			get{ return ORK.BattleSettings.battleRange;}
		}
		
		
		/*
		============================================================================
		In range functions
		============================================================================
		*/
		public bool InRange(Combatant combatant, Combatant target)
		{
			if(combatant != null && combatant.GameObject != null && 
				target != null && target.GameObject != null)
			{
				Vector3 v = target.GameObject.transform.position;
				if(this.ignoreYDistance)
				{
					v.y = combatant.GameObject.transform.position.y;
				}
				
				return Vector3.Distance(combatant.GameObject.transform.position, v) - 
					(this.ignoreRadius ? 0 : (combatant.BoxRadius + target.BoxRadius)) <= this.range - this.threshold;
			}
			return false;
		}
		
		public bool InRange(Vector3 position, Combatant combatant)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				if(this.ignoreYDistance)
				{
					position.y = combatant.GameObject.transform.position.y;
				}
				
				return Vector3.Distance(combatant.GameObject.transform.position, position) - 
					(this.ignoreRadius ? 0 : combatant.BoxRadius) <= this.range - this.threshold;
			}
			return false;
		}
		
		public static float Distance(Combatant user, Combatant target, bool ignoreYDistance, bool ignoreRadius)
		{
			if(user != null && user.GameObject != null && 
				target != null && target.GameObject != null)
			{
				Vector3 v = target.GameObject.transform.position;
				if(ignoreYDistance)
				{
					v.y = user.GameObject.transform.position.y;
				}
				
				return Vector3.Distance(user.GameObject.transform.position, v) - 
					(ignoreRadius ? 0 : (user.BoxRadius + target.BoxRadius));
			}
			else
			{
				return Mathf.Infinity;
			}
		}
		
		
		/*
		============================================================================
		Out of range functions
		============================================================================
		*/
		public bool OutOfRange(Combatant combatant, Combatant target)
		{
			if(combatant != null && combatant.GameObject != null && 
				target != null && target.GameObject != null)
			{
				Vector3 v = target.GameObject.transform.position;
				if(this.ignoreYDistance)
				{
					v.y = combatant.GameObject.transform.position.y;
				}
				return Vector3.Distance(combatant.GameObject.transform.position, v) - 
					(this.ignoreRadius ? 0 : (combatant.BoxRadius + target.BoxRadius)) >= this.range + this.threshold;
			}
			return false;
		}
		
		public bool OutOfRange(Vector3 position, Combatant combatant)
		{
			if(combatant != null && combatant.GameObject != null)
			{
				if(this.ignoreYDistance)
				{
					position.y = combatant.GameObject.transform.position.y;
				}
				return Vector3.Distance(combatant.GameObject.transform.position, position) - 
					(this.ignoreRadius ? 0 : combatant.BoxRadius) >= this.range + this.threshold;
			}
			return false;
		}
	}
}
