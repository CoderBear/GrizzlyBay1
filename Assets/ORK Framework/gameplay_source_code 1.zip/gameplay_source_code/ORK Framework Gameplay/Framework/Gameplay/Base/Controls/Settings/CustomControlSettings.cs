
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CustomControlSettings : BaseData
	{
		[ORKEditorArray(false, "Add Custom Control", "Adds a control behaviour.\n" +
			"Control behaviours will be automatically enabled/disabled by ORK when the selected control state changes.\n" +
			"Add control behaviours if you're using your own player or camera control scripts.", "", 
			"Remove", "Removes the control behaviour.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Custom Control", "Define the name and settings of the custom control behaviour.", ""
		})]
		public ControlBehaviour[] behaviours = new ControlBehaviour[0];
		
		public CustomControlSettings()
		{
			
		}
		
		
		/*
		============================================================================
		Player control functions
		============================================================================
		*/
		public void AddPlayerControls(GameObject player, GameObject camera)
		{
			for(int i=0; i<this.behaviours.Length; i++)
			{
				if(CustomControlType.Player.Equals(this.behaviours[i].blockType))
				{
					if(CustomControlType.Player.Equals(this.behaviours[i].objectType))
					{
						this.behaviours[i].Add(player, false);
					}
					else
					{
						this.behaviours[i].Add(camera, false);
					}
				}
			}
		}
		
		public void RemovePlayerControls(GameObject player, GameObject camera)
		{
			for(int i=0; i<this.behaviours.Length; i++)
			{
				if(CustomControlType.Player.Equals(this.behaviours[i].blockType))
				{
					if(CustomControlType.Player.Equals(this.behaviours[i].objectType))
					{
						this.behaviours[i].Remove(player, false);
					}
					else
					{
						this.behaviours[i].Remove(camera, false);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Camera control functions
		============================================================================
		*/
		public void AddCameraControls(GameObject player, GameObject camera)
		{
			for(int i=0; i<this.behaviours.Length; i++)
			{
				if(CustomControlType.Camera.Equals(this.behaviours[i].blockType))
				{
					if(CustomControlType.Player.Equals(this.behaviours[i].objectType))
					{
						this.behaviours[i].Add(player, true);
					}
					else
					{
						this.behaviours[i].Add(camera, true);
					}
				}
			}
		}
		
		public void RemoveCameraControls(GameObject player, GameObject camera)
		{
			for(int i=0; i<this.behaviours.Length; i++)
			{
				if(CustomControlType.Camera.Equals(this.behaviours[i].blockType))
				{
					if(CustomControlType.Player.Equals(this.behaviours[i].objectType))
					{
						this.behaviours[i].Remove(player, true);
					}
					else
					{
						this.behaviours[i].Remove(camera, true);
					}
				}
			}
		}
	}
}
