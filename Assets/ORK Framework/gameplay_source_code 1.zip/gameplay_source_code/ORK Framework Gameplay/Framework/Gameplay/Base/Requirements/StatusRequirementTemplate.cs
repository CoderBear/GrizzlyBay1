
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class StatusRequirementTemplate : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the status requirement template.", "")]
		[ORKEditorInfo("Template Settings", "Define the name of this status requirement template.", "", 
			endFoldout=true, expandWidth=true)]
		public string name = "";
		
		
		// requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo("Status Requirements", "Define the status requirements of this template.\n" +
			"You can use this template in other status requirements, e.g. in event interactions.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;
		
		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "", 
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		[ORKEditorInfo(endFoldout=true)]
		public StatusRequirement[] req = new StatusRequirement[0];
		
		public StatusRequirementTemplate()
		{
			
		}
		
		public StatusRequirementTemplate(string name)
		{
			this.name = name;
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckRequirement(Combatant combatant)
		{
			return StatusRequirement.Check(combatant, this.req, this.needed);
		}
		
		public bool CheckRequirementPreview(Combatant combatant)
		{
			return StatusRequirement.CheckPreview(combatant, this.req, this.needed);
		}
		
		public bool CheckRequirementBestiary(Combatant combatant)
		{
			return StatusRequirement.CheckBestiary(combatant, this.req, this.needed);
		}
		
		
		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public void RegisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			for(int i=0; i<this.req.Length; i++)
			{
				this.req[i].RegisterStatusChanges(combatant, notify);
			}
		}
		
		public void UnregisterStatusChanges(Combatant combatant, IStatusChanged notify)
		{
			for(int i=0; i<this.req.Length; i++)
			{
				this.req[i].UnregisterStatusChanges(combatant, notify);
			}
		}
	}
}
