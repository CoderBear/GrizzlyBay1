
using UnityEngine;
using ORKFramework.Reflection;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InputKey : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the key.", "")]
		[ORKEditorInfo("Key Settings", "Set where this key will get it's input from.\n" +
			"Despite the selected input origin, all keys can get input from HUDs.", "", 
			expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Input Origin", "Select where the input of the key will come from:\n" +
			"- None: No direct input is used. Input from a HUD can still be used.\n" +
			"- Unity Input Manager: A key defined in the Unity input manager is used.\n" +
			"- Key Code: The key mapped to the selected key code is used.\n" +
			"- ORK Input Key: Other input keys are used.\n" +
			"- Key Combo: A key combo sequence is used.\n" +
			"- Mouse: A mouse button is used (can't be used as axis).\n" +
			"- Touch: A touch is used (can't be used as axis).\n" +
			"- Custom: A custom control script is used (i.e. static functions of a class).", "")]
		[ORKEditorInfo(separator=true)]
		public InputKeyType type = InputKeyType.None;
		
		[ORKEditorHelp("Invert Axis", "The axis will be inverted.", "")]
		public bool invertAxis = false;
		
		
		// unity input manager
		[ORKEditorHelp("Name", "The name of the Unity input manager key.\n" +
			"The name must match the spelling of the name given in the Unity input manager.", "")]
		[ORKEditorInfo(separator=true, expandWidth=true)]
		[ORKEditorLayout("type", InputKeyType.UnityInputManager)]
		public string keyName = "";
		
		[ORKEditorHelp("Is Joypad Axis", "The used Unity input manager key is a joypad axis.\n" +
			"Joypad axis dont have down/hold/up actions, enable this option if you want to use them.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool isJoypadAxis = false;
		
		
		// key code
		[ORKEditorHelp("Positive Key", "Select the Key Code of the key used for the positive axis value.\n" +
			"If this key isn't used for axis input (e.g. horizontal selection), you only need to define a positive key.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", InputKeyType.KeyCode)]
		public KeyCode positiveKey = KeyCode.None;
		
		[ORKEditorHelp("Negative Key", "Select the Key Code of the key used for the negative axis value.\n" +
			"If this key isn't used for axis input (e.g. horizontal selection), you only need to define a positive key.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public KeyCode negativeKey = KeyCode.None;
		
		
		// mouse
		[ORKEditorHelp("Mouse Button", "Define which mouse button will be used, e.g.:\n" +
			"0 = left button\n" +
			"1 = right button\n" +
			"2 = middle button", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("type", InputKeyType.Mouse)]
		[ORKEditorInfo(separator=true)]
		public int mouseButton = 0;
		
		[ORKEditorHelp("Click Count", "The amount of clicks used to trigger the input, e.g.:\n" +
			"1 = single click\n" +
			"2 = double click", "")]
		[ORKEditorLimit(1, false)]
		public int clickCount = 1;
		
		[ORKEditorHelp("Click Timeout (s)", "The time in seconds to recognize multi-clicks.\n" +
			"If another click happens within the timeout, it will be recognized " +
			"as a multi-click (e.g. double click).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float clickTimeout = 0.2f;
		
		
		// touch
		[ORKEditorHelp("Touch Count", "Define the number of touches that will trigger the input, e.g.:\n" +
			"1 = one finger\n" +
			"2 = two fingers", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("type", InputKeyType.Touch)]
		public int touchCount = 1;
		
		[ORKEditorHelp("Consume Fingers", "Consume the fingers used for the touch input.\n" +
			"The touch wont be available for other touch interactions (e.g. 'Control' type HUDs).", "")]
		public bool consumeFingers = true;
		
		[ORKEditorHelp("Tab Count", "The amount of tabs used to trigger the input, e.g.:\n" +
			"1 = single tab" +
			"2 = double tab", "")]
		[ORKEditorLimit(1, false)]
		public int tabCount = 1;
		
		[ORKEditorHelp("Tab Timeout (s)", "The time in seconds to recognize multi-tabs.\n" +
			"If another tab happens within the timeout, it will be recognized " +
			"as a multi-tab (e.g. double tab).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float tabTimeout = 0.2f;
		
		
		// ORK input key
		[ORKEditorHelp("Needed", "Either all or only one input key must receive input to trigger this input key.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout("type", InputKeyType.ORKInputKey)]
		public Needed needed = Needed.One;
		
		[ORKEditorHelp("Input Key", "Select the input key that will be used as input for this input key.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Input Key", "Adds an input key that will be used as input.", "",
			"Remove", "Removes this input key.", "", isHorizontal=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public int[] inputKeyID;
		
		
		// combo key
		[ORKEditorArray(false, "Add Combo Key", "Adds a combo key.", "",
			"Remove", "Removes this combo key.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Combo Key", "Define the used input key and time until the next combo key has to be pressed.", ""
		})]
		[ORKEditorLayout("type", InputKeyType.KeyCombo, endCheckGroup=true, autoInit=true, autoSize=1)]
		public ComboInputKey[] comboInput;
		
		
		// input handling
		[ORKEditorHelp("Input Handling", "Select when the input will be recognized:\n" +
			"- Down: When the key is pressed down.\n" +
			"- Hold: While the key is held down.\n" +
			"- Up: When the key is released.\n" +
			"- Any: When the key is pressed down, held down or released.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(new string[] {"type", "type", "type", "type"}, 
			new System.Object[] {InputKeyType.KeyCode, InputKeyType.UnityInputManager, 
				InputKeyType.Mouse, InputKeyType.Touch}, 
			needed=Needed.One)]
		public InputHandling handling = InputHandling.Down;
		
		[ORKEditorHelp("Timeout (s)", "The time in seconds between recognizing two inputs.\n" +
			"Set to 0 to recognize the input every frame.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(setDefault=true, defaultValue=0.0f)]
		public float inputTimeout = 0;
		
		[ORKEditorHelp("Hold Time (s)", "The time in seconds the input has to be held to recognizing the input.\n" +
			"Set to 0 to recognize the input immediately.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("handling", InputHandling.Down, elseCheckGroup=true, endCheckGroup=true, endGroups=2, 
			setDefault=true, defaultValue=0.0f)]
		public float inputHoldTime = 0;
		
		
		// custom
		[ORKEditorHelp("Class Name", "The name of the class that contains the static functions.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("type", InputKeyType.Custom)]
		public string customName = "";
		
		[ORKEditorInfo(separator=true, labelText="Custom Button Function", label=new string[] {
			"Calls a static function using reflection - the function must return a bool value."
		})]
		[ORKEditorLayout(autoInit=true)]
		public CallMethod customButton;
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Custom Axis Function", label=new string[] {
			"Calls a static function using reflection - the function must return a float value."
		})]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public CallMethod customAxis;
		
		
		// ingame
		private bool inputReceived = false;
		
		private bool blocked = false;
		
		private float updateAxis = 0;
		
		private float hudAxis = 0;
		
		private float codeAxis = 0;
		
		private float timeout = Mathf.NegativeInfinity;
		
		private float holdTimeout = Mathf.NegativeInfinity;
		
		private float lastJoypadAxis = 0;
		
		
		// mouse/touch
		private float releaseTime = 0;
		
		private int count = 0;
		
		private List<int> fingerIDs = new List<int>();
		
		
		// key combo
		private int comboIndex = 0;
		
		private float comboTimeout = 0;
		
		public InputKey()
		{
			
		}
		
		public InputKey(string n)
		{
			this.name = n;
		}
		
		public InputKey(string n, KeyCode pk, KeyCode nk, InputHandling h)
		{
			this.name = n;
			this.positiveKey = pk;
			this.negativeKey = nk;
			this.handling = h;
			this.type = InputKeyType.KeyCode;
		}
		
		
		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public void Tick()
		{
			this.inputReceived = false;
			this.updateAxis = 0;
			
			// blocked input
			if(this.blocked || 
				this.timeout + this.inputTimeout > Time.realtimeSinceStartup || 
				this.holdTimeout + this.inputHoldTime > Time.realtimeSinceStartup)
			{
				if(this.inputHoldTime > 0)
				{
					if(InputKeyType.UnityInputManager.Equals(this.type))
					{
						if(this.isJoypadAxis)
						{
							float tmpAxis = Time.timeScale == 0 ? 
								Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName);
							if(tmpAxis == 0 && this.lastJoypadAxis != 0)
							{
								this.lastJoypadAxis = tmpAxis;
								this.holdTimeout = -this.inputHoldTime;
							}
						}
						else
						{
							if(Input.GetButtonUp(this.keyName))
							{
								this.holdTimeout = -this.inputHoldTime;
							}
						}
					}
					else if(InputKeyType.KeyCode.Equals(this.type))
					{
						if(Input.GetKeyUp(this.positiveKey) || Input.GetKeyUp(this.negativeKey))
						{
							this.holdTimeout = -this.inputHoldTime;
						}
					}
					else if(InputKeyType.Mouse.Equals(this.type))
					{
						if(Input.GetMouseButtonUp(this.mouseButton))
						{
							this.holdTimeout = -this.inputHoldTime;
							this.count = 0;
						}
						else if(Input.GetMouseButton(this.mouseButton))
						{
							this.releaseTime = Time.time + this.clickTimeout;
						}
					}
					else if(InputKeyType.Touch.Equals(this.type))
					{
						if(ORK.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
						{
							this.holdTimeout = -this.inputHoldTime;
							this.count = 0;
						}
						else if(ORK.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Hold))
						{
							this.releaseTime = Time.time + this.tabTimeout;
						}
					}
				}
				return;
			}
			// Unity input manager
			else if(InputKeyType.UnityInputManager.Equals(this.type))
			{
				if(this.isJoypadAxis)
				{
					this.updateAxis = this.invertAxis ? 
						-(Time.timeScale == 0 ? Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName)) : 
						(Time.timeScale == 0 ? Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName));
					
					// set input down time
					if(this.inputHoldTime > 0)
					{
						// down
						if(this.updateAxis != 0 && this.lastJoypadAxis == 0)
						{
							this.holdTimeout = Time.realtimeSinceStartup;
							this.lastJoypadAxis = this.updateAxis;
							return;
						}
						// up
						else if(this.updateAxis == 0 && this.lastJoypadAxis != 0)
						{
							this.holdTimeout = -this.inputHoldTime;
							if(InputHandling.Hold.Equals(this.handling))
							{
								this.lastJoypadAxis = this.updateAxis;
								return;
							}
						}
					}
					
					if((InputHandling.Down.Equals(this.handling) && this.updateAxis != 0 && this.lastJoypadAxis == 0) || 
						(InputHandling.Hold.Equals(this.handling) && this.updateAxis != 0 && this.lastJoypadAxis != 0) || 
						(InputHandling.Up.Equals(this.handling) && this.updateAxis == 0 && this.lastJoypadAxis != 0) || 
						(InputHandling.Any.Equals(this.handling) && 
							((this.updateAxis != 0 && this.lastJoypadAxis == 0) || 
							(this.updateAxis != 0 && this.lastJoypadAxis != 0) || 
							(this.updateAxis == 0 && this.lastJoypadAxis != 0))))
					{
						if(InputHandling.Up.Equals(this.handling) || 
							(InputHandling.Any.Equals(this.handling) && this.updateAxis == 0))
						{
							float tmp = this.updateAxis;
							this.updateAxis = this.lastJoypadAxis;
							this.lastJoypadAxis = tmp;
						}
						else
						{
							this.lastJoypadAxis = this.updateAxis;
						}
						this.timeout = Time.realtimeSinceStartup;
						this.inputReceived = true;
						return;
					}
					this.lastJoypadAxis = this.updateAxis;
				}
				else
				{
					this.updateAxis = this.invertAxis ? 
						-(Time.timeScale == 0 ? Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName)) : 
						(Time.timeScale == 0 ? Input.GetAxisRaw(this.keyName) : Input.GetAxis(this.keyName));
					
					// set input down time
					if(this.inputHoldTime > 0)
					{
						if(Input.GetButtonDown(this.keyName))
						{
							this.holdTimeout = Time.realtimeSinceStartup;
							return;
						}
						else if(Input.GetButtonUp(this.keyName))
						{
							this.holdTimeout = -this.inputHoldTime;
							if(InputHandling.Hold.Equals(this.handling))
							{
								return;
							}
						}
					}
					
					if((InputHandling.Down.Equals(this.handling) && Input.GetButtonDown(this.keyName)) || 
						(InputHandling.Hold.Equals(this.handling) && Input.GetButton(this.keyName)) || 
						(InputHandling.Up.Equals(this.handling) && Input.GetButtonUp(this.keyName)) || 
						(InputHandling.Any.Equals(this.handling) && 
							(Input.GetButtonDown(this.keyName) || Input.GetButton(this.keyName) || 
							Input.GetButtonUp(this.keyName))))
					{
						this.timeout = Time.realtimeSinceStartup;
						this.inputReceived = true;
						return;
					}
				}
			}
			// key code
			else if(InputKeyType.KeyCode.Equals(this.type))
			{
				// set input down time
				if(this.inputHoldTime > 0)
				{
					if(Input.GetKeyDown(this.positiveKey) || Input.GetKeyDown(this.negativeKey))
					{
						this.holdTimeout = Time.realtimeSinceStartup;
						return;
					}
					else if(Input.GetKeyUp(this.positiveKey) || Input.GetKeyUp(this.negativeKey))
					{
						this.holdTimeout = -this.inputHoldTime;
						if(InputHandling.Hold.Equals(this.handling))
						{
							return;
						}
					}
				}
				
				// positive key
				if((InputHandling.Down.Equals(this.handling) && Input.GetKeyDown(this.positiveKey)) ||
					(InputHandling.Hold.Equals(this.handling) && Input.GetKey(this.positiveKey)) || 
					(InputHandling.Up.Equals(this.handling) && Input.GetKeyUp(this.positiveKey)) || 
					(InputHandling.Any.Equals(this.handling) && 
						(Input.GetKeyDown(this.positiveKey) || Input.GetKey(this.positiveKey) || 
						Input.GetKeyUp(this.positiveKey))))
				{
					this.timeout = Time.realtimeSinceStartup;
					this.updateAxis = this.invertAxis ? -1 : 1;
					this.inputReceived = true;
					return;
				}
				// negative key
				else if((InputHandling.Down.Equals(this.handling) && Input.GetKeyDown(this.negativeKey)) ||
					(InputHandling.Hold.Equals(this.handling) && Input.GetKey(this.negativeKey)) || 
					(InputHandling.Up.Equals(this.handling) && Input.GetKeyUp(this.negativeKey)) || 
					(InputHandling.Any.Equals(this.handling) && 
						(Input.GetKeyDown(this.negativeKey) || Input.GetKey(this.negativeKey) || 
						Input.GetKeyUp(this.negativeKey))))
				{
					this.timeout = Time.realtimeSinceStartup;
					this.updateAxis = this.invertAxis ? 1 : -1;
					this.inputReceived = true;
					return;
				}
			}
			// mouse
			else if(InputKeyType.Mouse.Equals(this.type))
			{
				// click count
				if(Input.GetMouseButtonDown(this.mouseButton))
				{
					if(this.releaseTime <= Time.time)
					{
						this.count = 0;
					}
					this.count++;
					this.releaseTime = Time.time + this.clickTimeout;
				}
				
				if(this.clickCount == this.count)
				{
					// set input down time
					if(this.inputHoldTime > 0)
					{
						if(Input.GetMouseButtonDown(this.mouseButton))
						{
							this.holdTimeout = Time.realtimeSinceStartup;
							return;
						}
						else if(Input.GetMouseButtonUp(this.mouseButton))
						{
							this.holdTimeout = -this.inputHoldTime;
							this.count = 0;
							if(InputHandling.Hold.Equals(this.handling))
							{
								return;
							}
						}
					}
					
					if((InputHandling.Down.Equals(this.handling) && Input.GetMouseButtonDown(this.mouseButton)) || 
						(InputHandling.Hold.Equals(this.handling) && Input.GetMouseButton(this.mouseButton)) || 
						(InputHandling.Up.Equals(this.handling) && Input.GetMouseButtonUp(this.mouseButton)) || 
						(InputHandling.Any.Equals(this.handling) && 
							(Input.GetMouseButtonDown(this.mouseButton) || 
							Input.GetMouseButton(this.mouseButton) || 
							Input.GetMouseButtonUp(this.mouseButton))))
					{
						this.timeout = Time.realtimeSinceStartup;
						this.inputReceived = true;
						if(InputHandling.Up.Equals(this.handling))
						{
							this.count = 0;
						}
						return;
					}
					else if(Input.GetMouseButtonUp(this.mouseButton))
					{
						this.count = 0;
					}
				}
			}
			// touch
			else if(InputKeyType.Touch.Equals(this.type))
			{
				bool started = false;
				// tab count
				if(ORK.Control.Touch.CanStart(this.touchCount))
				{
					if(this.releaseTime <= Time.time)
					{
						this.count = 0;
					}
					this.fingerIDs = ORK.Control.Touch.GetStarted(this.consumeFingers);
					started = true;
					this.count++;
					this.releaseTime = Time.time + this.tabTimeout;
				}
				
				if(this.tabCount == this.count)
				{
					// set input down time
					if(this.inputHoldTime > 0)
					{
						if(started)
						{
							this.holdTimeout = Time.realtimeSinceStartup;
							return;
						}
						else if(ORK.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
						{
							this.holdTimeout = -this.inputHoldTime;
							this.count = 0;
							if(InputHandling.Hold.Equals(this.handling))
							{
								return;
							}
						}
					}
					
					if((InputHandling.Down.Equals(this.handling) && started) || 
						ORK.Control.Touch.IsPhase(this.fingerIDs, this.handling))
					{
						this.timeout = Time.realtimeSinceStartup;
						this.inputReceived = true;
						if(InputHandling.Up.Equals(this.handling))
						{
							this.count = 0;
						}
						return;
					}
					else if(ORK.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
					{
						this.count = 0;
					}
				}
			}
			// key combo
			else if(InputKeyType.KeyCombo.Equals(this.type))
			{
				if(this.comboIndex >= 0 && this.comboIndex < this.comboInput.Length)
				{
					// reset if time is up
					if(this.comboIndex > 0 && 
						(this.comboTimeout + this.comboInput[this.comboIndex - 1].timeout < Time.realtimeSinceStartup || 
						this.comboInput[this.comboIndex].OtherButton(this.realID)))
					{
						this.comboIndex = 0;
						this.comboTimeout = 0;
					}
					if(this.comboInput[this.comboIndex].GetButton())
					{
						this.comboTimeout = Time.realtimeSinceStartup;
						this.comboIndex++;
					}
				}
				if(this.comboIndex == this.comboInput.Length)
				{
					if(this.comboInput[this.comboIndex - 1].GetButton())
					{
						this.inputReceived = true;
						return;
					}
					else
					{
						this.comboIndex = 0;
						this.comboTimeout = 0;
					}
				}
			}
			// custom
			else if(InputKeyType.Custom.Equals(this.type))
			{
				System.Object value = this.customButton.GetReturnValueStatic(this.customName);
				if(value is bool)
				{
					this.inputReceived = (bool)value;
					return;
				}
				System.Object value2 = this.customAxis.GetReturnValueStatic(this.customName);
				if(value2 is float)
				{
					this.updateAxis = this.invertAxis ? -(float)value2 : (float)value2;
				}
			}
			
			// HUD or code
			if(this.hudAxis != 0 || this.codeAxis != 0)
			{
				this.timeout = Time.realtimeSinceStartup;
				this.inputReceived = true;
				return;
			}
		}
		
		public void TickCollection()
		{
			// other ORK input keys
			if(InputKeyType.ORKInputKey.Equals(this.type))
			{
				this.inputReceived = false;
				this.updateAxis = 0;
				
				int count = 0;
				for(int i=0; i<this.inputKeyID.Length; i++)
				{
					if(ORK.InputKeys.Get(this.inputKeyID[i]).GetButton())
					{
						if(Needed.One.Equals(this.needed))
						{
							this.timeout = Time.realtimeSinceStartup;
							this.inputReceived = true;
							return;
						}
						count++;
					}
					else if(Needed.All.Equals(this.needed))
					{
						break;
					}
				}
				if(Needed.All.Equals(this.needed) && 
					count == this.inputKeyID.Length)
				{
					this.timeout = Time.realtimeSinceStartup;
					this.inputReceived = true;
					return;
				}
				
				// HUD or code
				if(this.hudAxis != 0 || this.codeAxis != 0)
				{
					this.timeout = Time.realtimeSinceStartup;
					this.inputReceived = true;
					return;
				}
			}
		}
		
		public bool GetButton()
		{
			return this.inputReceived;
		}
		
		public float GetAxis()
		{
			if(this.blocked)
			{
				return 0;
			}
			else if(this.hudAxis != 0)
			{
				if(this.timeout + this.inputTimeout > Time.realtimeSinceStartup || 
					this.holdTimeout + this.inputHoldTime > Time.realtimeSinceStartup)
				{
					return 0;
				}
				else
				{
					this.timeout = Time.realtimeSinceStartup;
					return this.invertAxis ? -this.hudAxis : this.hudAxis;
				}
			}
			else if(this.codeAxis != 0)
			{
				if(this.timeout + this.inputTimeout > Time.realtimeSinceStartup || 
					this.holdTimeout + this.inputHoldTime > Time.realtimeSinceStartup)
				{
					return 0;
				}
				else
				{
					this.timeout = Time.realtimeSinceStartup;
					return this.invertAxis ? -this.codeAxis : this.codeAxis;
				}
			}
			else if(InputKeyType.UnityInputManager.Equals(this.type))
			{
				if(this.isJoypadAxis)
				{
					return this.inputReceived ? this.updateAxis : 0;
				}
			}
			else if(InputKeyType.ORKInputKey.Equals(this.type))
			{
				if(this.inputReceived)
				{
					for(int i=0; i<this.inputKeyID.Length; i++)
					{
						float tmpAxis = ORK.InputKeys.Get(this.inputKeyID[i]).GetAxis();
						if(tmpAxis != 0)
						{
							return this.invertAxis ? -tmpAxis : tmpAxis;
						}
					}
				}
			}
			return this.updateAxis;
		}
		
		public void SetDownTime()
		{
			this.holdTimeout = Time.realtimeSinceStartup;
		}
		
		public void ReleaseDownTime()
		{
			this.holdTimeout = -this.inputHoldTime;
		}
		
		public void SetAxisHUD(float value)
		{
			this.hudAxis = value;
			if(this.hudAxis < -1)
			{
				this.hudAxis = -1;
			}
			else if(this.hudAxis > 1)
			{
				this.hudAxis = 1;
			}
		}
		
		public void SetAxis(float value)
		{
			this.codeAxis = value;
			if(this.codeAxis < -1)
			{
				this.codeAxis = -1;
			}
			else if(this.codeAxis > 1)
			{
				this.codeAxis = 1;
			}
		}
		
		public bool Blocked
		{
			get{ return this.blocked;}
			set
			{
				this.blocked = value;
				this.hudAxis = 0;
				this.codeAxis = 0;
			}
		}
		
		public bool Received
		{
			get{ return this.inputReceived;}
			set{ this.inputReceived = value;}
		}
	}
}
