
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Block Move AI", "Blocks or unblocks the move AI either completely or for a selected object.\n" +
		"Combatants can't use the move AI while it's blocked.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class BlockMoveAIStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the move AI will be blocked.\n" +
			"If disabled, the moveAI will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("Use Object", "Only block the move AI of a selected object.\n" +
			"If disabled, the move AI will be blocked completely (i.e. for all objects).", "")]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting onObject;
		
		public BlockMoveAIStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useObject)
			{
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					MoveAIComponent moveAI = ComponentHelper.GetInChildren<MoveAIComponent>(list[i]);
					if(moveAI != null)
					{
						moveAI.blocked = this.block;
					}
				}
			}
			else
			{
				ORK.Control.SetBlockMoveAI(this.block ? 1 : -1);
			}
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.block ? "Block " : "Unblock ";
		}
	}
	
	[ORKEditorHelp("Set Move AI Target", "Sets the target of a combatant's move AI.\n" +
		"The move AI's settings will kick in afterwards, " +
		"e.g. when using 'Hunt' mode, the hunting settings will be used.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class SetMoveAITargetStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Moving Object")]
		public EventObjectSetting movingObject = new EventObjectSetting();
		
		[ORKEditorHelp("Movement Mode", "Select the mode of movement:\n" +
			"- Idle: The moving object will be idle.\n" +
			"- Waypoint: The moving object will move to the target as a waypoint.\n" +
			"- Follow: The moving object will follow the target.\n" +
			"- GiveWay: The moving object will move out of the way of the target.\n" +
			"- Hunt: The moving object will hunt the target.\n" +
			"- Flee: The moving object will flee from the target.", "")]
		public MoveAIMode moveAIMode = MoveAIMode.Hunt;
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("moveAIMode", MoveAIMode.Idle, elseCheckGroup=true, endCheckGroup=true)]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public SetMoveAITargetStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.movingObject.GetObject(baseEvent);
			Combatant targetCombatant = this.targetObject.GetFirstCombatant(baseEvent);
			
			if(targetCombatant != null)
			{
				for(int i=0; i<list.Count; i++)
				{
					MoveAIComponent moveAI = ComponentHelper.GetInChildren<MoveAIComponent>(list[i]);
					if(moveAI != null)
					{
						moveAI.SetTarget(targetCombatant, this.moveAIMode);
					}
				}
			}
			else
			{
				GameObject target = this.targetObject.GetFirstObject(baseEvent);
				if(target != null)
				{
					for(int i=0; i<list.Count; i++)
					{
						MoveAIComponent moveAI = ComponentHelper.GetInChildren<MoveAIComponent>(list[i]);
						if(moveAI != null)
						{
							moveAI.SetTarget(target, this.moveAIMode);
						}
					}
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.movingObject.GetInfoText() + " " + 
				this.moveAIMode.ToString() + " " +
				this.targetObject.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Stop Move AI", "Stops the current action of a combatant's move AI (e.g. stops hunting).\n" +
		"The move AI's settings will kick in afterwards, e.g. start following waypoints.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class StopMoveAIStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Moving Object")]
		public EventObjectSetting movingObject = new EventObjectSetting();
		
		public StopMoveAIStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = this.movingObject.GetObject(baseEvent);
			for(int i=0; i<list.Count; i++)
			{
				MoveAIComponent moveAI = ComponentHelper.GetInChildren<MoveAIComponent>(list[i]);
				if(moveAI != null)
				{
					moveAI.Stop();
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.movingObject.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Move AI Detection", "Checks if combatants are detected by another combatant's move AI detection.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class CheckMoveAIDetectionStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Needed", "Either all or only one of the objects must be detected.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;
		
		[ORKEditorInfo(separator=true, labelText="User Object")]
		public EventObjectSetting userObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public CheckMoveAIDetectionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.Check(this.userObject.GetCombatant(baseEvent), 
				this.targetObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool Check(List<Combatant> user, List<Combatant> target)
		{
			for(int i=0; i<user.Count; i++)
			{
				if(user[i] != null && user[i].MoveAI != null && 
					user[i].MoveAI.settings.useDetection)
				{
					for(int j=0; j<target.Count; j++)
					{
						if(target[j] != null)
						{
							if(user[i].MoveAI.settings.Detect(user[i], target[j]))
							{
								if(Needed.One.Equals(this.needed))
								{
									return true;
								}
							}
							else if(Needed.All.Equals(this.needed))
							{
								return false;
							}
						}
					}
				}
				else if(Needed.All.Equals(this.needed))
				{
					return false;
				}
			}
			return Needed.All.Equals(this.needed);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.userObject.GetInfoText() + ": " + 
				this.targetObject.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Move AI Hunting", "Checks if combatants are valid for hunting due to another " +
		"combatant's move AI hunting conditions. " +
		"The combatant needs to be aggressive in order to hunt targets.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class CheckMoveAIHuntingStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Needed", "Either all or only one of the objects must be valid hunting targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;
		
		[ORKEditorInfo(separator=true, labelText="User Object")]
		public EventObjectSetting userObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public CheckMoveAIHuntingStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.Check(this.userObject.GetCombatant(baseEvent), 
				this.targetObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool Check(List<Combatant> user, List<Combatant> target)
		{
			for(int i=0; i<user.Count; i++)
			{
				if(user[i] != null && user[i].MoveAI != null && 
					user[i].MoveAI.settings.useHunting)
				{
					for(int j=0; j<target.Count; j++)
					{
						if(target[j] != null)
						{
							if(user[i].MoveAI.settings.IsHunting(user[i], target[j]))
							{
								if(Needed.One.Equals(this.needed))
								{
									return true;
								}
							}
							else if(Needed.All.Equals(this.needed))
							{
								return false;
							}
						}
					}
				}
				else if(Needed.All.Equals(this.needed))
				{
					return false;
				}
			}
			return Needed.All.Equals(this.needed);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.userObject.GetInfoText() + ": " + 
				this.targetObject.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Move AI Flee", "Checks if combatants are valid for fleeing due to another " +
		"combatant's move AI flee conditions.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class CheckMoveAIFleeStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Needed", "Either all or only one of the objects must be valid for fleeing.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;
		
		[ORKEditorInfo(separator=true, labelText="User Object")]
		public EventObjectSetting userObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public CheckMoveAIFleeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.Check(this.userObject.GetCombatant(baseEvent), 
				this.targetObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool Check(List<Combatant> user, List<Combatant> target)
		{
			for(int i=0; i<user.Count; i++)
			{
				if(user[i] != null && user[i].MoveAI != null && 
					user[i].MoveAI.settings.useFlee)
				{
					for(int j=0; j<target.Count; j++)
					{
						if(target[j] != null)
						{
							if(user[i].MoveAI.settings.IsFlee(user[i], target[j]))
							{
								if(Needed.One.Equals(this.needed))
								{
									return true;
								}
							}
							else if(Needed.All.Equals(this.needed))
							{
								return false;
							}
						}
					}
				}
				else if(Needed.All.Equals(this.needed))
				{
					return false;
				}
			}
			return Needed.All.Equals(this.needed);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.userObject.GetInfoText() + ": " + 
				this.targetObject.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Is Move AI Target", "Checks if a combatant is the " +
		"current target of another combatant's move AI.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Move AI Steps")]
	public class CheckMoveAITargetStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="User Object")]
		public EventObjectSetting userObject = new EventObjectSetting();
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting targetObject = new EventObjectSetting();
		
		public CheckMoveAITargetStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.Check(this.userObject.GetCombatant(baseEvent), 
				this.targetObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		private bool Check(List<Combatant> user, List<Combatant> target)
		{
			for(int i=0; i<user.Count; i++)
			{
				if(user[i] != null && user[i].MoveAI != null && 
					user[i].MoveAI.settings.useFlee)
				{
					for(int j=0; j<target.Count; j++)
					{
						if(target[j] != null)
						{
							if(user[i].MoveAI.IsTarget(target[j]))
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.userObject.GetInfoText() + ": " + 
				this.targetObject.GetInfoText();
		}
	}
}
