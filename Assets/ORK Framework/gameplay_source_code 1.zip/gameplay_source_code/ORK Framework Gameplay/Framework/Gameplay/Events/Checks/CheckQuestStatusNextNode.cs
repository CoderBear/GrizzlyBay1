
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class CheckQuestStatusNextNode : CheckQuestStatus
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public CheckQuestStatusNextNode()
		{
			
		}
	}
}
