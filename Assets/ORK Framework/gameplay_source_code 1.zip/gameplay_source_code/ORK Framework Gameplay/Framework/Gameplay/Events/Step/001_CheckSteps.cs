
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Check Chance", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings). If the random number is less or equal to the " +
		"defined chance, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Check Steps")]
	public class CheckChanceStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="Chance")]
		public EventFloat chance = new EventFloat();
		
		public CheckChanceStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.GameSettings.CheckRandom(this.chance.GetValue(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.chance.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Chance Fork", "Which step will be executed next is decided by chance.\n" +
		"he chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"The next step of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Check Steps")]
	public class ChanceForkStep : BaseEventStep
	{
		[ORKEditorArray(false, "Add Range", "Adds a range for the chance check.", "", 
			"Remove", "Removes this range.", "", isCopy=true, isMove=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next step will be executed.", ""
		})]
		public ChanceEventNextNode[] range = new ChanceEventNextNode[] {new ChanceEventNextNode()};
		
		public ChanceForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;
			
			float chance = ORK.GameSettings.GetRandom();
			
			for(int i=0; i<this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, baseEvent))
				{
					check = this.range[i].next;
					break;
				}
			}
			
			baseEvent.StepFinished(check);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " + 
					this.range[index - 1].GetInfoText();
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Check Difficulty", "Checks the game's difficulty.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Check Steps")]
	public class CheckDifficultyStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Difficulty", "Select the difficulty to check for.", "")]
		[ORKEditorInfo(ORKDataType.Difficulty)]
		public int id = 0;
		
		[ORKEditorHelp("Check Type", "Checks if the game's difficulty is equal, not equal, less or greater than the selected difficulty.\n" +
			"The difficulty (level) is determined by the ID of the difficulty, e.g. ID 0 is less than ID 1, ID 3 is greater than ID 2.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;
		
		public CheckDifficultyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckValue(ORK.Game.Difficulty, this.id, this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + ORK.Difficulties.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check Language", "Checks the game's language.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Check Steps")]
	public class CheckLanguageStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Language", "Select the language to check for.", "")]
		[ORKEditorInfo(ORKDataType.Language)]
		public int id = 0;
		
		public CheckLanguageStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.Game.Language == this.id)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Languages.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check User", "Checks if the user is player or computer controlled.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Check Steps")]
	public class CheckUserStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Player Controlled", "The user is controlled by the player.\n" +
			"If disabled, the user is controlled by the computer.", "")]
		[ORKEditorLayout("checkControl", true, endCheckGroup=true)]
		public bool pCon = true;
		
		public CheckUserStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			List<Combatant> list = baseEvent.GetActorCombatant(0);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					c = list[i];
					break;
				}
			}
			
			if(c != null && this.pCon == c.IsPlayerControlled())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.pCon ? "Player Controlled" : "Not Player Controlled";
		}
	}
	
	[ORKEditorHelp("Check Value", "A value (e.g. result of a formula) will be checked with a defined value.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Check Steps")]
	public class CheckValueStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="Value")]
		public EventFloat value = new EventFloat();
		
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public EventFloat checkValue = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat checkValue2;
		
		public CheckValueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckVariableValue(this.value.GetValue(baseEvent), 
				this.checkValue.GetValue(baseEvent), 
				this.checkValue2 != null ? this.checkValue2.GetValue(baseEvent) : 0, 
				this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.value.GetInfoText() + " " + 
				this.check + " " + this.checkValue.GetInfoText() + 
				((VariableValueCheck.RangeInclusive.Equals(this.check) || 
						VariableValueCheck.RangeExclusive.Equals(this.check)) ? 
					" - " + this.checkValue2.GetInfoText() : "");
		}
	}
}
