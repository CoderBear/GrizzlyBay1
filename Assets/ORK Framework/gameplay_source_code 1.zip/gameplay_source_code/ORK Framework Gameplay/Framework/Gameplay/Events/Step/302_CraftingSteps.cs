
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Learn Recipe", "The combatant will learn a crafting recipe.\n" +
		"If group inventory is used, the combatant's group will learn the recipe.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps")]
	public class LearnRecipeStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Learn Crafting Type", "Learn all crafting recipes of a selected crafting type.\n" +
			"If disabled, only a selected crafting recipe will be learned.", "")]
		public bool allType = false;
		
		[ORKEditorHelp("Crafting Type", "Select the crafting type that will be learned.", "")]
		[ORKEditorInfo(ORKDataType.CraftingType)]
		[ORKEditorLayout("allType", true)]
		public int typeID = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe that will be learned.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Show Notification", "The crafting recipe's learning notification will be displayed.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "The crafting recipe's learning text will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public LearnRecipeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.allType)
					{
						list[i].Inventory.Crafting.LearnType(this.typeID, this.showNotification, this.showConsole);
					}
					else
					{
						list[i].Inventory.Crafting.Learn(this.id2, this.showNotification, this.showConsole);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.allType ? 
				ORK.CraftingTypes.GetName(this.typeID) : 
				ORK.CraftingRecipes.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Forget Recipe", "The combatant will forget a crafting recipe.\n" +
		"If group inventory is used, the combatant's group will forget the recipe.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps")]
	public class ForgetRecipeStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Forget All Recipes", "All recipes will be forgotten.\n" +
			"If disabled, only a selected recipe will be forgotten.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Learn Crafting Type", "Learn all crafting recipes of a selected crafting type.\n" +
			"If disabled, only a selected crafting recipe will be learned.", "")]
		[ORKEditorLayout("all", false)]
		public bool allType = false;
		
		[ORKEditorHelp("Crafting Type", "Select the crafting type that will be learned.", "")]
		[ORKEditorInfo(ORKDataType.CraftingType)]
		[ORKEditorLayout("allType", true)]
		public int typeID = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe that will be learned.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int id2 = 0;
		
		[ORKEditorHelp("Show Notification", "The crafting recipe's forgetting notification will be displayed.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "The crafting recipe's forgetting text will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public ForgetRecipeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Inventory.Crafting.Clear();
					}
					else if(this.allType)
					{
						list[i].Inventory.Crafting.ForgetType(this.typeID, this.showNotification, this.showConsole);
					}
					else
					{
						list[i].Inventory.Crafting.Forget(this.id2, this.showNotification, this.showConsole);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? 
				"All Recipes" : 
				(this.allType ? 
					ORK.CraftingTypes.GetName(this.typeID) : 
					ORK.CraftingRecipes.GetName(this.id2));
		}
	}
	
	[ORKEditorHelp("Knows Recipe", "Checks if the combatant knows a crafting recipe.\n" +
		"If group inventory is used, the combatant's group will be checked.\n" +
		"If the combatant knows the recipe, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps", "Check Steps")]
	public class KnowsRecipeStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Any Recipe", "Checks if the combatant knows any recipe at all.\n" +
			"If disabled, the combatant is checked for a defined recipe.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id2 = 0;
		
		public KnowsRecipeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = true;
			bool any = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					any = true;
					if((this.all && !list[i].Inventory.Crafting.HasRecipes()) ||
						(!this.all && !list[i].Inventory.Crafting.Knows(this.id2)))
					{
						check = false;
						break;
					}
				}
			}
			if(any && check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "Any Recipe" : ORK.CraftingRecipes.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Use Recipe", "The combatant will use a crafting recipe.\n" +
		"If the creation is successful, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps")]
	public class UseRecipeStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		public int id2 = 0;
		
		public UseRecipeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool created = false;
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(ORK.CraftingRecipes.Get(this.id2).CreateItem(list[i]))
					{
						created = true;
					}
				}
			}
			if(created)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.CraftingRecipes.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Add Recipe Outcome", "The outcome of a crafting recipe will be added to a combatant's inventory.\n" +
		"This doesn't consume ingredients or checks for requirements or crafting chance.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps")]
	public class AddRecipeOutcomeStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe which's outcome will be added.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		public int id2 = 0;
		
		[ORKEditorHelp("Use Critical Outcome", "Add the critical outcome of the crafting recipe.\n" +
			"If disabled or no critical outcome available, the normal outcome will be used.", "")]
		public bool useCriticalOutcome = false;
		
		[ORKEditorHelp("Show Console", "Adding the outcome will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Adding the outcome will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public AddRecipeOutcomeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			CraftingRecipe recipe = ORK.CraftingRecipes.Get(this.id2);
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Inventory.Add(
						this.useCriticalOutcome && recipe.useCriticalChance ? 
							recipe.critOutcome : recipe.outcome, 
						this.showNotification, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.CraftingRecipes.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Add Needed Ingredients", "The ingredients needed for a crafting recipe will be added to a combatant's inventory.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps")]
	public class AddNeededIngredientsStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe which's needed ingredients will be added.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		public int id2 = 0;
		
		[ORKEditorHelp("Show Console", "Adding the ingredients will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Adding the ingredients will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public AddNeededIngredientsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Inventory.Add(
						ORK.CraftingRecipes.Get(this.id2).GetSummedUpIngredients().ToArray(), 
						this.showNotification, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.CraftingRecipes.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Remove Needed Ingredients", "Removes the ingredients needed for a crafting recipe from a combatant's inventory.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps")]
	public class RemoveNeededIngredientsStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe which's needed ingredients will be removed.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		public int id2 = 0;
		
		[ORKEditorHelp("Show Console", "Removing the ingredients will display a notification.", "")]
		public bool showNotification = true;
		
		[ORKEditorHelp("Show Console", "Removing the ingredients will be displayed in the console.", "")]
		public bool showConsole = true;
		
		public RemoveNeededIngredientsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Inventory.Remove(
						ORK.CraftingRecipes.Get(this.id2).GetSummedUpIngredients().ToArray(), 
						this.showNotification, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.CraftingRecipes.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Can Use Recipe", "Checks if a combatant can use a crafting recipe.\n" +
		"If the combatant can use the recipe, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Crafting Steps", "Check Steps")]
	public class CanUseRecipeStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Crafting Recipe", "Select the crafting recipe that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.CraftingRecipe)]
		public int id2 = 0;
		
		public CanUseRecipeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = true;
			
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(ORK.CraftingRecipes.Get(this.id2).CanCreate(list[i]))
					{
						check = false;
						break;
					}
				}
			}
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.CraftingRecipes.GetName(this.id2);
		}
	}
}
