
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Join Active Group", "A combatant or combatant group joins the active player group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class JoinActiveGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, no one joins the group.", "")]
		public bool actor = false;
		
		// actor
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		// combatant group
		[ORKEditorHelp("Use Combatant Group", "The members of a selected combatant group will join the active player group.\n" +
			"If disable, a single combatant will join the active player group.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool useCombatantGroup = false;
		
		[ORKEditorHelp("Combatant Group", "Select the combatant group that will join the active player group.", "")]
		[ORKEditorInfo(ORKDataType.CombatantGroup)]
		[ORKEditorLayout("useCombatantGroup", true)]
		public int groupID = 0;
		
		// combatant
		[ORKEditorHelp("Combatant", "Select the combatant that will join the active player group.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("From Other Group", "The combatant will be taken from an inactive player group.\n" +
			"If disabled or no group contains the combatant, a new one is created.", "")]
		[ORKEditorInfo(separator=true)]
		public bool otherGroup = false;
		
		[ORKEditorHelp("Set Level", "Set the level of the combatant.\n" +
			"This will ignore the start level setting of the combatant.\n" +
			"That the level will only be set if a new combatant is created.", "")]
		public bool setLevel = false;
		
		[ORKEditorHelp("Level", "The level the combatant will start with.", "")]
		[ORKEditorLayout("setLevel", true, endCheckGroup=true)]
		[ORKEditorLimit(1, false)]
		public int level = 1;
		
		[ORKEditorHelp("Set Class Level", "Set the class level of the combatant.\n" +
			"This will ignore the start class level setting of the combatant.\n" +
			"That the class level will only be set if a new combatant is created.", "")]
		public bool setCLevel = false;
		
		[ORKEditorHelp("Class Level", "The class level the combatant will start with.", "")]
		[ORKEditorLayout("setCLevel", true, endCheckGroup=true, endGroups=3)]
		[ORKEditorLimit(1, false)]
		public int cLevel = 1;
		
		public JoinActiveGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// actor combatant
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						ORK.Game.ActiveGroup.Join(list[i]);
					}
				}
			}
			// combatant group
			else if(this.useCombatantGroup)
			{
				ORK.CombatantGroups.Get(this.groupID).Join(ORK.Game.ActiveGroup);
			}
			// id combatant
			else
			{
				Combatant c = null;
				if(this.otherGroup)
				{
					c = ORK.Game.PlayerHandler.GetMemberFromInactiveGroup(this.id);
				}
				if(c == null)
				{
					c = ORK.Combatants.Create(this.id, ORK.Game.ActiveGroup);
					int lvl = c.Setting.startLevel;
					int cLvl = c.Setting.startClassLevel;
					if(this.setLevel)
					{
						lvl = this.level;
					}
					if(this.setCLevel)
					{
						cLvl = this.cLevel;
					}
					c.Init(lvl, cLvl, c.Setting.startClassID);
				}
				else
				{
					ORK.Game.ActiveGroup.Join(c);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				(this.useCombatantGroup ? 
					ORK.CombatantGroups.GetName(this.groupID) : 
					ORK.Combatants.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Leave Active Group", "A combatant leaves the active player group (and battle group) " +
		"and will join the groups inactive members (or completely removed).", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class LeaveActiveGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, no one leaves the group.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will leave the active group.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("Delete", "The combatant will be deleted, all progress will be lost.\n" +
			"If disabled, the combatant will join the inactive members of the group.", "")]
		public bool delete = false;
		
		[ORKEditorHelp("Destroy Prefab", "If the combatant's prefab is currently " +
			"spawned in the scene, it will be destroyed.\n" +
			"If disabled, the prefab wont be destroyed.", "")]
		public bool destroyPrefab = true;
		
		public LeaveActiveGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.delete)
						{
							ORK.Game.ActiveGroup.Remove(list[i], true, this.destroyPrefab);
						}
						else
						{
							ORK.Game.ActiveGroup.Leave(list[i], this.destroyPrefab);
						}
					}
				}
			}
			else
			{
				if(this.delete)
				{
					ORK.Game.ActiveGroup.Remove(this.id, true, this.destroyPrefab);
				}
				else
				{
					ORK.Game.ActiveGroup.Leave(this.id, this.destroyPrefab);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.delete ? "Delete " : "") +
				(this.actor ? 
					"Actor " + this.id2 : 
					ORK.Combatants.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Is Member", "Checks if a combatant is a member of the active player group.\n" +
		"If the combatant is a member of the group, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps", "Check Steps")]
	public class IsMemberStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("Active Member", "The combatant must be an active member of the group.\n" +
			"If disabled, the combatant must be an inactive member of the group " +
			"(i.e. the combatant has left the group without joining another group).", "")]
		public bool isActive = true;
		
		public IsMemberStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						c = list[i];
						break;
					}
				}
			}
			else
			{
				c = ORK.Game.ActiveGroup.GetMember(this.id);
			}
			
			if(c != null && 
				((this.isActive && ORK.Game.ActiveGroup.IsMember(c)) ||
				(!this.isActive && ORK.Game.ActiveGroup.IsInactive(c))))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.isActive ? "Active " : "Inactive ") +
				(this.actor ? 
					"Actor " + this.id2 : 
					ORK.Combatants.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Check Player", "Checks if a selected combatant or object is the player (leader of the active group).\n" +
		"If the combatant or object is the player, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Active Group Steps", "Check Steps")]
	public class CheckPlayerStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Object", "Check an object (e.g. actor) if it is the player.\n" +
			"If disabled, the player will be checked for a selected combatant.", "")]
		public bool checkObject = false;
		
		
		//object
		[ORKEditorInfo(separator=true, labelText="Check Object")]
		[ORKEditorLayout("checkObject", true, autoInit=true)]
		public EventObjectSetting useObject;
		
		
		// combatant
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public CheckPlayerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool valid = false;
			
			if(this.checkObject)
			{
				List<Combatant> list = this.useObject.GetCombatant(baseEvent);
				
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null && 
						ORK.Game.ActiveGroup.Leader == list[i])
					{
						valid = true;
						break;
					}
				}
			}
			else if(ORK.Game.ActiveGroup.Leader != null && 
				ORK.Game.ActiveGroup.Leader.RealID == this.id)
			{
				valid = true;
			}
			
			if(valid)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkObject ? 
				this.useObject.GetInfoText() : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Set Player", "Sets a combatant as the new player, " +
		"the combatant must be a member (active or inactive) of the active player group, or an actor with a combatant.\n" +
		"If the new player's prefab isn't spawned in the scene, the old player " +
		"will be destroyed and the new spawned at the position of the old player.\n" +
		"If it is already in the scene, the player/camera controls will be " +
		"removed from the old player and added to the new player.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class SetPlayerStep : BaseEventStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used and joins the active player group.\n" +
			"If the actor doesn't have a combatant, no one is set as the new player.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public SetPlayerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						c = list[i];
					}
				}
			}
			else
			{
				c = ORK.Game.ActiveGroup.GetMember(this.id);
			}
			if(c != null)
			{
				ORK.Game.PlayerHandler.SetPlayer(c, false);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Switch Player", "Changes the player to the next or previous member of the player group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class SwitchPlayerStep : BaseEventStep
	{
		[ORKEditorHelp("Previous", "The previous member will be used as player.\n" +
			"If disabled, the next member will be used as player.", "")]
		public bool previous = false;
		
		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be available for switching.", "")]
		public bool onlyBattle = false;
		
		[ORKEditorHelp("Not Dead", "Dead combatants will be ignored, " +
			"i.e. only alive members of the active player group will be used.", "")]
		public bool notDead = false;
		
		public SwitchPlayerStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Control.SwitchMember(this.previous ? -1 : 1, 
				ORK.Game.ActiveGroup.Leader, this.onlyBattle, this.notDead);
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.previous ? "Previous" : "Next") + 
				(this.onlyBattle ? ", Battle Group" : ", Whole Group") + 
				(this.notDead ? ", alive" : "");
		}
	}
	
	[ORKEditorHelp("Set Combatant Name", "Changes the name of a combatant of the active player group or an actor.\n" +
		"Use an empty name field to reset to the default combatant name.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class SetCombatantNameStep : BaseEventStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If disabled, a member (active or inactive) of the active player group is used.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be renamed.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public StringValue value = new StringValue();
		
		public SetCombatantNameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i].SetName(this.value.GetValue());
						break;
					}
				}
			}
			else
			{
				Combatant c = ORK.Game.ActiveGroup.GetMember(this.id);
				if(c != null)
				{
					c.SetName(this.value.GetValue());
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id)) +
				": " + this.value.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Join Battle Group", "A combatant joins the active player battle group.\n" +
		"The combatant also joins the group if he isn't a member of it yet, " +
		"or rejoins the active members if he is an inactive member.\n" +
		"If the combatant doesn't exist, he will be created using the start level/class level settings.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class JoinBattleGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, no one joins the battle group.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will join the battle group.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public JoinBattleGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// actor combatant
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						ORK.Game.ActiveGroup.JoinBattle(list[i]);
					}
				}
			}
			// id/type combatant
			else
			{
				Combatant c = ORK.Game.ActiveGroup.GetMember(this.id);
				if(c == null)
				{
					c = ORK.Combatants.Create(this.id, ORK.Game.ActiveGroup);
					c.Init();
				}
				if(c != null)
				{
					ORK.Game.ActiveGroup.JoinBattle(c);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Leave Battle Group", "A combatant leaves the active player battle group.\n" +
		"The combatant will still remain an active member of the group.\n" +
		"The combatant wont leave the battle group if it's a locked battle member.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class LeaveBattleGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, no one leaves the battle group.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will leave the battle group.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("Destroy Prefab", "If the combatant's prefab is currently " +
			"spawned in the scene, it will be destroyed.\n" +
			"If disabled, the prefab wont be destroyed.", "")]
		public bool destroyPrefab = true;
		
		public LeaveBattleGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// actor combatant
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						ORK.Game.ActiveGroup.LeaveBattle(list[i], this.destroyPrefab);
					}
				}
			}
			// id/type combatant
			else
			{
				Combatant c = ORK.Game.ActiveGroup.GetMember(this.id);
				if(c != null)
				{
					ORK.Game.ActiveGroup.LeaveBattle(c, this.destroyPrefab);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Is Battle Member", "Checks if a combatant is a member of the active battle group.\n" +
		"If the combatant is a member of the battle group, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps", "Check Steps")]
	public class IsBattleMemberStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public IsBattleMemberStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						c = list[i];
						break;
					}
				}
			}
			else
			{
				c = ORK.Game.ActiveGroup.GetMember(this.id);
			}
			if(c != null && ORK.Game.ActiveGroup.IsBattleMember(c))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Lock Battle Member", "Locks or unlocks a battle member.\n" +
		"A locked battle member can't be removed from the battle group.\n" +
		"The combatant already has to be a member of the active battle group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class LockBattleMemberStep : BaseEventStep
	{
		[ORKEditorHelp("Lock/Unlock", "If enabled, the combatant will be locked.\n" +
			"If disabled, the combatant will be unlocked.", "")]
		public bool doLock = false;
		
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, no one will be locked.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be locked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public LockBattleMemberStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// actor combatant
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.doLock)
						{
							ORK.Game.ActiveGroup.LockBattleMember(list[i]);
						}
						else
						{
							ORK.Game.ActiveGroup.UnlockBattleMember(list[i]);
						}
					}
				}
			}
			// id/type combatant
			else
			{
				Combatant c = ORK.Game.ActiveGroup.GetMember(this.id);
				if(c != null)
				{
					if(this.doLock)
					{
						ORK.Game.ActiveGroup.LockBattleMember(c);
					}
					else
					{
						ORK.Game.ActiveGroup.UnlockBattleMember(c);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.doLock ? "Lock " : "Unlock ") + 
				(this.actor ? 
					"Actor " + this.id2 : 
					ORK.Combatants.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Is Locked Battle Member", "Checks if a combatant is a locked battle member of the active player group.\n" +
		"If the combatant is a locked member of the battle group, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps", "Check Steps")]
	public class IsLockedBattleMemberStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public IsLockedBattleMemberStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						c = list[i];
						break;
					}
				}
			}
			else
			{
				c = ORK.Game.ActiveGroup.GetMember(this.id);
			}
			if(c != null && ORK.Game.ActiveGroup.IsLockedBattleMember(c))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Hide Member", "Hides or unhides a combatant of the active player group.\n" +
		"A hidden member can't be seen/used when switching members and can't be a battle member.\n" +
		"The combatant will be removed from the battle group if it currently is in it - " +
		"this also ignores locked battle members.\n" +
		"A hidden member can still be used as the player and run around in the field.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class HideMemberStep : BaseEventStep
	{
		[ORKEditorHelp("Hide/Unhide", "If enabled, the combatant will be hidden.\n" +
			"If disabled, the combatant will be unhidden.", "")]
		public bool doHide = false;
		
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, no one will be hidden.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be hidden.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public HideMemberStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// actor combatant
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.doHide)
						{
							ORK.Game.ActiveGroup.HideMember(list[i]);
						}
						else
						{
							ORK.Game.ActiveGroup.UnhideMember(list[i]);
						}
					}
				}
			}
			// id/type combatant
			else
			{
				Combatant c = ORK.Game.ActiveGroup.GetMember(this.id);
				if(c != null)
				{
					if(this.doHide)
					{
						ORK.Game.ActiveGroup.HideMember(c);
					}
					else
					{
						ORK.Game.ActiveGroup.UnhideMember(c);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.doHide ? "Hide " : "Unhide ") + 
				(this.actor ? 
					"Actor " + this.id2 : 
					ORK.Combatants.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Is Hidden Member", "Checks if a combatant is hidden.\n" +
		"If the combatant is a hidden member of the active player group, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps", "Check Steps")]
	public class IsHiddenMemberStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Use Actor", "The combatant of an actor is used.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		public bool actor = false;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("actor", true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		public IsHiddenMemberStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			if(this.actor)
			{
				List<Combatant> list = baseEvent.GetActorCombatant(this.id2);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						c = list[i];
						break;
					}
				}
			}
			else
			{
				c = ORK.Game.ActiveGroup.GetMember(this.id);
			}
			if(c != null && ORK.Game.ActiveGroup.IsHiddenMember(c))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.actor ? 
				"Actor " + this.id2 : 
				ORK.Combatants.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Check Group Size", "Checks if the size of the active player group.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Active Group Steps", "Check Steps")]
	public class CheckGroupSizeStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Only Battle Group", "The size of the battle group will be checked.\n" +
			"If disabled, the size of the group (i.e. all members) will be checked.", "")]
		public bool onlyBattle = false;
		
		[ORKEditorHelp("Check Type", "Checks if the active group size is equal, not equal, " +
			"less or greater than a defined value.", "")]
		public ValueCheck check = ValueCheck.IsEqual;
		
		
		// value
		[ORKEditorInfo(separator=true, labelText="Group Size")]
		public EventFloat value = new EventFloat();
		
		public CheckGroupSizeStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckValue(
				this.onlyBattle ? ORK.Game.ActiveGroup.BattleSize : ORK.Game.ActiveGroup.Size, 
				this.value.GetValue(baseEvent), this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.onlyBattle ? "(Battle) " : "") + 
				this.check.ToString() + " " + 
				this.value.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Spawn Group Members", "Spawns the other members of the active player group (or battle group).\n" +
		"The members are spawned around the player, you can use 'Member' actors to place them afterwards.\n" +
		"Requires the player to already be spawned in the scene.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class SpawnGroupMembersStep : BaseEventStep
	{
		[ORKEditorHelp("Battle Group", "Only the battle group will be spawned.\n" +
			"If disabled, all members of the active player group will be spawned.", "")]
		public bool battleGroup = true;
		
		[ORKEditorHelp("Respawn", "Already spawned members of the group will be respawned.\n" +
			"If disabled, only not yet spawned members will be spawned.", "")]
		public bool respawnCreated = false;
		
		public SpawnGroupMembersStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.Game.ActiveGroup.Leader != null && 
				ORK.Game.ActiveGroup.Leader.GameObject != null)
			{
				ORK.Game.ActiveGroup.SpawnGroup(this.battleGroup, !this.respawnCreated);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.battleGroup ? "Battle Group" : "Whole Group") + 
				(this.respawnCreated ? ", respawn" : "");
		}
	}
	
	[ORKEditorHelp("Destroy Group Members", "Destroys all spawned members of the active player group except the player.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Active Group Steps")]
	public class DestroyGroupMembersStep : BaseEventStep
	{
		public DestroyGroupMembersStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.ActiveGroup.DestroySpawnedGroup();
			baseEvent.StepFinished(this.next);
		}
	}
}
