
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Add To Bestiary", "Adds a combatant's entry to the bestiary.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class AddToBestiaryStep : BaseEventStep
	{
		[ORKEditorHelp("Complete Entry", "A complete entry (i.e. with all status information) will be added to the bestiary.\n" +
			"If disabled, only a blank entry (i.e. without status information) will be added.", "")]
		public bool complete = false;
		
		[ORKEditorHelp("Ignore Not Scanable", "The combatant's 'Not Scanable' setting will be ignored.", "")]
		public bool ignoreNotScanable = false;
		
		[ORKEditorHelp("Ignore No Entry", "The combatant's 'No Bestiary Entry' setting will be ignored.", "")]
		public bool ignoreNoEntry = false;
		
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, nothing will be added to the bestiary.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		
		// areas
		[ORKEditorHelp("Current Area", "The current area will be used when adding the bestiary entry.\n" +
			"If disabled, you can define areas that will be used.\n" +
			"Bestiary entries can be separated by areas in menu screens - " +
			"when encountering an enemy, the current area will be added to combatant's entry.", "")]
		[ORKEditorInfo(separator=true, labelText="Area Settings")]
		public bool currentArea = true;
		
		[ORKEditorHelp("Area", "Select the area the combatant's bestiary will be available in.", "")]
		[ORKEditorInfo(ORKDataType.Area, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Area", "Adds an area to the bestiary entry.", "", 
			"Remove", "Removes this area.", "", isHorizontal=true)]
		[ORKEditorLayout("currentArea", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] areaID;
		
		public AddToBestiaryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					if(this.complete)
					{
						ORK.Game.Bestiary.SetComplete(list[i], 
							this.currentArea ? new int[] {ORK.Game.AreaID} : this.areaID, 
							this.ignoreNotScanable, this.ignoreNoEntry);
					}
					else
					{
						ORK.Game.Bestiary.AddBlank(list[i], 
							this.currentArea ? new int[] {ORK.Game.AreaID} : this.areaID, 
							this.ignoreNoEntry);
					}
				}
			}
			else
			{
				this.entry.Add(this.complete, 
					this.currentArea ? new int[] {ORK.Game.AreaID} : this.areaID, 
					this.ignoreNotScanable, this.ignoreNoEntry);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.complete ? "Complete: " : "") + 
				(this.useObject ? 
					this.usedObject.GetInfoText() : 
					ORK.Combatants.GetName(this.entry.combatantID));
		}
	}
	
	[ORKEditorHelp("Remove From Bestiary", "Removes a combatant's entry from the bestiary.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class RemoveFromBestiaryStep : BaseEventStep
	{
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, nothing will be removed from the bestiary.", "")]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		public RemoveFromBestiaryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					ORK.Game.Bestiary.Remove(list[i]);
				}
			}
			else
			{
				this.entry.Remove();
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject ? 
				this.usedObject.GetInfoText() : 
				ORK.Combatants.GetName(this.entry.combatantID);
		}
	}
	
	[ORKEditorHelp("Check Bestiary", "Checks if a combatant's entry is in the bestiary.\n" +
		"If the entry is found, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class CheckBestiaryStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Complete Entry", "The combatant's entry must be complete (i.e. all status information known).\n" +
			"If disabled, the combatant only needs to have an entry in the bestiary.", "")]
		public bool isComplete = false;
		
		// object
		[ORKEditorHelp("Use Object", "Use an event object (e.g. actor) for the combatant.\n" +
			"If the object doesn't have a combatant, 'Failed' will be executed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useObject = false;
		
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting usedObject;
		
		[ORKEditorHelp("All Combatants", "All combatants must be checked valid.\n" +
			"If disabled, a single combatant's valid check results in 'Success'.", "")]
		public bool allCombatants = false;
		
		
		// combatant
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public BestiaryLearnSetting entry = new BestiaryLearnSetting();
		
		public CheckBestiaryStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool found = false;
			if(this.useObject)
			{
				List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					if(this.isComplete)
					{
						found = ORK.Game.Bestiary.IsComplete(list[i]);
					}
					else
					{
						found = ORK.Game.Bestiary.IsKnown(list[i]);
					}
					
					if(found && !this.allCombatants)
					{
						break;
					}
					else if(!found && this.allCombatants)
					{
						break;
					}
				}
			}
			else
			{
				if(this.isComplete)
				{
					found = this.entry.IsComplete();
				}
				else
				{
					found = this.entry.IsKnown();
				}
			}
			
			if(found)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.isComplete ? "Complete: " : "") + 
				(this.useObject ? 
					this.usedObject.GetInfoText() : 
					ORK.Combatants.GetName(this.entry.combatantID));
		}
	}
	
	[ORKEditorHelp("Bestiary Dialogue", "Displays a dialogue with bestiary information of a selected game object or combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Bestiary Steps", "Dialogue Steps")]
	public class BestiaryDialogueStep : BaseEventStep
	{
		public BestiaryChoice dialogue = new BestiaryChoice();
		
		public BestiaryDialogueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.dialogue.Show(baseEvent, this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.dialogue.useObject ? 
					this.dialogue.usedObject.GetInfoText() : 
					ORK.Combatants.GetName(this.dialogue.entry.combatantID);
		}
	}
	
	[ORKEditorHelp("Check Bestiary Count", "Checks the number entries added to the bestiary.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Bestiary Steps")]
	public class CheckBestiaryCountStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the count is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the count is between two defind values, including the values.\n" +
			"Range exclusive checks if the count is between two defined values, excluding the values.\n" +
			"Approximately checks if the count is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public EventFloat value = new EventFloat();
		
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat value2;
		
		public CheckBestiaryCountStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckVariableValue(ORK.Game.Bestiary.Count, 
				this.value.GetValue(baseEvent), 
				this.value2 != null ? this.value2.GetValue(baseEvent) : 0, 
				this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText() + 
				(this.value2 != null ? " ~ " + this.value2.GetInfoText() : "");
		}
	}
	
	[ORKEditorHelp("Bestiary Count To Variable", "Stores the number of bestiary entries into a float game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Bestiary Steps", "Variable Steps")]
	public class BestiaryCountToVariableStep : BaseEventCheckStep
	{
		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;
		
		public BestiaryCountToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(VariableOrigin.Local.Equals(this.origin))
			{
				baseEvent.Variables.ChangeFloat(this.key.GetValue(), 
					ORK.Game.Bestiary.Count, this.floatOperator);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				ORK.Game.Variables.ChangeFloat(this.key.GetValue(), 
					ORK.Game.Bestiary.Count, this.floatOperator);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list2 = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list2.Count; i++)
					{
						if(list2[i] != null)
						{
							ObjectVariablesComponent[] comps = list2[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								comps[j].GetHandler().ChangeFloat(
									this.key.GetValue(), ORK.Game.Bestiary.Count, this.floatOperator);
							}
						}
					}
				}
				else
				{
					ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeFloat(
						this.key.GetValue(), ORK.Game.Bestiary.Count, this.floatOperator);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + 
				this.floatOperator.ToString() + " " + key.GetInfoText();
		}
	}
}
