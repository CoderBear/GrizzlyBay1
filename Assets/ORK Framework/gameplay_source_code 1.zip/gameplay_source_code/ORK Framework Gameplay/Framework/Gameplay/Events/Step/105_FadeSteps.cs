
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Fade Object", "Fades a game object's color (and alpha) over time.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Fade Steps")]
	public class FadeObjectStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Fading Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between fading two objects.\n" +
			"Only used if greater than 0 and more than one object will be faded.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start fading before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// fade
		[ORKEditorInfo(separator=true, labelText="Fade Settings")]
		[ORKEditorHelp("Wait", "Wait until fading has finished before the next step is executed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Fade Children", "All child game objects of the target will be faded.", "")]
		public bool fadeChildren = true;
		
		[ORKEditorHelp("Flash", "The game object will be flashed, not faded - " +
			"i.e. half of the time is used to fade to the set color values, " +
			"half of the time to fade back.", "")]
		public bool flash = false;
		
		[ORKEditorHelp("Set Property", "Define the name of the property that will be faded.\n" +
			"If disabled, the '_Color' property for fading the color is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool setProp = false;
		
		[ORKEditorHelp("Property Name", "The name of the property that will be faded.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("setProp", true)]
		public string prop = "";
		
		[ORKEditorHelp("Is Float", "The property that will be faded is a float value instead of a color.\n" +
			"Only the alpha value of the fade settings is used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool isFloat = false;
		
		[ORKEditorInfo(separator=true)]
		public FadeColorSettings color = new FadeColorSettings();
		
		[ORKEditorHelp("Shared Material", "The shared material is changed instead of the renderer's material.\n" +
			"Using shared materials will change this material in the project!\n" +
			"All objects using this material will be changed.", "")]
		[ORKEditorInfo(separator=true)]
		public bool shared = false;
		
		
		// audio options
		[ORKEditorHelp("Play Audio", "Play an audio clip when fading the object.\n" +
			"The clip will be played on the object.", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Options")]
		public bool useAudio = false;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=3)]
		[ORKEditorLayout("useAudio", true)]
		public int id2 = 0;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public PlayAudioSettings audio;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public FadeObjectStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
		
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				string mat = "_Color";
				bool iflo = false;
				if(this.setProp)
				{
					mat = this.prop;
					iflo = this.isFloat;
				}
				EventFader fader = ComponentHelper.Get<EventFader>(this.list[this.index]);
				if(this.useAudio)
				{
					AudioClip clip = baseEvent.GetAudioClip(this.id2);
					if(clip != null)
					{
						this.audio.PlayAudio(this.list[this.index], clip);
					}
				}
				if(this.flash)
				{
					fader.Flash(this.color, this.fadeChildren, this.shared, mat, iflo);
				}
				else
				{
					fader.Fade(this.color, this.fadeChildren, this.shared, mat, iflo);
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait)
					{
						baseEvent.StartTime(this.color.time, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.color.time + "s" + (this.wait ? " (wait)" : "");
		}
	}
	
	[ORKEditorHelp("Blink Object", "Starts or stops blinking a game object's color (and alpha) over time.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Fade Steps")]
	public class BlinkObjectStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Blinking Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between blinking two objects.\n" +
			"Only used if greater than 0 and more than one object will be blinked.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for all objects to start blinking before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;
		
		
		// fade
		[ORKEditorHelp("Start Blinking", "If enbled, the object will start blinking.\n" +
			"If disabled, the object will stop blinking.", "")]
		[ORKEditorInfo(separator=true, labelText="Blink Settings")]
		public bool start = false;
		
		[ORKEditorHelp("Blink Children", "All child game objects of the target will be blinked.", "")]
		[ORKEditorLayout("start", true)]
		public bool fadeChildren = true;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FadeColorSettings color;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		public BlinkObjectStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.onObject.GetObject(baseEvent);
			this.index = 0;
		
			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);
				
				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				EventFader fader = ComponentHelper.Get<EventFader>(this.list[this.index]);
				
				if(this.start)
				{
					fader.Blink(this.color, this.fadeChildren);
				}
				else
				{
					fader.StopBlink();
				}
			}
			
			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.start ? "Start" : "Stop";
		}
	}
	
	[ORKEditorHelp("Fade Screen", "Fades the screen.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Fade Steps")]
	public class FadeScreenStep : BaseEventStep
	{
		[ORKEditorHelp("Wait", "Wait until fading has finished before the next step is executed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Flash Screen", "The screen will be flashed, not faded - " +
			"i.e. half of the time is used to fade to the set color values, " +
			"half of the time to fade back.", "")]
		public bool flash = false;
		
		[ORKEditorInfo(separator=true)]
		public FadeColorSettings color = new FadeColorSettings();
		
		public FadeScreenStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.flash)
			{
				ORK.ScreenFader.FlashScreen(this.color);
			}
			else
			{
				ORK.ScreenFader.FadeScreen(this.color);
			}
			if(this.wait)
			{
				baseEvent.StartTime(this.color.time, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.color.time + "s" + (this.wait ? " (wait)" : "");
		}
	}
}
