
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Events
{
	public class EventPrefab : BaseData
	{
		[ORKEditorHelp("Prefab", "Select the prefab you want to use.", "")]
		public GameObject prefab;
		
		private List<GameObject> spawnedPrefabs = new List<GameObject>();
		
		public EventPrefab()
		{
			
		}
		
		public void Clear()
		{
			this.spawnedPrefabs = new List<GameObject>();
		}
		
		
		/*
		============================================================================
		Object functions
		============================================================================
		*/
		public void SetPrefab(GameObject obj)
		{
			this.prefab = obj;
		}
		
		public GameObject GetPrefab()
		{
			return this.prefab;
		}
		
		public GameObject SpawnPrefab(Vector3 position, Vector3 rotation)
		{
			this.GetPrefab();
			if(this.prefab != null)
			{
				GameObject obj = GameObject.Instantiate(this.prefab, 
					position, Quaternion.Euler(rotation)) as GameObject;
				this.spawnedPrefabs.Add(obj);
				return obj;
			}
			return null;
		}
		
		public void DestroyPrefab(int index, float time)
		{
			if(index == -1)
			{
				for(int i=0; i<this.spawnedPrefabs.Count; i++)
				{
					if(this.spawnedPrefabs[i] != null)
					{
						if(time > 0)
						{
							GameObject.Destroy(this.spawnedPrefabs[i], time);
						}
						else
						{
							GameObject.Destroy(this.spawnedPrefabs[i]);
						}
					}
				}
				this.spawnedPrefabs = new List<GameObject>();
			}
			else
			{
				if(index >= 0 && index < this.spawnedPrefabs.Count)
				{
					GameObject.Destroy(this.spawnedPrefabs[index]);
					this.spawnedPrefabs.RemoveAt(index);
				}
			}
		}
		
		public List<GameObject> GetSpawnedPrefab(int index)
		{
			if(index == -1)
			{
				return this.spawnedPrefabs;
			}
			else
			{
				List<GameObject> list = new List<GameObject>();
				if(index >= 0 && index < this.spawnedPrefabs.Count)
				{
					list.Add(this.spawnedPrefabs[index]);
				}
				return list;
			}
		}
	}
}

