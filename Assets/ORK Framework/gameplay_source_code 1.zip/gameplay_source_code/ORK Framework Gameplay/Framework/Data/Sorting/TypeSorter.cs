
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeSorter : BaseData
	{
		[ORKEditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data are sorted by name.\n" +
			"- ID: The data are sorted by ID (i.e. the index of the data).", "")]
		public TypeSorting sorting = TypeSorting.Name;
		
		[ORKEditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;
		
		public TypeSorter()
		{
			
		}
		
		public void Sort(ref List<int> list, ORKDataType type)
		{
			if(TypeSorting.None.Equals(this.sorting))
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(TypeSorting.Name.Equals(this.sorting))
			{
				if(ORKDataType.AbilityType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.AbilityTypes.GetName, this.invert));
				}
				else if(ORKDataType.AreaType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.AreaTypes.GetName, this.invert));
				}
				else if(ORKDataType.FormulaType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.FormulaTypes.GetName, this.invert));
				}
				else if(ORKDataType.CraftingType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.CraftingTypes.GetName, this.invert));
				}
				else if(ORKDataType.ItemType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.ItemTypes.GetName, this.invert));
				}
				else if(ORKDataType.LogType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.LogTypes.GetName, this.invert));
				}
				else if(ORKDataType.EquipmentPart.Equals(type))
				{
					list.Sort(new NameSorter(ORK.EquipmentParts.GetName, this.invert));
				}
				else if(ORKDataType.Faction.Equals(type))
				{
					list.Sort(new NameSorter(ORK.Factions.GetName, this.invert));
				}
				else if(ORKDataType.SceneObjectType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.SceneObjectTypes.GetName, this.invert));
				}
				else if(ORKDataType.QuestType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.QuestTypes.GetName, this.invert));
				}
				else if(ORKDataType.PortraitType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.PortraitTypes.GetName, this.invert));
				}
				else if(ORKDataType.SoundType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.SoundTypes.GetName, this.invert));
				}
				else if(ORKDataType.AnimationType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.AnimationTypes.GetName, this.invert));
				}
				else if(ORKDataType.DamageType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.DamageTypes.GetName, this.invert));
				}
				else if(ORKDataType.ConsoleType.Equals(type))
				{
					list.Sort(new NameSorter(ORK.ConsoleTypes.GetName, this.invert));
				}
			}
			else if(TypeSorting.ID.Equals(this.sorting))
			{
				list.Sort(new IDSorter());
			}
		}
	}
}
