
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeIDContentSorter : IComparer<IContent>
	{
		private bool invert = false;
		
		public TypeIDContentSorter(bool invert)
		{
			this.invert = invert;
		}
		
		public int Compare(IContent x, IContent y)
		{
			if(this.invert)
			{
				int tmp = y.TypeID.CompareTo(x.TypeID);
				if(tmp == 0)
				{
					return y.ID.CompareTo(x.ID);
				}
				else
				{
					return tmp;
				}
			}
			else
			{
				int tmp = x.TypeID.CompareTo(y.TypeID);
				if(tmp == 0)
				{
					return x.ID.CompareTo(y.ID);
				}
				else
				{
					return tmp;
				}
			}
		}
	}
}
