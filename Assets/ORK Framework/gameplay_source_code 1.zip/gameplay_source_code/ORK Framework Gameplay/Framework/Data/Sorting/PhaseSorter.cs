
using System.Collections.Generic;

namespace ORKFramework
{
	public class PhaseSorter : IComparer<KeyValuePair<int, float>>
	{
		public int Compare(KeyValuePair<int, float> x , KeyValuePair<int, float> y)
		{
	        if(x.Value < y.Value)
			{
				return 1;
			}
			else if(x.Value > y.Value)
			{
				return -1;
			}
			else
			{
				return 0;
			}
	    } 
	}
}
