
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IContentSimple
	{
		int ID
		{
			get;
		}
		
		string GetName();
		
		string GetDescription();
		
		string GetIconTextCode();
		
		Texture GetIcon();
		
		GUIContent GetContent();
	}
}
