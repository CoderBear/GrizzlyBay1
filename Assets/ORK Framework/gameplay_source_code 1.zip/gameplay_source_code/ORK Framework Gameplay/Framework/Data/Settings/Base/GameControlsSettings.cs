
using UnityEngine;
using System.Collections.Generic;
using ORKFramework.Behaviours;

namespace ORKFramework
{
	public class GameControlsSettings : BaseSettings
	{
		// cursor and clicks
		[ORKEditorHelp("Cursor Timeout (s)", "The time in seconds that has to pass " +
			"between 2 cursor moves (e.g. choice selection).", "")]
		[ORKEditorInfo("Base Key Settings", "Set the base game controls.", "")]
		public float cursorTimeout = 0.25f;
		
		[ORKEditorHelp("Click Timeout (s)", "The time in seconds to recognize multi-clicks.\n" +
			"If another click/touch happens within the timeout, it will be recognized " +
			"as a multi-click (e.g. double click).", "")]
		public float clickTimeout = 0.2f;
		
		
		// base controls
		[ORKEditorHelp("Accept Key", "The key used to accept selections (e.g. choice dialogues, battle menu, etc.).", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, labelText="Base Keys")]
		public int acceptKey = 3;
		
		[ORKEditorHelp("Cancel Key", "The key used to cancel selections or return to previous selections " +
			"(e.g. return from target selection in battle menus).", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int cancelKey = 4;
		
		[ORKEditorHelp("Vertical Axis", "The key used to move the menu cursor vertically.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int verticalAxis = 2;
		
		[ORKEditorHelp("Horizontal Axis", "The key used to move the menu cursor horizontally.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int horizontalAxis = 1;
		
		
		// pause
		[ORKEditorHelp("Pause Key", "The key used to pause and unpause the game.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true, labelText="Pause Settings")]
		public int pauseKey = 0;
		
		[ORKEditorHelp("Pause Time", "The game time (play time) will pause when the game is paused.", "")]
		public bool pauseTime = false;
		
		[ORKEditorHelp("Freeze Pause", "The game freezes in pause, i.e. animations, movements, etc. will stop.", "")]
		public bool freezePause = false;
		
		
		// member switch settings
		[ORKEditorHelp("Plus Key", "The key used to change to the next member of the player group.\n" +
			"Can be used to change to another group member's battle menu (if available) or switch the player.", "")]
		[ORKEditorInfo("Group Member Keys", "You can use input keys to change the player " +
			"or switch to another group members battle menu.", "", 
			isPopup=true, popupType=ORKDataType.InputKey)]
		public int memberPlusKey = 0;
		
		[ORKEditorHelp("Minus Key", "The key used to change to the previous member of the player group.\n" +
			"Can be used to change to another group member's battle menu (if available) or switch the player.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int memberMinusKey = 0;
		
		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be available for switching.", "")]
		public bool switchOnlyBattle = false;
		
		[ORKEditorHelp("Not Dead", "Dead combatants will be ignored, " +
			"i.e. only alive members of the active player group will be used.", "")]
		public bool switchNotDead = false;
		
		// change player
		[ORKEditorHelp("Switch Player", "The plus/minus keys will switch the player from " +
			"one group member to the other.\n" +
			"If your party isn't spawned in the field, the current player object will be " +
			"replaced with the new player.\n" +
			"A combatant with 'Not Controllable' enabled can't be switched to.", "")]
		[ORKEditorInfo(separator=true, labelText="Change Player")]
		public bool switchPlayer = false;
		
		[ORKEditorHelp("Field", "The player can be changed in the field (i.e. outside of battles).", "")]
		[ORKEditorLayout("switchPlayer", true)]
		public bool switchField = true;
		
		[ORKEditorHelp("Turn Based", "The player can be changed in 'Turn Based' battles.", "")]
		public bool switchTurnBased = false;
		
		[ORKEditorHelp("Active Time", "The player can be changed in 'Active Time' battles.", "")]
		public bool switchActiveTime = false;
		
		[ORKEditorHelp("Real Time", "The player can be changed in 'Real Time' battles.", "")]
		public bool switchRealTime = true;
		
		[ORKEditorHelp("Phase", "The player can be changed in 'Phase' battles.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool switchPhase = false;
		
		// change menu user
		[ORKEditorHelp("Switch Menu User", "The plus/minus keys will switch the current battle menu user.\n" +
			"This is only possible when more than one battle menu is displayed " +
			"(i.e. also only in 'Active Time' and 'Real Time' battles).", "")]
		[ORKEditorInfo(separator=true, labelText="Change Menu User")]
		public bool switchMenuUser = false;
		
		[ORKEditorHelp("Active Time", "The menu user can be changed in 'Active Time' battles.", "")]
		[ORKEditorLayout("switchMenuUser", true)]
		public bool switchMenuActiveTime = false;
		
		[ORKEditorHelp("Real Time", "The menu user can be changed in 'Real Time' battles.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool switchMenuRealTime = true;
		
		
		// ability level changes
		[ORKEditorHelp("Plus Key", "The key to be used to increase the level of a currently selected ability.\n" +
			"Can be done in the battle menu or ability menu screens.\n" +
			"The ability level keys are used to circle through already learned ability levels.", "")]
		[ORKEditorInfo("Ability Level Keys", "You can use input keys to change " +
			"the used level of a currently selected ability.", "", 
			isPopup=true, popupType=ORKDataType.InputKey)]
		public int abilityPlusKey = 0;
		
		[ORKEditorHelp("Minus Key", "The key to be used to decrease the level of a currently selected ability.\n" +
			"Can be done in the battle menu or ability menu screens.\n" +
			"The ability level keys are used to circle through already learned ability levels.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int abilityMinusKey = 0;
		
		[ORKEditorHelp("Loop Levels", "The ability level changes will loop when at the end " +
			"(level 1 or currently learned maximum level).", "")]
		[ORKEditorInfo(endFoldout=true, endFolds=2)]
		public bool loopAbilityLevels = false;
		
		
		// components and interactions
		// player components
		[ORKEditorHelp("Component Name", "The name of the component.\n" +
			"This component will be automatically added to the player when spawned.\n" +
			"If the player is changed, the component will be removed from the old player and added to the new one.", "")]
		[ORKEditorInfo("Player Components/Interaction", "Automatically add components and an interaction controller to the player.", "", 
			expandWidth=true, labelText="Player Component Settings")]
		[ORKEditorArray(false, "Add Component", "Adds a component to the player.\n" +
			"This component will be automatically added to the player when spawned.", "", 
			"Remove", "Removes this component.", "", isHorizontal=true)]
		public string[] playerComponent = new string[0];
		
		// interaction controller
		[ORKEditorHelp("Add Automatically", "The interaction controller is automatically added to the player." +
			"If disabled, you need to manually add an interaction controller to the prefab of the player.", "")]
		[ORKEditorInfo(separator=true, labelText="Interaction Controller")]
		public bool addIC = false;
		
		[ORKEditorHelp("IC Prefab", "The prefab used as interaction controller.", "")]
		[ORKEditorLayout("addIC", true)]
		public GameObject icPrefab;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings icMount = new MountSettings();
		
		
		// player controls
		[ORKEditorInfo("Player Controls", "ORK can automatically add controls to your player when spawned.\n" +
			"When the player is changed during the game, the controls will be removed from the " +
			"old player and added to the new one.", "", endFoldout=true)]
		public PlayerControlSettings playerControl = new PlayerControlSettings();
		
		
		// camera controls
		[ORKEditorInfo("Camera Controls", "ORK can automatically add camera controls to your scene's main camera.\n" +
			"If you don't want to automatically add camera control in a scene, " +
			"simply add a NoCameraControl component to the camera.", "", endFoldout=true)]
		public CameraControlSettings cameraControl = new CameraControlSettings();
		
		
		// custom controls
		[ORKEditorInfo("Custom Controls", "ORK can automatically add/find custom controls to the player or main camera.\n" +
			"Use custom controls to implement your own control scripts into ORK's control block system.", "", endFoldout=true)]
		public CustomControlSettings customControl = new CustomControlSettings();
		
		public GameControlsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(!data.Contains<DataObject>("customControl"))
			{
				List<ControlBehaviour> list = new List<ControlBehaviour>();
				
				DataObject tmpData = data.GetFile("playerControl");
				if(tmpData != null)
				{
					DataObject[] pc = tmpData.GetFileArray("behaviours");
					if(pc != null)
					{
						for(int i=0; i<pc.Length; i++)
						{
							ControlBehaviour con = new ControlBehaviour();
							con.SetData(pc[i]);
							list.Add(con);
						}
					}
				}
				
				tmpData = data.GetFile("cameraControl");
				if(tmpData != null)
				{
					DataObject[] cc = tmpData.GetFileArray("behaviours");
					if(cc != null)
					{
						for(int i=0; i<cc.Length; i++)
						{
							ControlBehaviour con = new ControlBehaviour();
							con.SetData(cc[i]);
							con.blockType = CustomControlType.Camera;
							con.objectType = CustomControlType.Camera;
							list.Add(con);
						}
					}
				}
				this.customControl.behaviours = list.ToArray();
			}
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "gameControls"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		
		/*
		============================================================================
		Player components functions
		============================================================================
		*/
		public void AddPlayerComponents(Combatant c)
		{
			if(c != null && c.GameObject != null)
			{
				this.playerControl.AddPlayerControl(c.GameObject);
				for(int i=0; i<this.playerComponent.Length; i++)
				{
					Component comp = ComponentHelper.Get(c.GameObject, this.playerComponent[i]);
					if(comp == null)
					{
						ComponentHelper.Add(c.GameObject, this.playerComponent[i]);
					}
				}
			}
		}
		
		public void RemovePlayerComponents(Combatant c)
		{
			if(c != null && c.GameObject != null)
			{
				this.playerControl.RemovePlayerControl(c.GameObject);
				for(int i=0; i<this.playerComponent.Length; i++)
				{
					Component comp = ComponentHelper.Get(c.GameObject, this.playerComponent[i]);
					if(comp != null)
					{
						GameObject.Destroy(comp);
					}
				}
			}
		}

		public void AddInteractionController(GameObject player)
		{
			if(this.addIC && player != null && this.icPrefab != null && 
				player.GetComponentInChildren<InteractionController>() == null)
			{
				GameObject ic = (GameObject)GameObject.Instantiate(this.icPrefab);
				if(ic != null)
				{
					this.icMount.MountTo(player.transform, ic.transform);
				}
			}
		}
	}
}

