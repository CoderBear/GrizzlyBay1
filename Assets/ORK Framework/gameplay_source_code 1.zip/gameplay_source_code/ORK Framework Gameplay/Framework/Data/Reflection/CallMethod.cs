
using UnityEngine;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class CallMethod : BaseData
	{
		[ORKEditorHelp("Function Name", "The name of the function that will be called.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string functionName = "";
		
		// parameters
		[ORKEditorArray(false, "Add Parameter", "Adds a parameter that will be used when calling the function.", "", 
			"Remove", "Removes this parameter.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {"Parameter", "The parameter will be used when calling the function.", ""})]
		public CallParameter[] parameter = new CallParameter[0];
		
		public CallMethod()
		{
			
		}
		
		public bool Call(System.Object instance)
		{
			if(instance != null && this.functionName != "")
			{
				if(this.parameter.Length > 0)
				{
					System.Type[] types = new System.Type[this.parameter.Length];
					System.Object[] values = new System.Object[this.parameter.Length];
					
					for(int i=0; i<this.parameter.Length; i++)
					{
						if(ParameterType.String.Equals(this.parameter[i].type))
						{
							types[i] = typeof(string);
							values[i] = this.parameter[i].stringValue;
						}
						else if(ParameterType.Bool.Equals(this.parameter[i].type))
						{
							types[i] = typeof(bool);
							values[i] = this.parameter[i].boolValue;
						}
						else if(ParameterType.Int.Equals(this.parameter[i].type))
						{
							types[i] = typeof(int);
							values[i] = this.parameter[i].intValue;
						}
						else if(ParameterType.Float.Equals(this.parameter[i].type))
						{
							types[i] = typeof(float);
							values[i] = this.parameter[i].floatValue;
						}
						else if(ParameterType.Vector2.Equals(this.parameter[i].type))
						{
							types[i] = typeof(Vector2);
							values[i] = this.parameter[i].vector2Value;
						}
						else if(ParameterType.Vector3.Equals(this.parameter[i].type))
						{
							types[i] = typeof(Vector3);
							values[i] = this.parameter[i].vector3Value;
						}
					}
					
					MethodInfo methodInfo = instance.GetType().GetMethod(this.functionName, types);
					if(methodInfo != null)
					{
						try
						{
							methodInfo.Invoke(instance, values);
							return true;
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + instance.GetType() + "): " + 
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + instance.GetType() + "): " + this.functionName);
					}
				}
				else
				{
					MethodInfo methodInfo = instance.GetType().GetMethod(this.functionName, new System.Type[] {});
					if(methodInfo != null)
					{
						try
						{
							methodInfo.Invoke(instance, null);
							return true;
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + instance.GetType() + "): " + 
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + instance.GetType() + "): " + this.functionName);
					}
				}
			}
			return false;
		}
		
		public bool CallStatic(string className)
		{
			if(className != "" && this.functionName != "")
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(className);
				if(classType != null)
				{
					if(this.parameter.Length > 0)
					{
						System.Type[] types = new System.Type[this.parameter.Length];
						System.Object[] values = new System.Object[this.parameter.Length];
						
						for(int i=0; i<this.parameter.Length; i++)
						{
							if(ParameterType.String.Equals(this.parameter[i].type))
							{
								types[i] = typeof(string);
								values[i] = this.parameter[i].stringValue;
							}
							else if(ParameterType.Bool.Equals(this.parameter[i].type))
							{
								types[i] = typeof(bool);
								values[i] = this.parameter[i].boolValue;
							}
							else if(ParameterType.Int.Equals(this.parameter[i].type))
							{
								types[i] = typeof(int);
								values[i] = this.parameter[i].intValue;
							}
							else if(ParameterType.Float.Equals(this.parameter[i].type))
							{
								types[i] = typeof(float);
								values[i] = this.parameter[i].floatValue;
							}
							else if(ParameterType.Vector2.Equals(this.parameter[i].type))
							{
								types[i] = typeof(Vector2);
								values[i] = this.parameter[i].vector2Value;
							}
							else if(ParameterType.Vector3.Equals(this.parameter[i].type))
							{
								types[i] = typeof(Vector3);
								values[i] = this.parameter[i].vector3Value;
							}
						}
						
						MethodInfo methodInfo = classType.GetMethod(this.functionName, types);
						if(methodInfo != null)
						{
							try
							{
								methodInfo.Invoke(null, values);
								return true;
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Method call failed (" + classType + "): " + 
									this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
						}
					}
					else
					{
						MethodInfo methodInfo = classType.GetMethod(this.functionName, new System.Type[] {});
						if(methodInfo != null)
						{
							try
							{
								methodInfo.Invoke(null, null);
								return true;
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Method call failed (" + classType + "): " + 
									this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
						}
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + className);
				}
			}
			return false;
		}
		
		public System.Object GetReturnValue(System.Object instance)
		{
			if(instance != null && this.functionName != "")
			{
				if(this.parameter.Length > 0)
				{
					System.Type[] types = new System.Type[this.parameter.Length];
					System.Object[] values = new System.Object[this.parameter.Length];
					
					for(int i=0; i<this.parameter.Length; i++)
					{
						if(ParameterType.String.Equals(this.parameter[i].type))
						{
							types[i] = typeof(string);
							values[i] = this.parameter[i].stringValue;
						}
						else if(ParameterType.Bool.Equals(this.parameter[i].type))
						{
							types[i] = typeof(bool);
							values[i] = this.parameter[i].boolValue;
						}
						else if(ParameterType.Int.Equals(this.parameter[i].type))
						{
							types[i] = typeof(int);
							values[i] = this.parameter[i].intValue;
						}
						else if(ParameterType.Float.Equals(this.parameter[i].type))
						{
							types[i] = typeof(float);
							values[i] = this.parameter[i].floatValue;
						}
						else if(ParameterType.Vector2.Equals(this.parameter[i].type))
						{
							types[i] = typeof(Vector2);
							values[i] = this.parameter[i].vector2Value;
						}
						else if(ParameterType.Vector3.Equals(this.parameter[i].type))
						{
							types[i] = typeof(Vector3);
							values[i] = this.parameter[i].vector3Value;
						}
					}
					
					MethodInfo methodInfo = instance.GetType().GetMethod(this.functionName, types);
					if(methodInfo != null)
					{
						try
						{
							return methodInfo.Invoke(instance, values);
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + instance.GetType() + "): " + 
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + instance.GetType() + "): " + this.functionName);
					}
				}
				else
				{
					MethodInfo methodInfo = instance.GetType().GetMethod(this.functionName, new System.Type[] {});
					if(methodInfo != null)
					{
						try
						{
							return methodInfo.Invoke(instance, null);
						}
						catch(System.Exception ex)
						{
							Debug.LogWarning("Method call failed (" + instance.GetType() + "): " + 
								this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
						}
					}
					else
					{
						Debug.LogWarning("Method not found (" + instance.GetType() + "): " + this.functionName);
					}
				}
			}
			return null;
		}
		
		public System.Object GetReturnValueStatic(string className)
		{
			if(className != "" && this.functionName != "")
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(className);
				if(classType != null)
				{
					if(this.parameter.Length > 0)
					{
						System.Type[] types = new System.Type[this.parameter.Length];
						System.Object[] values = new System.Object[this.parameter.Length];
						
						for(int i=0; i<this.parameter.Length; i++)
						{
							if(ParameterType.String.Equals(this.parameter[i].type))
							{
								types[i] = typeof(string);
								values[i] = this.parameter[i].stringValue;
							}
							else if(ParameterType.Bool.Equals(this.parameter[i].type))
							{
								types[i] = typeof(bool);
								values[i] = this.parameter[i].boolValue;
							}
							else if(ParameterType.Int.Equals(this.parameter[i].type))
							{
								types[i] = typeof(int);
								values[i] = this.parameter[i].intValue;
							}
							else if(ParameterType.Float.Equals(this.parameter[i].type))
							{
								types[i] = typeof(float);
								values[i] = this.parameter[i].floatValue;
							}
							else if(ParameterType.Vector2.Equals(this.parameter[i].type))
							{
								types[i] = typeof(Vector2);
								values[i] = this.parameter[i].vector2Value;
							}
							else if(ParameterType.Vector3.Equals(this.parameter[i].type))
							{
								types[i] = typeof(Vector3);
								values[i] = this.parameter[i].vector3Value;
							}
						}
						
						MethodInfo methodInfo = classType.GetMethod(this.functionName, types);
						if(methodInfo != null)
						{
							try
							{
								return methodInfo.Invoke(null, values);
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Method call failed (" + classType + "): " + 
									this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
						}
					}
					else
					{
						MethodInfo methodInfo = classType.GetMethod(this.functionName, new System.Type[] {});
						if(methodInfo != null)
						{
							try
							{
								return methodInfo.Invoke(null, null);
							}
							catch(System.Exception ex)
							{
								Debug.LogWarning("Method call failed (" + classType + "): " + 
									this.functionName + "\n" + ex.Message + "\n" + ex.StackTrace);
							}
						}
						else
						{
							Debug.LogWarning("Method not found (" + classType + "): " + this.functionName);
						}
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + className);
				}
			}
			return null;
		}
	}
}
