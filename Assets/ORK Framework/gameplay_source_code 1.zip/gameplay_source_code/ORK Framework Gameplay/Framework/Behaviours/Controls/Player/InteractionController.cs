
using ORKFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Interaction Controller")]
	public class InteractionController : MonoBehaviour
	{
		private bool interacting = false;
	
		private List<BaseInteraction> list = new List<BaseInteraction>();
	
	
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool InteractionAvailable(InteractionType type, string customType)
		{
			GameObject player = ORK.Game.GetPlayer();
			for(int i=0; i<this.list.Count; i++)
			{
				// remove dead interactions
				if(this.list[i] == null)
				{
					this.list.RemoveAt(i--);
				}
				// check available interactions
				else if(this.list[i].enabled && 
					this.list[i].CanInteract(EventStartType.Interact, player) && 
					(InteractionType.Any.Equals(type) || 
					(type.Equals(this.list[i].Type) && 
					(customType == "" || this.list[i].customType == customType))))
				{
					return true;
				}
			}
			return false;
		}
		
		public BaseInteraction GetFirstAvailable(InteractionType type, string customType)
		{
			GameObject player = ORK.Game.GetPlayer();
			for(int i=0; i<this.list.Count; i++)
			{
				// remove dead interactions
				if(this.list[i] == null)
				{
					this.list.RemoveAt(i--);
				}
				// check available interactions
				else if(this.list[i].enabled && 
					this.list[i].CanInteract(EventStartType.Interact, player) && 
					(InteractionType.Any.Equals(type) || 
					(type.Equals(this.list[i].Type) && 
					(customType == "" || this.list[i].customType == customType))))
				{
					return this.list[i];
				}
			}
			return null;
		}
		
		public int AvailableCount
		{
			get
			{
				int count = 0;
				GameObject player = ORK.Game.GetPlayer();
				for(int i=0; i<this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled && 
						this.list[i].CanInteract(EventStartType.Interact, player))
					{
						count++;
					}
				}
				return count;
			}
		}
	
	
		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			BaseInteraction[] interactions = other.gameObject.GetComponents<BaseInteraction>();
			for(int i=0; i<interactions.Length; i++)
			{
				if(interactions[i] != null && EventStartType.Interact.Equals(interactions[i].startType) && 
					!this.list.Contains(interactions[i]))
				{
					this.list.Add(interactions[i]);
				}
			}
		}

		void OnTriggerExit(Collider other)
		{
			BaseInteraction[] interactions = other.gameObject.GetComponents<BaseInteraction>();
			for(int i=0; i<interactions.Length; i++)
			{
				if(interactions[i] != null && EventStartType.Interact.Equals(interactions[i].startType))
				{
					this.list.Remove(interactions[i]);
				}
			}
		}
	
	
		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			BaseInteraction[] interactions = other.gameObject.GetComponents<BaseInteraction>();
			for(int i=0; i<interactions.Length; i++)
			{
				if(interactions[i] != null && EventStartType.Interact.Equals(interactions[i].startType) && 
					!this.list.Contains(interactions[i]))
				{
					this.list.Add(interactions[i]);
				}
			}
		}

		void OnTriggerExit2D(Collider2D other)
		{
			BaseInteraction[] interactions = other.gameObject.GetComponents<BaseInteraction>();
			for(int i=0; i<interactions.Length; i++)
			{
				if(interactions[i] != null && EventStartType.Interact.Equals(interactions[i].startType))
				{
					this.list.Remove(interactions[i]);
				}
			}
		}
	
	
		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public bool Interact()
		{
			if(!this.interacting && ORK.Control.CanInteract)
			{
				for(int i=0; i<this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled)
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact())
						{
							return true;
						}
					}
				}
			}
			return false;
		}
		
		public bool Interact(InteractionType type, string customType)
		{
			if(!this.interacting && ORK.Control.CanInteract)
			{
				GameObject player = ORK.Game.GetPlayer();
				for(int i=0; i<this.list.Count; i++)
				{
					// remove dead interactions
					if(this.list[i] == null)
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled && 
						this.list[i].CanInteract(EventStartType.Interact, player) && 
						(InteractionType.Any.Equals(type) || 
						(type.Equals(this.list[i].Type) && 
						(customType == "" || this.list[i].customType == customType))))
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact())
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		private IEnumerator BlockInteraction()
		{
			this.interacting = true;
			yield return null;
			this.interacting = false;
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "InteractionController.psd");
		}
	}
}