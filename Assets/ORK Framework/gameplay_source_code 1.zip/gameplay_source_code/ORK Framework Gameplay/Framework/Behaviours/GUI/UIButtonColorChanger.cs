
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public class UIButtonColorChanger : MonoBehaviour
	{
		private GUIBox box;
		
		private bool alphaOnly = false;
		
		private Button button;
		
		private Color lastColor;
		
		private CanvasRenderer canvasRenderer;
		
		private CanvasRenderer[] childRenderer;
		
		public void Initialize(GUIBox box, bool alphaOnly)
		{
			this.box = box;
			this.alphaOnly = alphaOnly;
			
			this.button = this.GetComponent<Button>();
			this.canvasRenderer = this.GetComponent<CanvasRenderer>();
			this.childRenderer = this.GetComponentsInChildren<CanvasRenderer>();
		}
		
		void LateUpdate()
		{
			if(this.canvasRenderer != null && 
				this.childRenderer != null)
			{
				Color color = this.canvasRenderer.GetColor();
				
				if(this.box.controlable && this.box.focusable && 
					!this.box.Focused && this.box.InactiveColor.setColor)
				{
					color = this.box.InactiveColor.color;
					this.canvasRenderer.SetColor(color);
				}
				
				if(this.alphaOnly)
				{
					if(color.a != this.lastColor.a)
					{
						for(int i=0; i<this.childRenderer.Length; i++)
						{
							this.childRenderer[i].SetAlpha(color.a);
						}
						this.lastColor = color;
					}
				}
				else if(color != this.lastColor)
				{
					for(int i=0; i<this.childRenderer.Length; i++)
					{
						this.childRenderer[i].SetColor(color);
					}
					this.lastColor = color;
				}
			}
		}
	}
}
