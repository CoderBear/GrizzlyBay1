
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/ORK Object Variables")]
	public class ObjectVariablesComponent : SceneID
	{
		public bool localVariables = false;
		
		public string objectID = "";
		
		
		// initial variables
		public bool alwaysInitialize = false;
		
		public VariableSetter initialVariables = new VariableSetter();
		
		
		// ingame
		private VariableHandler handler;
		
		void Start()
		{
			if(this.alwaysInitialize || !this.HandlerExists())
			{
				this.initialVariables.SetVariables(this.GetHandler());
			}
		}
		
		public bool HandlerExists()
		{
			if(this.objectID == "" || this.localVariables)
			{
				return this.handler != null;
			}
			else
			{
				return ORK.Game.Scene.ObjectVariablesExist(this.objectID);
			}
		}
		
		public void SetHandler(VariableHandler handler)
		{
			this.handler = handler;
		}
		
		public VariableHandler GetHandler()
		{
			if(this.objectID == "" || this.localVariables)
			{
				if(this.handler == null)
				{
					this.handler = new VariableHandler(false);
					this.initialVariables.SetVariables(this.handler);
				}
				return this.handler;
			}
			else
			{
				if(ORK.Game.Scene.ObjectVariablesExist(this.objectID))
				{
					return ORK.Game.Scene.GetObjectVariables(this.objectID);
				}
				else
				{
					VariableHandler vh = ORK.Game.Scene.GetObjectVariables(this.objectID);
					this.initialVariables.SetVariables(vh);
					return vh;
				}
			}
		}
		
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "ObjectVariables.psd");
		}
	}
}
