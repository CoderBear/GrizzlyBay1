
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Area Name")]
	public class AreaComponent : MonoBehaviour
	{
		[ORKEditorInfo(ORKDataType.Area)]
		public int areaID = 0;
		
		public bool show = true;
		
		public bool autoName = true;
		
		void OnTriggerEnter(Collider other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if(player != null && other.transform.root == player.transform.root)
			{
				ORK.Game.SetArea(this.areaID, this.show);
			}
		}
		
		void OnTriggerEnter2D(Collider2D other)
		{
			GameObject player = ORK.Game.GetPlayer();
			if(player != null && other.transform.root == player.transform.root)
			{
				ORK.Game.SetArea(this.areaID, this.show);
			}
		}
		
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Area.psd");
		}
		
		public void SetAutoName()
		{
			this.name = "Area: " + ORK.Areas.GetName(this.areaID);
		}
	}
}
