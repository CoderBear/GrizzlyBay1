
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Scenes/Add Combatant")]
	public class AddCombatant : MonoBehaviour
	{
		public BattleSystemType battleType = BattleSystemType.TurnBased;
		
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		public CombatantGroupMember combatantSetting = new CombatantGroupMember();
		
		
		// battle arena
		public GameObject battleComponentObject;
	
		public bool setBCPos = false;
	
		public bool setBCRot = false;
		
		public bool useNearestArena = false;
		
		public float arenaRange = 20;
		
		
		// move AI
		public bool blockMoveAI = false;
		
		public bool ownMoveAI = false;
		
		public int moveAIID = 0;
		
		
		// waypoint settings
		public bool randomWaypointOrder = false;
		
		public GameObject[] waypoints = new GameObject[0];
		
		void Start()
		{
			if(this.GetComponent<CombatantComponent>() == null)
			{
				Combatant combatant = this.combatantSetting.Create(new Group(this.factionID));
				combatant.GameObject = this.gameObject;
				combatant.Group.BattleType = this.battleType;
				
				if(this.waypoints.Length > 0 && combatant.MoveAI != null)
				{
					combatant.MoveAI.SetWaypoints(this.waypoints, this.randomWaypointOrder);
				}
				
				if(combatant.Component != null)
				{
					combatant.Component.addCombatantComponent = this;
				}
			}
		}
		
		
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public BattleComponent GetBattleComponent(Vector3 position, Vector3 rotation)
		{
			BattleComponent bc = null;
			if(this.battleComponentObject != null)
			{
				bc = this.battleComponentObject.GetComponent<BattleComponent>();
				if(bc != null)
				{
					if(this.setBCPos)
					{
						bc.transform.position = position;
					}
					if(this.setBCRot)
					{
						bc.transform.eulerAngles = rotation;
					}
				}
			}
			if(bc == null && this.useNearestArena)
			{
				BattleComponent[] comps = GameObject.FindObjectsOfType<BattleComponent>();
				int nearest = -1;
				float distance = Mathf.Infinity;
				for(int i=0; i<comps.Length; i++)
				{
					if(comps[i] != null && comps[i].enabled && 
						comps[i].gameObject.activeInHierarchy)
					{
						float tmp = Vector3.Distance(position, comps[i].transform.position);
						if(tmp < distance)
						{
							nearest = i;
							distance = tmp;
						}
					}
				}
				if(nearest >= 0 && nearest < comps.Length)
				{
					bc = comps[nearest];
				}
			}
			if(bc == null)
			{
				bc = new GameObject("_Battle").AddComponent<BattleComponent>();
				bc.transform.position = position;
				bc.transform.eulerAngles = rotation;
			}
			bc.battleType = this.battleType;
			bc.useSceneID = false;
			bc.sceneID = -1;
			return bc;
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Combatant.psd");
		}
	}
}
