
using ORKFramework;
using ORKFramework.Events;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class ActorEventMover : MonoBehaviour
	{
		// objects
		private Transform actor;

		private Transform target;

		private Vector3 position;
	
		private CharacterController controller;

		private bool applyGravity;
	
		
		// time
		private float time;

		private float time2;
		
		
		// settings
		private float speed;
	
		private Function interpolate;

		private Vector3 startPos;

		private Vector3 distancePos;

		private float distanceY;
		
		private bool faceDirection = false;
		
		private bool ignoreY = false;
		
		
		// curves
		private AnimationCurve xCurve;
		
		private AnimationCurve yCurve;
		
		private AnimationCurve zCurve;
		
		private bool curveLocalSpace = false;
	
		
		// move types
		private bool speedToObject = false;

		private bool speedToPosition = false;

		private bool moveToPosition = false;

		private bool moveToDir = false;
		
		private bool curveMove = false;
	
		private BaseEvent callback = null;

		private int next = 0;
		
		
		// secure movement
		private bool secureMove = false;
		
		private Vector3 lastPosition;
		
		private float lastMoveTime = 0;
		
		private float secureTime = 0.5f;
	
		public void StopMoving()
		{
			this.actor = null;
			this.target = null;
			this.controller = null;
			this.faceDirection = false;
			this.ignoreY = false;
			this.speedToObject = false;
			this.speedToPosition = false;
			this.moveToPosition = false;
			this.moveToDir = false;
			this.callback = null;
			this.interpolate = null;
			
			this.curveMove = false;
			this.xCurve = null;
			this.yCurve = null;
			this.zCurve = null;
		}
	
	
		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public void SpeedToObject(Transform a, bool ic, bool g, bool fd, bool ignoreY, 
			float s, float d, Transform t, BaseEvent cb, int n, float secureTime)
		{
			this.StopMoving();
			
			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.applyGravity = g;
			this.speed = s;
			this.distanceY = d;
			this.target = t;
			this.callback = cb;
			this.next = n;
			this.faceDirection = fd;
			this.ignoreY = ignoreY;
			
			if(secureTime >= 0.1f)
			{
				this.secureMove = true;
				this.secureTime = secureTime;
			}
			
			this.speedToObject = true;
		}
	
		public void SpeedToPosition(Transform a, bool ic, bool g, bool fd, bool ignoreY, 
			float s, float d, Vector3 pos, BaseEvent cb, int n, float secureTime)
		{
			this.StopMoving();

			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.applyGravity = g;
			this.speed = s;
			this.distanceY = d;
			this.position = pos;
			this.callback = cb;
			this.next = n;
			this.faceDirection = fd;
			this.ignoreY = ignoreY;
			
			if(secureTime >= 0.1f)
			{
				this.secureMove = true;
				this.secureTime = secureTime;
			}

			this.speedToPosition = true;
		}
	
		public void MoveToPosition(Transform a, bool ic, bool g, bool fd, bool ignoreY, 
			Vector3 pos, EaseType et, float t)
		{
			this.StopMoving();
		
			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.applyGravity = g;
			this.position = pos;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
			
			if(fd)
			{
				if(ignoreY)
				{
					this.actor.LookAt(new Vector3(this.position.x, this.actor.position.y, this.position.z));
				}
				else
				{
					this.actor.LookAt(this.position);
				}
			}
			
			this.startPos = this.actor.position;
			this.distancePos = this.position - this.startPos;
			
			this.moveToPosition = true;
		}
	
		public void MoveToDirection(Transform a, bool ic, Vector3 d, bool fd, bool ignoreY, float s, float t)
		{
			this.StopMoving();
		
			this.actor = a;
			if(ic)
			{
				this.controller = this.actor.GetComponent<CharacterController>();
			}
			this.position = d;
			this.speed = s;
			this.time = 0;
			this.time2 = t;
			
			if(fd)
			{
				if(ignoreY)
				{
					this.actor.LookAt(new Vector3(this.position.x + this.actor.position.x, 
						this.actor.position.y, this.position.z + this.actor.position.z));
				}
				else
				{
					this.actor.LookAt(new Vector3(this.position.x + this.actor.position.x, 
						this.position.y + this.actor.position.y, this.position.z + this.actor.position.z));
				}
			}
			this.moveToDir = true;
		}
	
		public void MoveByCurve(Transform a, AnimationCurve xCurve, AnimationCurve yCurve, AnimationCurve zCurve, 
			bool localSpace, float t)
		{
			this.StopMoving();
			
			this.actor = a;
			this.position = this.actor.position;
			
			this.xCurve = xCurve;
			this.yCurve = yCurve;
			this.zCurve = zCurve;
			this.curveLocalSpace = localSpace;
			
			this.time = 0;
			this.time2 = t;
			
			this.curveMove = true;
		}
	
	
		/*
		============================================================================
		Callbacks functions
		============================================================================
		*/
		void OnControllerColliderHit(ControllerColliderHit hit)
		{
			if(this.speedToObject && this.callback != null && 
				hit.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.callback.StepFinished(this.next);
			}
		}
	
		void OnCollisionEnter(Collision collisionInfo)
		{
			if(this.speedToObject && this.callback != null && 
				collisionInfo.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.callback.StepFinished(this.next);
			}
		}
	
		void OnCollisionEnter2D(Collision2D collisionInfo)
		{
			if(this.speedToObject && this.callback != null && 
				collisionInfo.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.callback.StepFinished(this.next);
			}
		}
	
		void OnTriggerEnter(Collider other)
		{
			if(this.speedToObject && this.callback != null && 
				other.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.callback.StepFinished(this.next);
			}
		}
	
		void OnTriggerEnter2D(Collider2D other)
		{
			if(this.speedToObject && this.callback != null && 
				other.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				if(this.controller)
				{
					this.controller.Move(Vector3.zero);
				}
				this.callback.StepFinished(this.next);
			}
		}
	
	
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		void Update()
		{
			if(!ORK.Game.Paused)
			{
				if(this.speedToObject)
				{
					if(this.target != null)
					{
						if(this.faceDirection)
						{
							if(this.ignoreY)
							{
								this.actor.LookAt(new Vector3(this.target.position.x, this.actor.position.y, this.target.position.z));
							}
							else
							{
								this.actor.LookAt(this.target.position);
							}
						}
					
						if(this.controller)
						{
							Vector3 moveDirection = this.faceDirection ? 
								Vector3.forward : 
								VectorHelper.GetDirection(this.actor.position, 
									this.ignoreY ? 
										new Vector3(this.target.position.x, this.actor.position.y, this.target.position.z) : 
										this.target.position);
							
							if(this.faceDirection)
							{
								moveDirection = this.actor.TransformDirection(moveDirection);
							}
							
							if(this.applyGravity)
							{
								this.controller.Move((moveDirection.normalized * this.speed + Physics.gravity) * ORK.Game.DeltaTime);
							}
							else
							{
								this.controller.Move(moveDirection.normalized * this.speed * ORK.Game.DeltaTime);
							}
						}
						else
						{
							this.actor.position = Vector3.MoveTowards(this.actor.position, 
								this.ignoreY ? 
									new Vector3(this.target.position.x, this.actor.position.y, this.target.position.z) : 
									this.target.position, 
								this.speed * ORK.Game.DeltaTime);
						}
						
						if(this.secureMove && this.actor.position != this.lastPosition)
						{
							this.lastPosition = this.actor.position;
							this.lastMoveTime = Time.time;
						}
					}
				
					if(this.target == null || 
						(this.secureMove && this.lastMoveTime + this.secureTime < Time.time) || 
						VectorHelper.Distance(this.actor.position, this.target.position, this.ignoreY) - this.distanceY <= 0.2f)
					{
						this.speedToObject = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
						
						if(this.callback != null)
						{
							this.callback.StepFinished(this.next);
						}
					}
				}
				else if(this.speedToPosition)
				{
					if(this.faceDirection)
					{
						if(this.ignoreY)
						{
							this.actor.LookAt(new Vector3(this.position.x, this.actor.position.y, this.position.z));
						}
						else
						{
							this.actor.LookAt(this.position);
						}
					}
				
					if(this.controller)
					{
						Vector3 moveDirection = this.faceDirection ? 
							Vector3.forward : 
							VectorHelper.GetDirection(this.actor.position, 
								this.ignoreY ? 
									new Vector3(this.position.x, this.actor.position.y, this.position.z) : 
									this.position);
						
						if(this.faceDirection)
						{
							moveDirection = this.actor.TransformDirection(moveDirection);
						}
						
						if(this.applyGravity)
						{
							this.controller.Move((moveDirection.normalized * this.speed + Physics.gravity) * ORK.Game.DeltaTime);
						}
						else
						{
							this.controller.Move(moveDirection.normalized * this.speed * ORK.Game.DeltaTime);
						}
					}
					else
					{
						this.actor.position = Vector3.MoveTowards(this.actor.position, 
							this.ignoreY ? 
								new Vector3(this.position.x, this.actor.position.y, this.position.z) : 
								this.position, 
							this.speed * ORK.Game.DeltaTime);
					}
						
					if(this.secureMove && this.actor.position != this.lastPosition)
					{
						this.lastPosition = this.actor.position;
						this.lastMoveTime = Time.time;
					}
				
					if((this.secureMove && this.lastMoveTime + this.secureTime < Time.time) || 
						VectorHelper.Distance(this.actor.position, this.position, this.ignoreY) - this.distanceY <= 0.2f)
					{
						this.speedToPosition = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
						
						if(this.callback != null)
						{
							this.callback.StepFinished(this.next);
						}
					}
				}
				else if(this.moveToPosition)
				{
					this.time += ORK.Game.DeltaTime;
					if(this.controller)
					{
						Vector3 moveDirection = Interpolate.Ease(this.interpolate, this.startPos, 
							this.distancePos, this.time, this.time2) - this.actor.position;
						
						if(this.applyGravity)
						{
							moveDirection += Physics.gravity;
						}
						this.controller.Move(moveDirection);
					}
					else
					{
						this.actor.position = Interpolate.Ease(this.interpolate, this.startPos, 
							this.distancePos, this.time, this.time2);
					}
					
					if(this.time >= this.time2)
					{
						this.moveToPosition = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
					}
				}
				else if(this.moveToDir)
				{
					float t = ORK.Game.DeltaTime;
					this.time += t;
					if(this.controller)
					{
						this.controller.Move(this.position * this.speed * t);
					}
					else
					{
						this.actor.position += this.position * this.speed * t;
					}
					
					if(this.time >= this.time2)
					{
						this.moveToDir = false;
						if(this.controller)
						{
							this.controller.Move(Vector3.zero);
						}
					}
				}
				else if(this.curveMove)
				{
					this.time += ORK.Game.DeltaTime;
					
					Vector3 tmp = Vector3.zero;
					if(this.xCurve != null)
					{
						tmp.x = this.xCurve.Evaluate(this.time);
					}
					if(this.yCurve != null)
					{
						tmp.y = this.yCurve.Evaluate(this.time);
					}
					if(this.zCurve != null)
					{
						tmp.z = this.zCurve.Evaluate(this.time);
					}
					
					if(this.curveLocalSpace)
					{
						this.actor.position = this.position;
						this.actor.position = this.actor.TransformPoint(tmp);
					}
					else
					{
						this.actor.position = this.position + tmp;
					}
					
					if(this.time >= this.time2)
					{
						this.curveMove = false;
					}
				}
			}
		}
	}
}
