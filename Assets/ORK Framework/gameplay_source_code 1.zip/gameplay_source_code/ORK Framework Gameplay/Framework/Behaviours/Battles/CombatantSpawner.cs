
using ORKFramework;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Combatant Spawner")]
	public class CombatantSpawner : BaseBattleComponent
	{
		// repeat autostart check
		public bool repeatCheckSpawn = false;
		
		public float repeatCheckTime = 0.0f;
		
		
		// chance
		public bool useAppearingChance = false;
		
		public float appearingChance = 100;
		
		public bool appearingChanceFailSetID = false;
		
		
		// spawn settings
		public LayerMask layerMask = -1;
		
		public bool spawnRandom = false;

		public Rounding roundSpawnPosition = Rounding.None;
		
		public bool rememberCombatants = false;
		
		public string spawnerID = "";
		
		
		// spawn positions
		public GameObject[] spawnPoint;
		
		
		// battle arena
		public GameObject battleComponentObject;
	
		public bool setBCPos = false;
	
		public bool setBCRot = false;
		
		public bool useNearestArena = false;
		
		public float arenaRange = 20;
	
		public BattleSystemType battleType = BattleSystemType.TurnBased;
		
		
		// combatant settings
		public BattleCombatant[] combatant = new BattleCombatant[] {new BattleCombatant()};
		
		public int[] quantity = new int[] {1};
		
		public bool[] randomRotation = new bool[] {false};
		
		public bool[] setScale = new bool[] {false};
		
		public Vector3[] scale = new Vector3[] {Vector3.one};
		
		public bool[] spawnAll = new bool[] {false};
		
		// respawn
		public bool[] respawn = new bool[] {false};
		
		public float[] respawnTime = new float[] {60.0f};
		
		// move AI
		public bool[] blockMoveAI = new bool[] {false};
		
		public bool[] ownMoveAI = new bool[] {false};
		
		public int[] moveAIID = new int[] {0};
		
		
		// waypoint settings
		public bool randomWaypointOrder = false;
		
		public GameObject[] waypoints = new GameObject[0];


		// ingame
		private bool initialized = false;

		private Collider colliderComponent;
		
		private Collider2D collider2DComponent;
		
		private SpawnerData[] spawned;
		
		private bool isSpawned = false;
		
		private bool dontRemember = false;
		
		
		/*
		============================================================================
		Start functions
		============================================================================
		*/
		void Start()
		{
			if(!this.initialized)
			{
				this.initialized = true;

				if(!this.useAppearingChance ||
					ORK.GameSettings.CheckRandom(this.appearingChance))
				{
					this.colliderComponent = this.GetComponent<Collider>();
					this.collider2DComponent = this.GetComponent<Collider2D>();
					this.CheckCombatantArrays();

					// init spawned
					if(!this.CheckAutoDestroy())
					{
						if(this.IsSceneIDSet())
						{
							this.dontRemember = true;
							GameObject.Destroy(this.gameObject);
						}
						else if(this.InitSpawned())
						{
							this.CheckAutoStart();
						}
					}
				}
				else if(this.useAppearingChance)
				{
					this.dontRemember = true;
					if(this.appearingChanceFailSetID)
					{
						this.SetSceneID();
					}
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		private void CheckAutoStart()
		{
			if(EventStartType.Autostart.Equals(this.startType))
			{
				if(this.CheckConditions())
				{
					this.DoAutoStart();
				}
				else if(this.repeatCheckSpawn)
				{
					StartCoroutine(this.CheckAutoStart2());
				}
			}
		}
		
		private IEnumerator CheckAutoStart2()
		{
			if(this.repeatCheckTime > 0)
			{
				yield return new WaitForSeconds(this.repeatCheckTime);
			}
			else
			{
				yield return new WaitForSeconds(0.1f);
			}
			this.CheckAutoStart();
		}
		
		public void CheckCombatantArrays()
		{
			if(this.quantity.Length != this.combatant.Length)
			{
				this.quantity = ArrayHelper.Copy(this.combatant.Length, this.quantity);
			}
			if(this.randomRotation.Length != this.combatant.Length)
			{
				this.randomRotation = ArrayHelper.Copy(this.combatant.Length, this.randomRotation);
			}
			if(this.setScale.Length != this.combatant.Length)
			{
				this.setScale = ArrayHelper.Copy(this.combatant.Length, this.setScale);
			}
			if(this.scale.Length != this.combatant.Length)
			{
				this.scale = ArrayHelper.Copy(this.combatant.Length, this.scale);
			}
			if(this.spawnAll.Length != this.combatant.Length)
			{
				this.spawnAll = ArrayHelper.Copy(this.combatant.Length, this.spawnAll);
			}
			if(this.respawn.Length != this.combatant.Length)
			{
				this.respawn = ArrayHelper.Copy(this.combatant.Length, this.respawn);
			}
			if(this.respawnTime.Length != this.combatant.Length)
			{
				this.respawnTime = ArrayHelper.Copy(this.combatant.Length, this.respawnTime);
			}
			if(this.blockMoveAI.Length != this.combatant.Length)
			{
				this.blockMoveAI = ArrayHelper.Copy(this.combatant.Length, this.blockMoveAI);
			}
			if(this.ownMoveAI.Length != this.combatant.Length)
			{
				this.ownMoveAI = ArrayHelper.Copy(this.combatant.Length, this.ownMoveAI);
			}
			if(this.moveAIID.Length != this.combatant.Length)
			{
				this.moveAIID = ArrayHelper.Copy(this.combatant.Length, this.moveAIID);
			}
		}
		
		
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public BattleComponent GetBattleComponent(Vector3 position, Vector3 rotation)
		{
			BattleComponent bc = null;
			if(this.battleComponentObject != null)
			{
				bc = this.battleComponentObject.GetComponent<BattleComponent>();
				if(bc != null)
				{
					if(this.setBCPos)
					{
						bc.transform.position = position;
					}
					if(this.setBCRot)
					{
						bc.transform.eulerAngles = rotation;
					}
				}
			}
			if(bc == null && this.useNearestArena)
			{
				BattleComponent[] comps = GameObject.FindObjectsOfType<BattleComponent>();
				int nearest = -1;
				float distance = Mathf.Infinity;
				for(int i=0; i<comps.Length; i++)
				{
					if(comps[i] != null && comps[i].enabled && 
						comps[i].gameObject.activeInHierarchy)
					{
						float tmp = Vector3.Distance(position, comps[i].transform.position);
						if(tmp < distance)
						{
							nearest = i;
							distance = tmp;
						}
					}
				}
				if(nearest >= 0 && nearest < comps.Length)
				{
					bc = comps[nearest];
				}
			}
			if(bc == null)
			{
				bc = new GameObject("_Battle").AddComponent<BattleComponent>();
				bc.transform.position = position;
				bc.transform.eulerAngles = rotation;
			}
			bc.battleType = this.battleType;
			bc.useSceneID = this.useSceneID;
			bc.sceneID = this.sceneID;
			return bc;
		}
		
		private Vector3 GetSpawnCenter()
		{
			if(this.colliderComponent != null)
			{
				Vector3 castOrigin = this.colliderComponent.bounds.center;
				castOrigin.y += this.colliderComponent.bounds.extents.y - 0.1f;
				return castOrigin;
			}
			else if(this.collider2DComponent != null)
			{
				Vector3 castOrigin = this.collider2DComponent.bounds.center;
				castOrigin.y += this.collider2DComponent.bounds.extents.y - 0.1f;
				return castOrigin;
			}
			return this.transform.position;
		}
		
		private Vector3 GetRandomAdd()
		{
			Vector3 add = Vector3.zero;
			if(this.colliderComponent != null)
			{
				add.x += Random.Range(-this.colliderComponent.bounds.extents.x, this.colliderComponent.bounds.extents.x);
				add.z += Random.Range(-this.colliderComponent.bounds.extents.z, this.colliderComponent.bounds.extents.z);
			}
			else if(this.collider2DComponent != null)
			{
				add.x += Random.Range(-this.collider2DComponent.bounds.extents.x, this.collider2DComponent.bounds.extents.x);
				add.z += Random.Range(-this.collider2DComponent.bounds.extents.z, this.collider2DComponent.bounds.extents.z);
			}
			return add;
		}
		
		private Vector3 GetSingleSpawnPosition()
		{
			if(this.spawnPoint != null && this.spawnPoint.Length > 0)
			{
				List<GameObject> list = new List<GameObject>(this.spawnPoint);
				ArrayHelper.RemoveAllNull(list);
				if(list.Count > 0)
				{
					return list[Random.Range(0, list.Count)].transform.position;
				}
			}
			return this.transform.position;
		}
		
		public bool IsBlockMoveAI(int index)
		{
			if(index >= 0 && index < this.blockMoveAI.Length)
			{
				return this.blockMoveAI[index];
			}
			return false;
		}
		
		public bool OwnMoveAI(int index)
		{
			if(index >= 0 && index < this.ownMoveAI.Length)
			{
				return this.ownMoveAI[index];
			}
			return false;
		}
		
		public int GetMoveAI(int index)
		{
			if(index >= 0 && index < this.ownMoveAI.Length)
			{
				return this.moveAIID[index];
			}
			return -1;
		}
		
		
		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get{ return InteractionType.Battle;}
		}
		
		public void StartFromEvent()
		{
			if(!this.isSpawned)
			{
				this.StartEvent(null);
			}
		}
		
		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;

			if(!this.initialized)
			{
				this.Start();
			}
			
			this.isSpawned = true;
		
			if(this.spawnRandom)
			{
				this.StartCoroutine(this.Spawn(Random.Range(0, this.combatant.Length)));
			}
			else
			{
				this.StartCoroutine(this.SpawnAll());
			}
		}
		
		
		/*
		============================================================================
		Spawn functions
		============================================================================
		*/
		private IEnumerator Spawn(int index)
		{
			Vector3 castOrigin = this.GetSpawnCenter();
			int count = 0;
			
			while(this.spawned[index].CanSpawn(this.quantity[index]))
			{
				if((this.colliderComponent != null && !this.SpawnInArea(index, castOrigin + this.GetRandomAdd())) || 
					(this.collider2DComponent != null && !this.SpawnInArea(index, castOrigin + this.GetRandomAdd())) || 
					(this.colliderComponent == null && this.collider2DComponent == null && 
						!this.SpawnAt(index, this.GetSingleSpawnPosition())))
				{
					count++;
					if(count > 10)
					{
						count = 0;
						yield return null;
					}
				}
			}
		}
		
		private IEnumerator SpawnSingle(int index)
		{
			Vector3 castOrigin = this.GetSpawnCenter();
			int count = 0;
			
			while(true)
			{
				if((this.colliderComponent != null && !this.SpawnInArea(index, castOrigin + this.GetRandomAdd())) || 
					(this.collider2DComponent != null && !this.SpawnInArea(index, castOrigin + this.GetRandomAdd())) || 
					(this.colliderComponent == null && this.collider2DComponent == null && 
						!this.SpawnAt(index, this.GetSingleSpawnPosition())))
				{
					count++;
					if(count > 10)
					{
						count = 0;
						yield return null;
					}
				}
				else
				{
					break;
				}
			}
		}
		
		private IEnumerator SpawnAll()
		{
			Vector3 castOrigin = this.GetSpawnCenter();
			int count = 0;
			
			for(int i=0; i<this.combatant.Length; i++)
			{
				while(this.spawned[i].CanSpawn(this.quantity[i]))
				{
					if((this.colliderComponent != null && !this.SpawnInArea(i, castOrigin + this.GetRandomAdd())) || 
						(this.collider2DComponent != null && !this.SpawnInArea(i, castOrigin + this.GetRandomAdd())) || 
						(this.colliderComponent == null && this.collider2DComponent == null && 
							!this.SpawnAt(i, this.GetSingleSpawnPosition())))
					{
						count++;
						if(count > 10)
						{
							count = 0;
							yield return null;
						}
					}
				}
			}
		}
		
		private bool SpawnInArea(int index, Vector3 castOrigin)
		{
			if(!Rounding.None.Equals(this.roundSpawnPosition))
			{
				castOrigin.x = ValueHelper.GetRounded(castOrigin.x, this.roundSpawnPosition);
				castOrigin.z = ValueHelper.GetRounded(castOrigin.z, this.roundSpawnPosition);
			}

			if(this.colliderComponent != null)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(castOrigin, -Vector3.up, out hit, this.colliderComponent.bounds.size.y, this.layerMask))
				{
					// check if not a spawn zone
					if(!ORK.Game.Scene.WithinNoSpawn(hit.point))
					{
						return this.SpawnAt(index, hit.point);
					}
				}
			}
			else if(this.collider2DComponent != null)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(castOrigin, -Vector3.up, out hit, this.collider2DComponent.bounds.size.y, this.layerMask))
				{
					// check if not a spawn zone
					if(!ORK.Game.Scene.WithinNoSpawn(hit.point))
					{
						return this.SpawnAt(index, hit.point);
					}
				}
			}
			return false;
		}
		
		private bool SpawnAt(int index, Vector3 position)
		{
			Group group = this.combatant[index].GetGroup(this, index, this.respawn[index]);
			if(group != null)
			{
				// update spawned info
				this.spawned[index].quantity++;
				this.spawned[index].groups.Add(group);
				
				group.BattleType = this.battleType;
				group.Leader.Spawn(position, true, 
					this.randomRotation[index] ? Random.Range(0.0f, 360.0f) : this.transform.eulerAngles.y, 
					this.setScale[index], this.scale[index]);
				
				if(this.spawnAll[index])
				{
					group.SpawnGroup(true, true);
				}
				
				if(this.rememberCombatants)
				{
					List<Combatant> list = group.GetBattle();
					for(int i=0; i<list.Count; i++)
					{
						list[i].RememberPosition = true;
					}
				}
				
				this.SetWaypoints(group);
				return true;
			}
			return false;
		}
		
		public void SetWaypoints(Group group)
		{
			if(this.waypoints.Length > 0)
			{
				List<Combatant> list = group.GetBattle();
				for(int i=0; i<list.Count; i++)
				{
					if(list[i].MoveAI != null)
					{
						list[i].MoveAI.SetWaypoints(this.waypoints, this.randomWaypointOrder);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Respawn functions
		============================================================================
		*/
		public void CheckRespawn(int index, Group group)
		{
			if(!this.IsSceneIDSet())
			{
				this.spawned[index].quantity--;
				this.spawned[index].groups.Remove(group);
				
				if(this.respawn[index])
				{
					this.spawned[index].respawn.Add(this.respawnTime[index]);
				}
			}
		}
		
		void Update()
		{
			if(this.spawned != null)
			{
				float delta = ORK.Game.DeltaBattleTime;
				for(int i=0; i<this.spawned.Length; i++)
				{
					if(this.spawned[i].respawn.Count > 0)
					{
						for(int j=0; j<this.spawned[i].respawn.Count; j++)
						{
							this.spawned[i].respawn[j] -= delta;
							
							if(this.spawned[i].respawn[j] <= 0)
							{
								this.spawned[i].respawn.RemoveAt(j--);
								this.StartCoroutine(this.SpawnSingle(i));
							}
						}
					}
				}
			}
		}
		
		private bool InitSpawned()
		{
			this.spawned = new SpawnerData[this.combatant.Length];
			for(int i=0; i<this.spawned.Length; i++)
			{
				this.spawned[i] = new SpawnerData();
			}
			
			if(this.rememberCombatants && this.spawnerID != "")
			{
				DataObject data = ORK.Game.Scene.GetSpawnerData(
					Application.loadedLevelName, this.spawnerID);
				
				if(data != null)
				{
					DataObject[] tmp = data.GetFileArray("spawned");
					if(this.spawned.Length == tmp.Length)
					{
						for(int i=0; i<this.spawned.Length; i++)
						{
							this.spawned[i].LoadGame(tmp[i]);
							this.spawned[i].UpdateSpawner(this, i, this.respawn[i]);
						}
						this.isSpawned = true;
						return false;
					}
					else
					{
						return true;
					}
				}
			}
			
			return true;
		}
		
		public void StoreSpawned()
		{
			if(this.rememberCombatants && this.spawnerID != "" && 
				this.spawned != null && this.isSpawned && !this.dontRemember)
			{
				DataObject data = new DataObject();
				
				DataObject[] tmp = new DataObject[this.spawned.Length];
				for(int i=0; i<this.spawned.Length; i++)
				{
					tmp[i] = this.spawned[i].SaveGame();
				}
				data.Set("spawned", tmp);
				
				ORK.Game.Scene.SetSpawnerData(
					Application.loadedLevelName, this.spawnerID, data);
			}
		}
		
		void OnDestroy()
		{
			this.StoreSpawned();
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Combatant.psd");
		}
	}
}
