
using UnityEngine;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Real Time Battle Area")]
	public class RealTimeBattleArea : BaseConditionComponent
	{
		// ingame
		private bool counted = false;
		
		private bool doStart = false;
		
		private bool doEnd = false;
		
		
		// collider
		private Collider colliderComponent;
		
		private Collider2D collider2DComponent;
		
		
		/*
		============================================================================
		Auto destroy functions
		============================================================================
		*/
		void Start()
		{
			this.colliderComponent = this.GetComponent<Collider>();
			this.collider2DComponent = this.GetComponent<Collider2D>();
			
			if(!this.CheckAutoDestroy())
			{
				if(this.IsSceneArea())
				{
					ORK.Battle.RealTimeAreaCount++;
					this.counted = true;
				}
			}
		}
		
		
		/*
		============================================================================
		Scene area functions
		============================================================================
		*/
		public bool IsSceneArea()
		{
			return this.colliderComponent == null && this.collider2DComponent == null;
		}
		
		void OnDisable()
		{
			if(this.IsSceneArea() || this.counted)
			{
				this.doStart = false;
				this.doEnd = false;
				this.counted = false;
				ORK.Battle.RealTimeAreaCount--;
				this.SetVariables();
			}
		}
		
		
		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			if((other.gameObject == ORK.Game.GetPlayer() || 
				(ORK.Game.GetPlayer() != null && 
					other.transform.root == ORK.Game.GetPlayer().transform.root)) && 
				this.CheckVariables())
			{
				this.doStart = true;
				this.doEnd = false;
				this.StartCoroutine(this.EnterBattle());
			}
		}
		
		void OnTriggerExit(Collider other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() || 
				(ORK.Game.GetPlayer() != null && 
					other.transform.root == ORK.Game.GetPlayer().transform.root))
			{
				this.doStart = false;
				this.doEnd = true;
				this.StartCoroutine(this.ExitBattle());
			}
		}
		
		
		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			if((other.gameObject == ORK.Game.GetPlayer() || 
				(ORK.Game.GetPlayer() != null && 
					other.transform.root == ORK.Game.GetPlayer().transform.root)) && 
				this.CheckVariables())
			{
				this.doStart = true;
				this.doEnd = false;
				this.StartCoroutine(this.EnterBattle());
			}
		}
		
		void OnTriggerExit2D(Collider2D other)
		{
			if(other.gameObject == ORK.Game.GetPlayer() || 
				(ORK.Game.GetPlayer() != null && 
					other.transform.root == ORK.Game.GetPlayer().transform.root))
			{
				this.doStart = false;
				this.doEnd = true;
				this.StartCoroutine(this.ExitBattle());
			}
		}
		
		
		/*
		============================================================================
		Battle functions (fix for exit/enter bug)
		============================================================================
		*/
		private IEnumerator EnterBattle()
		{
			yield return null;
			yield return null;
			if(this.doStart)
			{
				this.doStart = false;
				this.doEnd = false;
				
				if(!this.counted)
				{
					this.counted = true;
					ORK.Battle.RealTimeAreaCount++;
				}
			}
		}
		
		private IEnumerator ExitBattle()
		{
			yield return null;
			yield return null;
			if(this.doEnd)
			{
				this.doStart = false;
				this.doEnd = false;
				
				if(this.counted)
				{
					this.counted = false;
					ORK.Battle.RealTimeAreaCount--;
					this.SetVariables();
				}
			}
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Battle.psd");
		}
	}
}
