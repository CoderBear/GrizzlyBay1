
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Battle")]
	public class BattleComponent : BaseBattleComponent, IEventStarter
	{
		public BattleSystemType battleType = BattleSystemType.TurnBased;
		
		public bool canEscape = true;
		
		public bool setLooks = true;
		
		
		// chance
		public bool useAppearingChance = false;
		
		public float appearingChance = 100;
		
		public bool appearingChanceFailSetID = false;
		
		
		// combatant teams
		public bool allGroups = false;
		
		public BattleCombatant[] combatant = new BattleCombatant[] {new BattleCombatant()};
		
		
		// battle spots
		public bool ownSpots = false;
		
		// player group
		public GameObject[] playerSpot = new GameObject[0];
		
		public GameObject[] playerSpotPA = new GameObject[0];
		
		public GameObject[] playerSpotEA = new GameObject[0];
		
		// ally group
		public GameObject[] allySpot = new GameObject[0];
		
		public GameObject[] allySpotPA = new GameObject[0];
		
		public GameObject[] allySpotEA = new GameObject[0];
		
		// enemy group
		public GameObject[] enemySpot = new GameObject[0];
		
		public GameObject[] enemySpotPA = new GameObject[0];
		
		public GameObject[] enemySpotEA = new GameObject[0];
		
		
		// battle advantages
		// player advantage
		public bool enablePA = true;
		
		public bool overridePAChance = false;
		
		public float paChance = 0;
		
		// enemy advantage
		public bool enableEA = true;
		
		public bool overrideEAChance = false;
		
		public float eaChance = 0;
		
		
		// additional loot
		public ItemGain[] itemGains = new ItemGain[0];
		
		
		// start event
		public bool useDefaultStart = true;
		
		public ORKBattleStartEvent startEventAsset;
		
		
		// end event
		public bool useDefaultEnd = true;
		
		public ORKBattleEndEvent victoryEventAsset;
		
		public ORKBattleEndEvent escapeEventAsset;
		
		public ORKBattleEndEvent defeatEventAsset;
		
		public ORKBattleEndEvent leaveArenaEventAsset;
		
		
		// auto join
		public bool useDefaultAutoJoin = true;
		
		public AutoJoinBattle autoJoin;
		
		
		// ingame
		private BattleStartEvent startEvent;
		
		private BattleEndEvent endEvent;
		
		private BattleOutcome outcome = BattleOutcome.None;
		
		
		// battle mode:
		// 0 == not yet started
		// 1 == start event
		// 2 == battle running
		// 3 == end event
		// 4 == done
		private int battleMode = 0;
		
		private bool markSceneChangeDestroy = false;
		
		private bool sceneChangedDestroy = false;
		
		
		// camera
		private Vector3 initialCamPosition;
		
		private Quaternion initialCamRotation;
		
		private float initialFieldOfView;
		
		
		// started by event
		private IEventStarter starter;
		
		
		// real battle spots
		private Dictionary<GameObject, Combatant> playerSpotList;
		
		private Dictionary<GameObject, Combatant> allySpotList;
		
		private Dictionary<GameObject, Combatant> enemySpotList;
		
		
		// start from combatant
		private List<Group> startGroup;
		
		// joined combatants
		private List<Combatant> joined;
		
		public GameObject GameObject
		{
			get{ return this.gameObject;}
		}
		
		
		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get{ return InteractionType.Battle;}
		}
		
		
		/*
		============================================================================
		Combatants functions
		============================================================================
		*/
		private void AddTeamToBattle(int index)
		{
			if(index >= 0 && index < this.combatant.Length)
			{
				Group group = this.combatant[index].GetGroup(null, -1, false);
				if(group != null)
				{
					group.BattleType = this.battleType;
					ORK.Battle.Join(group.GetBattle());
				}
			}
		}
		
		
		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		void Start()
		{
			//this.SetSceneName();
			
			if(!this.useAppearingChance || 
				ORK.GameSettings.CheckRandom(this.appearingChance))
			{
				if(!this.CheckAutoDestroy())
				{
					if(this.IsSceneIDSet())
					{
						GameObject.Destroy(this.gameObject);
					}
					else
					{
						this.AutoStart();
					}
				}
			}
			else if(this.useAppearingChance)
			{
				if(this.appearingChanceFailSetID)
				{
					this.SetSceneID();
				}
				GameObject.Destroy(this.gameObject);
			}
		}
		
		void Update()
		{
			if(!ORK.Game.Paused)
			{
				if(this.battleMode == 0)
				{
					this.KeyPress();
				}
				else if(this.battleMode == 1 && 
					this.startEvent != null && this.startEvent.Executing)
				{
					this.startEvent.Tick(ORK.Game.DeltaTime);
				}
				else if(this.battleMode == 3 && 
					this.endEvent != null && this.endEvent.Executing)
				{
					this.endEvent.Tick(ORK.Game.DeltaTime);
				}
			}
		}
		
		public void StartEvent(IEventStarter s)
		{
			this.starter = s;
			this.StartBattle();
		}
		
		public void StartGroup(Group g, IEventStarter s)
		{
			this.startGroup = new List<Group>();
			this.startGroup.Add(g);
			this.starter = s;
			this.StartEvent(ORK.Game.GetPlayer());
		}
		
		public void StartGroups(List<Group> g, IEventStarter s)
		{
			this.startGroup = g;
			this.starter = s;
			this.StartEvent(ORK.Game.GetPlayer());
		}
		
		public override void StartEvent(GameObject startingObject)
		{
			if(this.battleMode == 0 && ORK.Control.CanInteract && 
				!ORK.Control.InBattle && !this.IsSceneIDSet() && 
				!ORK.Control.ChangingScene)
			{
				this.StartBattle();
			}
			else if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
			}
		}
		
		private void StartBattle()
		{
			this.joined = null;
			
			this.startEvent = null;
			this.endEvent = null;
			this.battleMode = 1;
	
			this.playerSpotList = null;
			this.allySpotList = null;
			this.enemySpotList = null;
	
			// set up battle
			ORK.Battle.ClearBattle();
			ORK.Battle.SetBattleArena(this);
			
			// player group joins
			ORK.Battle.Join(ORK.Game.ActiveGroup.GetBattle());
			// allies/enemies join
			if(this.startGroup != null && this.startGroup.Count > 0)
			{
				for(int i=0; i<this.startGroup.Count; i++)
				{
					ORK.Battle.Join(this.startGroup[i].GetBattle());
				}
			}
			else
			{
				if(this.allGroups)
				{
					for(int i=0; i<this.combatant.Length; i++)
					{
						this.AddTeamToBattle(i);
					}
				}
				else
				{
					this.AddTeamToBattle(Random.Range(0, this.combatant.Length));
				}
			}
			
			// auto join
			if(this.useDefaultAutoJoin)
			{
				this.joined = ORK.BattleSettings.autoJoin.GetCombatants(this.transform.position);
			}
			else if(this.autoJoin != null)
			{
				this.joined = this.autoJoin.GetCombatants(this.transform.position);
			}
			if(this.joined != null && this.joined.Count > 0)
			{
				ORK.Battle.Join(this.joined);
			}
			
			// check if any enemies are in the battle
			if(ORK.Game.Combatants.Get(ORK.Game.ActiveGroup.Leader, 
				false, Range.Infinity, Consider.Yes, Consider.No, Consider.Yes).Count > 0)
			{
				this.outcome = BattleOutcome.None;
				ORK.Battle.SetType(this.battleType);
				
				Camera cam = Camera.main;
				if(cam != null)
				{
					this.initialCamPosition = cam.transform.position;
					this.initialCamRotation = cam.transform.rotation;
					this.initialFieldOfView = cam.fieldOfView;
				}
				
				ORK.Control.SetInBattle(1);
				ORK.Battle.DoBattleBlock(1);
				
				this.startEvent = new BattleStartEvent();
				ORKBattleStartEvent evtAsset = this.useDefaultStart ? 
					ORK.BattleSystem.GetStartEvent(this.battleType) : 
					this.startEventAsset;
				if(evtAsset != null)
				{
					this.startEvent.SetData(evtAsset.GetData().ToDataObject());
				}
				this.startEvent.StartEvent(this, ORK.Game.GetPlayer());
			}
			// no enemies, no battle
			else
			{
				this.battleMode = 0;
				ORK.Battle.ClearBattle();
				if(ComponentHelper.IsAlive(this.starter))
				{
					this.starter.EventEnded();
				}
			}
		}
		
		public void DontDestroy()
		{
			this.markSceneChangeDestroy = true;
			this.sceneChangedDestroy = false;
			this.gameObject.transform.parent = null;
			DontDestroyOnLoad(this.gameObject);
			
			// mark combatants for respawn
			if(this.startGroup != null)
			{
				for(int i=0; i<this.startGroup.Count; i++)
				{
					if(this.startGroup[i] != null && 
						this.startGroup[i].Spawner != null)
					{
						this.startGroup[i].CheckSpawner(true);
					}
				}
			}
		}
		
		void OnLevelWasLoaded(int level)
		{
			if(this.markSceneChangeDestroy)
			{
				this.sceneChangedDestroy = true;
			}
			
			// replace spots on ground
			if(this.playerSpotList != null)
			{
				this.SpotListOnGround(this.playerSpotList);
			}
			if(this.allySpotList != null)
			{
				this.SpotListOnGround(this.allySpotList);
			}
			if(this.enemySpotList != null)
			{
				this.SpotListOnGround(this.enemySpotList);
			}
		}
		
		public void BattleFinished(BattleOutcome bo)
		{
			this.outcome = bo;
			this.EventEnded();
		}
		
		public void EventEnded()
		{
			// start event finished
			if(this.battleMode == 1)
			{
				this.battleMode = 2;
				this.startEvent = null;
		
				ORK.Game.Combatants.SpawnBattle();
				if(this.setLooks)
				{
					ORK.Battle.SetLooks(null);
				}
				ORK.Battle.StartBattle(this.canEscape);
			}
			// battle finished
			else if(this.battleMode == 2)
			{
				this.battleMode = 3;
				this.SetVariables();
				this.SetSceneID();
				
				this.endEvent = new BattleEndEvent();
				this.endEvent.SetInitialCameraPosition(this.initialCamPosition, this.initialCamRotation, this.initialFieldOfView);
				if(BattleOutcome.Victory.Equals(this.outcome))
				{
					ORKBattleEndEvent evtAsset = this.useDefaultEnd ? 
						ORK.BattleSystem.GetVictoryEvent(this.battleType) : 
						this.victoryEventAsset;
					if(evtAsset != null)
					{
						this.endEvent.SetData(evtAsset.GetData().ToDataObject());
					}
				}
				else if(BattleOutcome.Escape.Equals(this.outcome))
				{
					ORKBattleEndEvent evtAsset = this.useDefaultEnd ? 
						ORK.BattleSystem.GetEscapeEvent(this.battleType) : 
						this.escapeEventAsset;
					if(evtAsset != null)
					{
						this.endEvent.SetData(evtAsset.GetData().ToDataObject());
					}
				}
				else if(BattleOutcome.Defeat.Equals(this.outcome))
				{
					ORKBattleEndEvent evtAsset = this.useDefaultEnd ? 
						ORK.BattleSystem.GetDefeatEvent(this.battleType) : 
						this.defeatEventAsset;
					if(evtAsset != null)
					{
						this.endEvent.SetData(evtAsset.GetData().ToDataObject());
					}
				}
				else if(BattleOutcome.LeaveArena.Equals(this.outcome))
				{
					ORKBattleEndEvent evtAsset = this.useDefaultEnd ? 
						ORK.BattleSystem.GetLeaveArenaEvent(this.battleType) : 
						this.leaveArenaEventAsset;
					if(evtAsset != null)
					{
						this.endEvent.SetData(evtAsset.GetData().ToDataObject());
					}
				}
				this.endEvent.StartEvent(this, ORK.Game.GetPlayer());
			}
			// end event finished
			else if(this.battleMode == 3)
			{
				this.battleMode = 0;
				this.endEvent = null;
		
				if(ORK.Battle.HasGains())
				{
					ORK.Battle.CollectGains(true, 
						ORK.Battle.GainsCloseTime, ORK.Battle.GainsBlockAccept, 
						null, -1);
				}
				
				ORK.Battle.ClearGains();
				ORK.Battle.ClearObjectsAndAnimations();
				ORK.Game.Combatants.EndBattle();
				
				ORK.Battle.DoBattleBlock(-1);
				ORK.Battle.DoMoveAIBlock(-1);
				ORK.Control.SetInBattle(-1);
				ORK.Battle.ClearBattle();
		
				// call event that started the battle
				if(ComponentHelper.IsAlive(this.starter))
				{
					if(this.starter is GameEvent && 
						((GameEvent)this.starter).blockingEvent)
					{
						ORK.Control.SetEventBlock(1);
					}
					this.starter.EventEnded();
					this.starter = null;
				}
		
				if(this.markSceneChangeDestroy && this.sceneChangedDestroy)
				{
					GameObject.Destroy(this.gameObject);
				}
				else if(this.repeatDestroy)
				{
					this.CheckAutoDestroy();
				}
			}
		}
		
		public override void SetSceneID()
		{
			base.SetSceneID();
			if(this.joined != null && this.joined.Count > 0)
			{
				for(int i=0; i<this.joined.Count; i++)
				{
					if(this.joined[i] != null && this.joined[i].Group.Spawner != null)
					{
						this.joined[i].Group.Spawner.SetSceneID();
					}
				}
			}
			this.joined = null;
		}
		
		
		/*
		============================================================================
		Battle spot functions
		============================================================================
		*/
		public void SetSpot(Combatant oldUser, Combatant newUser)
		{
			if(this.playerSpotList != null)
			{
				foreach(KeyValuePair<GameObject, Combatant> pair in this.playerSpotList)
				{
					if(pair.Value == oldUser)
					{
						this.playerSpotList[pair.Key] = newUser;
						return;
					}
				}
			}
			if(this.allySpotList != null)
			{
				foreach(KeyValuePair<GameObject, Combatant> pair in this.allySpotList)
				{
					if(pair.Value == oldUser)
					{
						this.allySpotList[pair.Key] = newUser;
						return;
					}
				}
			}
			if(this.enemySpotList != null)
			{
				foreach(KeyValuePair<GameObject, Combatant> pair in this.enemySpotList)
				{
					if(pair.Value == oldUser)
					{
						this.enemySpotList[pair.Key] = newUser;
						return;
					}
				}
			}
		}
		
		private void SpotListOnGround(Dictionary<GameObject, Combatant> list)
		{
			foreach(KeyValuePair<GameObject, Combatant> pair in list)
			{
				if(pair.Key != null)
				{
					pair.Key.transform.position = new Vector3(
						pair.Key.transform.position.x, 
						ORK.BattleSpots.onGround ? 
							this.transform.position.y + 1 : 
							pair.Key.transform.position.y, 
						pair.Key.transform.position.z);
					this.SpotOnGround(pair.Key);
				}
			}
		}
		
		private void SpotOnGround(GameObject obj)
		{
			if(ORK.BattleSpots.onGround)
			{
				PlaceOnGround pog = ComponentHelper.Get<PlaceOnGround>(obj);
				pog.distance = ORK.BattleSpots.distance;
				pog.layerMask = ORK.BattleSpots.layerMask;
				pog.offset = ORK.BattleSpots.rayOffset.GetValue();
				pog.Place();
			}
		}
		
		public void SetNextPlayerSpot(Combatant combatant, GroupAdvantageType advantage)
		{
			GameObject spot = null;
			if(this.playerSpotList == null)
			{
				this.playerSpotList = new Dictionary<GameObject, Combatant>();
			}
			// check already added spots
			foreach(KeyValuePair<GameObject, Combatant> pair in this.playerSpotList)
			{
				if(pair.Value == null)
				{
					spot = pair.Key;
				}
			}
			// check spots added to battle component
			if(spot == null && this.ownSpots && 
				this.playerSpotList.Count < this.playerSpot.Length)
			{
				if(GroupAdvantageType.Player.Equals(advantage))
				{
					spot = this.playerSpotPA[this.playerSpotList.Count];
				}
				else if(GroupAdvantageType.Enemy.Equals(advantage))
				{
					spot = this.playerSpotEA[this.playerSpotList.Count];
				}
				else
				{
					spot = this.playerSpot[this.playerSpotList.Count];
				}
			}
			// no spot found > create new spot
			if(spot == null)
			{
				spot = new GameObject("_PlayerSpot" + this.playerSpotList.Count);
				ORK.BattleSpots.SetPlayerSpot(this.playerSpotList.Count, advantage, this.transform, spot.transform);
				spot.transform.parent = this.transform;
				this.SpotOnGround(spot);
			}
			// add/update list, set spot to combatant
			combatant.BattleSpot = spot;
			if(this.playerSpotList.ContainsKey(spot))
			{
				this.playerSpotList[spot] = combatant;
			}
			else
			{
				this.playerSpotList.Add(spot, combatant);
			}
		}
		
		public void SetNextAllySpot(Combatant combatant, GroupAdvantageType advantage)
		{
			GameObject spot = null;
			if(this.allySpotList == null)
			{
				this.allySpotList = new Dictionary<GameObject, Combatant>();
			}
			// check already added spots
			foreach(KeyValuePair<GameObject, Combatant> pair in this.allySpotList)
			{
				if(pair.Value == null)
				{
					spot = pair.Key;
				}
			}
			// check spots added to battle component
			if(spot == null && this.ownSpots && 
				this.allySpotList.Count < this.allySpot.Length)
			{
				if(GroupAdvantageType.Player.Equals(advantage))
				{
					spot = this.allySpotPA[this.allySpotList.Count];
				}
				else if(GroupAdvantageType.Enemy.Equals(advantage))
				{
					spot = this.allySpotEA[this.allySpotList.Count];
				}
				else
				{
					spot = this.allySpot[this.allySpotList.Count];
				}
			}
			// no spot found > create new spot
			if(spot == null)
			{
				spot = new GameObject("_AllySpot" + this.allySpotList.Count);
				ORK.BattleSpots.SetAllySpot(this.allySpotList.Count, advantage, this.transform, spot.transform);
				spot.transform.parent = this.transform;
				this.SpotOnGround(spot);
			}
			// add/update list, set spot to combatant
			combatant.BattleSpot = spot;
			if(this.allySpotList.ContainsKey(spot))
			{
				this.allySpotList[spot] = combatant;
			}
			else
			{
				this.allySpotList.Add(spot, combatant);
			}
		}
		
		public void SetNextEnemySpot(Combatant combatant, GroupAdvantageType advantage)
		{
			GameObject spot = null;
			if(this.enemySpotList == null)
			{
				this.enemySpotList = new Dictionary<GameObject, Combatant>();
			}
			// check already added spots
			foreach(KeyValuePair<GameObject, Combatant> pair in this.enemySpotList)
			{
				if(pair.Value == null)
				{
					spot = pair.Key;
				}
			}
			// check spots added to battle component
			if(spot == null && this.ownSpots && 
				this.enemySpotList.Count < this.enemySpot.Length)
			{
				if(GroupAdvantageType.Player.Equals(advantage))
				{
					spot = this.enemySpotPA[this.enemySpotList.Count];
				}
				else if(GroupAdvantageType.Enemy.Equals(advantage))
				{
					spot = this.enemySpotEA[this.enemySpotList.Count];
				}
				else
				{
					spot = this.enemySpot[this.enemySpotList.Count];
				}
			}
			// no spot found > create new spot
			if(spot == null)
			{
				spot = new GameObject("_EnemySpot" + this.enemySpotList.Count);
				ORK.BattleSpots.SetEnemySpot(this.enemySpotList.Count, advantage, this.transform, spot.transform);
				spot.transform.parent = this.transform;
				this.SpotOnGround(spot);
			}
			// add/update list, set spot to combatant
			combatant.BattleSpot = spot;
			if(this.enemySpotList.ContainsKey(spot))
			{
				this.enemySpotList[spot] = combatant;
			}
			else
			{
				this.enemySpotList.Add(spot, combatant);
			}
		}
		
		
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static BattleComponent CreateBattle(List<Combatant> enemy)
		{
			if(enemy != null && enemy.Count > 0 && 
				ORK.Game.ActiveGroup.Leader != null && 
				ORK.Game.ActiveGroup.Leader.GameObject != null)
			{
				List<Group> groupList = new List<Group>();
				
				// add groups to list and calculate battle position
				List<GameObject> tmp = new List<GameObject>();
				for(int i=0; i<enemy.Count; i++)
				{
					if(enemy[i] != null)
					{
						Group g = enemy[i].Group;
						groupList.Add(g);
						List<Combatant> battleGroup = g.GetBattle();
						for(int j=0; j<battleGroup.Count; j++)
						{
							if(battleGroup[j] != null && 
								battleGroup[j].GameObject != null)
							{
								tmp.Add(battleGroup[j].GameObject);
							}
						}
					}
				}
				tmp.Add(ORK.Game.ActiveGroup.Leader.GameObject);
				
				Vector3 center = TransformHelper.GetCenterPosition(tmp);
				BattleComponent battle = null;
				
				for(int i=0; i<enemy.Count; i++)
				{
					if(enemy[i] != null)
					{
						if(enemy[i].Group.Spawner != null)
						{
							battle = enemy[i].Group.Spawner.GetBattleComponent(center, 
								ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles);
						}
						else if(enemy[i].Component != null && 
							enemy[i].Component.addCombatantComponent != null)
						{
							battle = enemy[i].Component.addCombatantComponent.GetBattleComponent(center, 
								ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles);
						}
						if(battle != null)
						{
							break;
						}
					}
				}
				
				if(battle == null)
				{
					battle = new GameObject("_Battle").AddComponent<BattleComponent>();
					battle.transform.position = center;
					battle.transform.eulerAngles = ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles;
					
					for(int i=0; i<enemy.Count; i++)
					{
						if(enemy[i] != null)
						{
							battle.battleType = enemy[i].Group.BattleType;
							break;
						}
					}
					battle.useSceneID = false;
					battle.DontDestroy();
				}

				if(battle != null)
				{
					battle.startGroup = groupList;
				}
				return battle;
			}
			return null;
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "Battle.psd");
		}
	}
}
